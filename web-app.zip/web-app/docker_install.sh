#!/bin/bash

# We need to install dependencies only for Docker
[[ ! -e /.dockerenv ]] && exit 0

set -xe

# Install git (the php image doesn't have it) which is required by composer
apt-get update -yqq
apt-get upgrade -yqq
apt-get install apt-utils -yqq

# Install other deps
apt-get install zip unzip -yqq

# Install Componser
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
php composer-setup.php
php -r "unlink('composer-setup.php');"

# Setu postgres
/etc/init.d/postgresql start
sudo -u postgres sh -c 'createdb dycom_web_app'
sudo -u postgres sh -c "psql -c \"CREATE USER dycom_Zsql_dycom_patrols WITH PASSWORD 'dycom_W!skEyD!still&r';\""

# Install NPM 
curl -sL https://deb.nodesource.com/setup_6.x | sudo -E bash -
apt-get install -y nodejs
npm -v
