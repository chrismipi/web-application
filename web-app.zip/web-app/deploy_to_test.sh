#!/bin/bash

# Only run under Docker context
[[ ! -e /.dockerenv ]] && exit 0

set -xe

# Setup SSH
which ssh-agent || ( apt-get update -y && apt-get install openssh-client -y )
mkdir -p ~/.ssh
eval $(ssh-agent -s)
[[ -f /.dockerenv ]] && echo -e "Host *\n\tStrictHostKeyChecking no\n\n" > ~/.ssh/config

# Deploy the code to the test server
ssh-add <(echo "$STAGING_PRIVATE_KEY")
# ssh-keyscan -H '139.59.170.128' >> ~/.ssh/known_hosts
ssh -p22 gitlab@139.59.170.128 "cd ~/deployments/dycom/dycom-deploy-makefile/ && make deploy-web-app"
# ssh -t gitlab@139.59.170.128 "cd ~/deployments/dycom/dycom-deploy-makefile/ && make deploy-web-app"
