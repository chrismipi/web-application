@extends('layouts.no-auth-layout')

@section('content')
    <login></login>
@endsection
