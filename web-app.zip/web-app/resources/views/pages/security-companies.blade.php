@extends('layouts.default')

@section('content')
	<security-companies :security-companies="{{ json_encode($securityCompanies) }}"></security-companies>
@endsection
