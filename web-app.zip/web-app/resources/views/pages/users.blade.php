@extends('layouts.default')

@section('content')
	<users :users="{{ json_encode($users) }}"></users>
@endsection
