@extends('layouts.default')

@section('content')
	<clients :clients="{{ json_encode($clients) }}"></clients>
@endsection
