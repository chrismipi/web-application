@extends('layouts.default')

@section('content')
	<upcomming-patrols :patrols="{{ json_encode($patrols) }}"></upcomming-patrols>
@endsection
