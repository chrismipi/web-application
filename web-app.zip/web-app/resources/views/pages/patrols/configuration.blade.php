@extends('layouts.default')

@section('content')
	<patrol-configuration :sites="{{ json_encode($sites) }}"></patrol-configuration>
@endsection
