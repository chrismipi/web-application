@extends('layouts.default')

@section('content')
	<active-patrols :patrols="{{ json_encode($patrols) }}"></active-patrols>
@endsection
