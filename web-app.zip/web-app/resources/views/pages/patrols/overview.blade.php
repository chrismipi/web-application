@extends('layouts.default')

@section('content')
	<patrol-overview :patrols="{{ json_encode($patrols) }}"></patrol-overview>
@endsection
