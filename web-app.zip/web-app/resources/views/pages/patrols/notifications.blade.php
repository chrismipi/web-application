@extends('layouts.default')

@section('content')
	<notifications :active="{{ json_encode($activeNotification) }}"></notifications>
@endsection
