@extends('layouts.default')

@section('content')
	<patrol-history :patrols="{{ json_encode($patrols) }}"></patrol-history>
@endsection
