@extends('layouts.default')

@section('content')
    <dashboard></dashboard>
@endsection
