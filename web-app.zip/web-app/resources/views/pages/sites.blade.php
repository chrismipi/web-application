@extends('layouts.default')

@section('content')
	<sites :sites="{{ json_encode($sites) }}"></sites>
@endsection
