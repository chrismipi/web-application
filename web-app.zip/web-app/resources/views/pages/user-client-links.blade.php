@extends('layouts.default')

@section('content')
	<user-client-links :user-client-links="{{ json_encode($userClientlinks) }}"></user-client-links>
@endsection
