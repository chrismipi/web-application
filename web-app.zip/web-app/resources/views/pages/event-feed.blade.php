@extends('layouts.default')

@section('content')
    {{-- <p>We are logged in, yay!</p> --}}
    @if (isset($event))
    	<event-feed :current-event="{{ json_encode($event) }}"></event-feed>
    @elseif (isset($events))
    	<event-feed :events="{{ json_encode($events) }}"></event-feed>
    @endif
@endsection
