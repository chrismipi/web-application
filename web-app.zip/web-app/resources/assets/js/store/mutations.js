const MUTATION_NAME = 'MUTATION_NAME';

export default{
  MUTATION_NAME,
};
