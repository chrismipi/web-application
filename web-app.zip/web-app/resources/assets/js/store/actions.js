import types from './mutations';

export default (commit) => {
  commit(types.MUTATION_NAME);
};
