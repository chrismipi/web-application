/* eslint-disable */
import moment from 'moment';
/* eslint-disable */
import * as types from '../mutations';

const state = {
  user: {
    userName: '',
    userRoles: [],
    clients: [],
    securityCompanies: [],
    sites: [],
    notifications: [],
    permissions: [],
  },
};

const getters = {
  userName(state) {
    return state.user.userName;
  },

  userRoles(state) {
    return state.user.userRoles;
  },

  clients(state) {
    return state.user.clients;
  },

  securityCompanies(state) {
    return state.user.securityCompanies;
  },

  sites(state) {
    return state.user.sites;
  },

  notifications(state) {
    return state.user.notifications;
  },

  permissions(state) {
    return state.user.permissions;
  }
};

const actions = {
  removeNotification(context, notification) {
    const audio = new Audio('/audio/trash.mp3');
    audio.play();
    return new Promise((resolve, reject) => {
      axios.get(`/api/alert/ack/${notification.id}`)
        .then((response) => {
          context.commit('removeNotification', notification);
          resolve(response);
        })
        .catch((error) => {
          reject(error)
        });
    });
  },

  clear(context) {
    return new Promise((resolve, reject) => {
      context.commit('userName', '');
      context.commit('userRoles', []);
      context.commit('clients', []);
      context.commit('securityCompanies', []);
      context.commit('sites', []);
      context.commit('permissions', []);
      context.commit('notifications', []);
      resolve(true);
    });
  },
};

const mutations = {
  userName(state, userName) {
    state.user.userName = userName;
  },

  userRoles(state, userRoles) {
    state.user.userRoles = userRoles;
  },

  clients(state, clients) {
    state.user.clients = clients;
  },

  securityCompanies(state, securityCompanies) {
    state.user.securityCompanies = securityCompanies;
  },

  sites(state, sites) {
    state.user.sites = sites;
  },

  permissions(state, permissions) {
    state.user.permissions = permissions;
  },

  notifications(state, notifications) {
    state.user.notifications = notifications;
  },

  addNotification(state, notification) {
    state.user.notifications.push(notification);
  },

  removeNotification(state, notification) {
    const tempNotification = window._.find(state.user.notifications, notification);
    state.user.notifications.splice(tempNotification, 1);
  },

  setNotifications(state, notifications) {
    state.user.notifications = notifications;
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};