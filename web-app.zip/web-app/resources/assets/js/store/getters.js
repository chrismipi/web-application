export default function(state) {
  return state;
}
