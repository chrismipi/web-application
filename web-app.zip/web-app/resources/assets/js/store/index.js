import Vue from 'vue';
import Vuex from 'vuex';
import CreatePersistedState from 'vuex-persistedstate';
import createLogger from 'vuex/dist/logger';
import * as actions from './actions';
import session from './modules/session';

Vue.use(Vuex);

const debug = process.env.NODE_ENV !== 'production';

export default new Vuex.Store({
  actions,
  modules: {
    session,
  },
  strict: debug,
  plugins: debug ? [createLogger(), CreatePersistedState()] : [CreatePersistedState()],
});
