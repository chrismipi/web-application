<template>
  <v-app id="inspire">
    <main>
      <v-content>
        <slot></slot>
      </v-content>
    </main>
    <page-footer></page-footer>
    <notification-toast></notification-toast>
  </v-app>
</template>

<script>
import NotificationToast from '../components/layout/NotificationToast';
import PageFooter from '../components/layout/Footer';
export default {
  components: {
    NotificationToast,
    PageFooter,
  },
  data: () => ({
  }),
  mounted() {
  }
}
</script>