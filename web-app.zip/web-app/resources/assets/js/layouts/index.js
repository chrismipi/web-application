Vue.component('default-layout', require('./DefultLayout.vue'));
Vue.component('no-auth-layout', require('./NoAuthLayout.vue'));