<template>
  <v-app id="inspire">
    <v-navigation-drawer
      persistent
      v-model="drawerRight"
      width="460"
      right
      clipped
      enable-resize-watcher
      app
    >
      <notification-panel v-model="notifications" v-on:mute-event="muteEvent"></notification-panel>
    </v-navigation-drawer>
    <toolbar v-model="drawer"></toolbar>
    <v-navigation-drawer persistent clipped app v-model="drawer">
      <side-menu></side-menu>
    </v-navigation-drawer>
    <main>
      <v-content>
        <v-layout row wrap>
          <v-flex xs12>
            <v-breadcrumbs icons divider="chevron_right" style="float: left;">
              <v-breadcrumbs-item
                v-for="(breadcrum,index) in breadcrums"
                :key="index"
                :disabled="breadcrum.disabled"
              >{{ breadcrum.text }}</v-breadcrumbs-item>
            </v-breadcrumbs>
          </v-flex>
          <v-flex xs12>
            <slot></slot>
          </v-flex>
        </v-layout>
      </v-content>
    </main>
    <page-footer></page-footer>
    <notification-toast></notification-toast>
  </v-app>
</template>

<script>
import Toolbar from "../components/layout/Toolbar";
import SideMenu from "../components/layout/SideMenu";
import NotificationPanel from "../components/layout/NotificationPanel";
import PageFooter from "../components/layout/Footer";
import NotificationToast from "../components/layout/NotificationToast";
import { mapGetters } from "vuex";

export default {
  props: {
    userName: {
      type: String,
      required: true
    },
    userRoles: {
      type: Array,
      required: true
    },
    clients: {
      type: Array,
      required: false
    },
    securityCompanies: {
      type: Array,
      required: false
    },
    sites: {
      type: Array,
      required: false
    },
    alerts: {
      type: Array,
      required: false
    },
    permissions: {
      type: Array,
      required: true
    }
  },
  components: {
    Toolbar,
    SideMenu,
    NotificationPanel,
    PageFooter,
    NotificationToast
  },
  data: () => ({
    drawer: true,
    drawerRight: true,
    right: true
  }),
  computed: {
    breadcrums() {
      const result = [];
      window.location.pathname.split("/").forEach(path => {
        if (path !== "" && path !== "/") {
          result.push({
            text: window._.capitalize(path),
            disabled: false
          });
        }
      });

      if (result.length === 0) {
        result.push({
          text: "Dashboard",
          disabled: false
        });
      }

      return result;
    },

    ...mapGetters({
      notifications: "session/notifications"
    })

  },
  methods: {
    muteEvent(notification) {
      this.$store.dispatch("session/removeNotification", notification);
    },

    playNotificationSound(notificationType) {
      let soundPath = "/audio/beep.mp3";

      if (
        notificationType === "panic_alert" ||
        notificationType === "incident" ||
        notificationType === "guard_call_me"
      ) {
        soundPath = "/audio/alarm.mp3";
      }

      const audio = new Audio(soundPath);
      audio.play();
    }
  },
  created() {
    // On every re-load of the layout, overwrite the notifications
    // with the new ones.
    this.$store.commit("session/setNotifications", this.alerts);
    this.$store.commit("session/userName", this.userName);
    this.$store.commit("session/userRoles", this.userRoles);
    this.$store.commit("session/clients", this.clients);
    this.$store.commit("session/sites", this.sites);
    this.$store.commit("session/securityCompanies", this.securityCompanies);
    this.$store.commit("session/permissions", this.permissions);
  },
  mounted() {
    this.$store.getters["session/sites"].forEach(site => {
      //sometime site comes as an object and sometimes as a number, still need to check why
      var intSite;
      if (isNaN(site)) {
        intSite = site.id;
      } else {
        intSite = site;
      }
      Echo.channel(`alert.site.${intSite}`).listen(
        ".App\\Events\\AlertEvent",
        e => {
          console.log("EVENT TRIGERED: ", e);
          this.playNotificationSound(e.alert.event_type);
          this.$store.commit("session/addNotification", e.alert);
        }
      );
    });
  }
};
</script>
