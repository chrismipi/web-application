<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs12>
        <transition name="component-fade" mode="out-in">
          <component
            v-bind:is="currentView"
            v-model="currentVModel"
            :security-companies="securityCompanies"
            v-on:edit="toggleEditSecurityCompany"
            v-on:show-list="showList"
            :disabled="!this.canEditSecurityCompany"
          ></component>
        </transition>
      </v-flex>
    </v-layout>
    <v-fab-transition v-if="fabButtonIconShow">
      <v-btn fixed dark fab bottom left class="teal" @click="addNewSecurityCompany()">
        <v-icon>{{ fabButtonIcon }}</v-icon>
      </v-btn>
    </v-fab-transition>
  </v-container>
</template>

<script>
import SecurityCompanyList from "../components/securityCompanies/SecurityCompanyList";
import AddSecurityCompany from "../components/securityCompanies/AddSecurityCompany";
import EditSecurityCompany from "../components/securityCompanies/EditSecurityCompany";
import { mapGetters } from "vuex";

export default {
  props: {
    securityCompanies: {
      type: Array,
      required: true
    }
  },
  components: {
    SecurityCompanyList,
    AddSecurityCompany,
    EditSecurityCompany
  },
  data: () => ({
    currentView: "no-permissions",
    currentVModel: null,
    fabButtonIcon: "add",
    fabButtonIconShow: false,
    canAddSecurityCompany: false,
    canViewSecurityCompany: false,
    canEditSecurityCompany: false,
    canDeleteSecurityCompany: false
  }),
  computed: {
    ...mapGetters({
      permissions: "session/permissions"
    })
  },
  methods: {
    addNewSecurityCompany() {
      if (this.canAddSecurityCompany) {
        if (this.currentView === "security-company-list") {
          this.currentView = "add-security-company";
          this.fabButtonIcon = "arrow_back";
        } else {
          if (!this.canViewSecurityCompany) {
            this.currentView = "no-permissions";
            this.fabButtonIconShow = false;
          } else {
            this.currentView = "security-company-list";
          }

          if (this.canAddSecurityCompany) {
            this.fabButtonIcon = "add";
            this.fabButtonIconShow = true;
          } else {
            this.fabButtonIconShow = false;
          }
        }
      } else {
        if (this.canViewSecurityCompany) {
          this.currentView = "security-company-list";
          this.fabButtonIconShow = false;
          this.fabButtonIcon = "add";
        }
      }
    },

    showList() {
      if (this.canViewSecurityCompany) {
        this.currentView = "security-company-list";
      } else {
        this.currentView = "no-permissions";
      }

      if (this.canAddSecurityCompany) {
        this.fabButtonIcon = "add";
        this.fabButtonIconShow = true;
      } else {
        this.fabButtonIconShow = false;
      }
    },

    setPermissions() {
      this.canAddSecurityCompany = window._.find(this.permissions, {
        name: "Add Security Company"
      })
        ? true
        : false;
      this.canViewSecurityCompany = window._.find(this.permissions, {
        name: "View Security Company"
      })
        ? true
        : false;
      this.canEditSecurityCompany = window._.find(this.permissions, {
        name: "Edit Security Company"
      })
        ? true
        : false;
      this.canDeleteSecurityCompany = window._.find(this.permissions, {
        name: "Delete Security Company"
      })
        ? true
        : false;
    },

    initViewBasedOnPermissions() {
      if (this.canViewSecurityCompany) {
        this.currentView = "security-company-list";
      }

      if (this.canAddSecurityCompany) {
        this.currentView = "security-company-list";
        this.fabButtonIconShow = true;
      }
    },

    toggleEditSecurityCompany(securityCompany) {
      if (this.canEditSecurityCompany || this.canViewSecurityCompany) {
        if (this.currentView === "security-company-list") {
          this.currentVModel = securityCompany;
          this.currentView = "edit-security-company";
          this.fabButtonIcon = "arrow_back";
          this.fabButtonIconShow = true;
        } else {
          this.showList();
        }
      } else {
        this.currentView = "no-permissions";
        this.fabButtonIcon = "arrow_back";
        this.fabButtonIconShow = true;
      }
    }
  },
  created() {
    this.setPermissions();
    this.initViewBasedOnPermissions();
  },
  mounted() {},
  beforeDestroy() {}
};
</script>

<style scoped>
.component-fade-enter-active,
.component-fade-leave-active {
  transition: opacity 0.3s ease;
}
.component-fade-enter,
.component-fade-leave-to {
  opacity: 0;
}
</style>