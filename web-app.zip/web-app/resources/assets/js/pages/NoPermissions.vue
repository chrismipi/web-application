<template>
	<v-container grid-list-md text-xs-center>
		<v-layout row wrap>
			<v-flex xs12>
				<h5>You do not have permissions to view this page. Please contact your system administrator.</h5>
			</v-flex>
		</v-layout>
	</v-container>
</template>

<script>

export default {
	data: () => ({
	}),
	methods: {
	},
	mounted() {
	},
	beforeDestroy () {
	},
}
</script>

<style scoped>
</style>