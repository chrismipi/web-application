<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs12>
        <transition name="component-fade" mode="out-in">
          <component
            v-bind:is="currentView"
            v-model="currentVModel"
            :users="users"
            v-on:edit="toggleEditUser"
            v-on:show-list="showList"
            :disabled="!this.canEditUser"
          ></component>
        </transition>
        <v-fab-transition v-if="fabButtonIconShow">
          <v-btn fixed dark fab bottom left class="teal" @click="addNewUsers()">
            <v-icon>{{ fabButtonIcon }}</v-icon>
          </v-btn>
        </v-fab-transition>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
import UserList from "../components/users/UserList";
import AddUser from "../components/users/AddUser";
import EditUser from "../components/users/EditUser";
import { mapGetters } from "vuex";

export default {
  props: {
    users: {
      type: Array,
      required: true
    }
  },
  components: {
    UserList,
    AddUser,
    EditUser
  },
  data: () => ({
    addingusers: false,
    currentView: "user-list",
    currentVModel: null,
    fabButtonIcon: "add",
    fabButtonIconShow: false,
    canAddSite: false,
    canViewSite: false,
    canEditSite: false,
    canDeleteSite: false,
    canEditUser: false
  }),
  computed: {
    ...mapGetters({
      permissions: "session/permissions"
    })
  },
  methods: {
    addNewUsers() {
      if (this.canAddUser) {
        if (this.currentView === "user-list") {
          this.currentView = "add-user";
          this.fabButtonIcon = "arrow_back";
        } else {
          if (!this.canViewUser) {
            this.currentView = "no-permissions";
            this.fabButtonIconShow = false;
          } else {
            this.currentView = "user-list";
          }

          if (this.canAddUser) {
            this.fabButtonIcon = "add";
            this.fabButtonIconShow = true;
          } else {
            this.fabButtonIconShow = false;
          }
        }
      } else {
        if (this.canViewUser) {
          this.currentView = "user-list";
          this.fabButtonIconShow = false;
          this.fabButtonIcon = "add";
        }
      }
    },

    showList() {
      if (this.canViewUser) {
        this.currentView = "user-list";
      } else {
        this.currentView = "no-permissions";
      }

      if (this.canAddUser) {
        this.fabButtonIcon = "add";
        this.fabButtonIconShow = true;
      } else {
        this.fabButtonIconShow = false;
      }
    },

    setPermissions() {
      if (
        window._.find(this.permissions, { name: "Add Admin" }) ||
        window._.find(this.permissions, { name: "Add Operator" }) ||
        window._.find(this.permissions, { name: "Add Client" })
      ) {
        this.canAddUser = true;
      }

      if (
        window._.find(this.permissions, { name: "View Admin" }) ||
        window._.find(this.permissions, { name: "View Operator" }) ||
        window._.find(this.permissions, { name: "View Client" })
      ) {
        this.canViewUser = true;
      }

      if (
        window._.find(this.permissions, { name: "Edit Admin" }) ||
        window._.find(this.permissions, { name: "Edit Operator" }) ||
        window._.find(this.permissions, { name: "Edit Client" })
      ) {
        this.canEditUser = true;
      }

      if (
        window._.find(this.permissions, { name: "Delete Admin" }) ||
        window._.find(this.permissions, { name: "Delete Operator" }) ||
        window._.find(this.permissions, { name: "Delete Client" })
      ) {
        this.canDeleteUser = true;
      }
    },

    initViewBasedOnPermissions() {
      if (this.canViewUser) {
        this.currentView = "user-list";
      }

      if (this.canAddUser) {
        this.currentView = "user-list";
        this.fabButtonIconShow = true;
      }
    },

    toggleEditUser(user) {
      if (this.canEditUser || this.canViewUser) {
        if (this.currentView === "user-list") {
          this.currentVModel = user;
          this.currentView = "edit-user";
          this.fabButtonIcon = "arrow_back";
          this.fabButtonIconShow = true;
        } else {
          this.showList();
        }
      } else {
        this.currentView = "no-permissions";
        this.fabButtonIcon = "arrow_back";
        this.fabButtonIconShow = true;
      }
    }
  },
  created() {
    this.setPermissions();
    this.initViewBasedOnPermissions();
  },
  mounted() {},
  beforeDestroy() {}
};
</script>

<style scoped>
.component-fade-enter-active,
.component-fade-leave-active {
  transition: opacity 0.3s ease;
}
.component-fade-enter,
.component-fade-leave-to {
  opacity: 0;
}
</style>