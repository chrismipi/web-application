<template>
	<no-auth-layout>
		<v-layout class="main-layout">
			<transition name="fade" mode="out-in">
				<v-flex xs12 sm4 offset-sm4 v-if="!successAuth">
					<v-card>
						<v-card-title primary-title class="teal lighten-2">
							<div class="headline white--text">Dycom Radio</div>
							<div class="subtitle white--text">Please Login</div>
						</v-card-title>
						<v-card-text>
							<form>
								<v-text-field v-model="email" label="Email" :error-messages="errors.collect('email')" v-validate="'required|email'" data-vv-name="email" required></v-text-field>
								<v-text-field v-model="password" label="Pasword" :error-messages="errors.collect('password')" v-validate="'required'" data-vv-name="password" required :append-icon="e4 ? 'visibility' : 'visibility_off'" :append-icon-cb="() => (e4 = !e4)" :type="e4 ? 'password' : 'text'"></v-text-field>
								<v-btn block @click="submit" class="teal">submit</v-btn>
								<v-btn block @click="clear">clear</v-btn>
							</form>
						</v-card-text>
					</v-card>
				</v-flex>
				<v-flex v-else xs12 sm4 offset-sm4 class="progress-loader">
					<div class="headline">Success!</div>
					<div class="subtitle">Loading your dashboard...</div>
					<v-progress-circular v-bind:size="250" v-bind:width="15" v-bind:rotate="-90" v-bind:value="loader.value" color="teal lighten-2">
						{{ loader.value }}%
					</v-progress-circular>
				</v-flex>
			</transition>
		</v-layout>
	</no-auth-layout>
</template>

<script>
	import { EventBus } from '../utils/event-bus';

	export default {
		data: () => ({
			e4: true,
			email: '',
			password: '',
			loader: {
				interval: {},
				value: 0
			},
			successAuth: false,
		}),
		methods: {
			submit () {
				this.$validator.validateAll()
				.then(result => {
					if (result) {
						axios.post('/login', {
							email: this.email,
							password: this.password,
						})
						.then((response) => {
							EventBus.$emit('notify', 'success', 'Login Successful!');
							this.successAuth = true;
							this.loader.interval = setInterval(() => {
								if (this.loader.value < 100) {
									this.loader.value += 10;
								}
							}, 1000);

							window.location.reload();
						})
						.catch((error) => {
							EventBus.$emit('notify', 'error', 'Invalid Credentials!');
						});
					}
				}).catch(() => {
					EventBus.$emit('notify', 'error', 'Something went wrong. Please try again later.');
				});
			},
			clear () {
				this.email = ''
				this.password = ''
				this.$validator.reset()
			},
		},
		beforeDestroy () {
			clearInterval(this.interval)
		},
	}
</script>

<style scoped>
.headline{
	text-align: center;
	width: 100%;
}

.subtitle{
	text-align: center;
	width: 100%;
}

.main-layout{
	margin-top: 100px;
}


.progress-circular{
	margin: 1rem;
}

.progress-loader{
	text-align: center;
}
</style>
