<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs12>
        <transition name="component-fade" mode="out-in">
          <component
            v-bind:is="currentView"
            v-model="currentVModel"
            :sites="sites"
            v-on:edit="toggleEditSite"
            v-on:show-list="showList"
            v-on:site-events="showEventAlerts"
            :disabled="!this.canEditSite"
          ></component>
        </transition>
      </v-flex>
    </v-layout>
    <v-fab-transition v-if="fabButtonIconShow">
      <v-btn fixed dark fab bottom left class="teal" @click="addNewSite()">
        <v-icon>{{ fabButtonIcon }}</v-icon>
      </v-btn>
    </v-fab-transition>
  </v-container>
</template>

<script>
import SiteList from "../components/sites/SiteList";
import AddSite from "../components/sites/AddSite";
import EditSite from "../components/sites/EditSite";
import SiteEvents from "../components/sites/SiteEvents";
import { EventBus } from '../utils/event-bus';
import { mapGetters } from "vuex";

export default {
  props: {
    sites: {
      type: Array,
      required: true
    }
  },
  components: {
    SiteList,
    AddSite,
    EditSite,
    SiteEvents
  },
  data: () => ({
    addingSite: false,
    currentView: "site-list",
    currentVModel: null,
    fabButtonIcon: "add",
    fabButtonIconShow: false,
    canAddSite: false,
    canViewSite: false,
    canEditSite: false,
    canDeleteSite: false
  }),
  computed: {
    ...mapGetters({
      permissions: "session/permissions"
    })
  },
  methods: {
    addNewSite() {
      if (this.canAddSite) {
        if (this.currentView === "site-list") {
          this.currentView = "add-site";
          this.fabButtonIcon = "arrow_back";
        } else {
          if (!this.canViewSite) {
            this.currentView = "no-permissions";
            this.fabButtonIconShow = false;
          } else {
            this.currentView = "site-list";
          }

          if (this.canAddSite) {
            this.fabButtonIcon = "add";
            this.fabButtonIconShow = true;
          } else {
            this.fabButtonIconShow = false;
          }
        }
      } else {
        if (this.canViewSite) {
          this.currentView = "site-list";
          this.fabButtonIconShow = false;
          this.fabButtonIcon = "add";
        }
      }
    },

    showList() {
      if (this.canViewSite) {
        this.currentView = "site-list";
      } else {
        this.currentView = "no-permissions";
      }

      if (this.canAddSite) {
        this.fabButtonIcon = "add";
        this.fabButtonIconShow = true;
      } else {
        this.fabButtonIconShow = false;
      }
    },

    showEventAlerts(site) {
       this.currentView = "site-events";
        this.currentVModel = site;
        this.fabButtonIcon = "arrow_back";
        this.fabButtonIconShow = true;
    },

    setPermissions() {
      this.canAddSite = window._.find(this.permissions, { name: "Add Site" })
        ? true
        : false;
      this.canViewSite = window._.find(this.permissions, { name: "View Site" })
        ? true
        : false;
      this.canEditSite = window._.find(this.permissions, { name: "Edit Site" })
        ? true
        : false;
      this.canDeleteSite = window._.find(this.permissions, {
        name: "Delete Site"
      })
        ? true
        : false;
    },

    initViewBasedOnPermissions() {
      if (this.canViewSite) {
        this.currentView = "site-list";
      }

      if (this.canAddSite) {
        this.currentView = "site-list";
        this.fabButtonIconShow = true;
      }
    },

    toggleEditSite(site) {
      if (this.canEditSite || this.canViewSite) {
        if (this.currentView === "site-list") {
          this.currentVModel = site;
          this.currentView = "edit-site";
          this.fabButtonIcon = "arrow_back";
          this.fabButtonIconShow = true;
        } else {
          this.showList();
        }
      } else {
        this.currentView = "no-permissions";
        this.fabButtonIcon = "arrow_back";
        this.fabButtonIconShow = true;
      }
    }
  },
  created() {
    this.setPermissions();
    this.initViewBasedOnPermissions();
  },
  mounted() {},
  beforeDestroy() {}
};
</script>

<style scoped>
.component-fade-enter-active,
.component-fade-leave-active {
  transition: opacity 0.3s ease;
}
.component-fade-enter,
.component-fade-leave-to {
  opacity: 0;
}
</style>