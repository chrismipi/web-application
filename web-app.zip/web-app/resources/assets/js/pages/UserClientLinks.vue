<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs12>
        <transition name="component-fade" mode="out-in">
          <component
            v-bind:is="currentView"
            v-model="currentVModel"
            :user-client-links="userClientLinks"
            v-on:edit="toggleEditUserClientLink"
            v-on:show-list="showList"
            :disabled="!this.canEditUserClientLink"
          ></component>
        </transition>
      </v-flex>
    </v-layout>
    <v-fab-transition v-if="fabButtonIconShow">
      <v-btn fixed dark fab bottom left class="teal" @click="addNewUserClientLink()">
        <v-icon>{{ fabButtonIcon }}</v-icon>
      </v-btn>
    </v-fab-transition>
  </v-container>
</template>

<script>
import UserClientLinkList from "../components/userClientLinks/UserClientLinkList";
import AddUserClientLink from "../components/userClientLinks/AddUserClientLink";
import EditUserClientLink from "../components/userClientLinks/EditUserClientLink";
import { mapGetters } from "vuex";

export default {
  props: {
    userClientLinks: {
      type: Array,
      required: true
    }
  },
  components: {
    UserClientLinkList,
    AddUserClientLink,
    EditUserClientLink
  },
  data: () => ({
    currentView: "no-permissions",
    currentVModel: null,
    fabButtonIcon: "add",
    fabButtonIconShow: false,
    canAddUserClientLink: false,
    canViewUserClientLink: false,
    canEditUserClientLink: false,
    canDeleteUserClientLink: false
  }),
  computed: {
    ...mapGetters({
      permissions: "session/permissions"
    })
  },
  methods: {
    addNewUserClientLink() {
      if (this.canAddUserClientLink) {
        if (this.currentView === "user-client-link-list") {
          this.currentView = "add-user-client-link";
          this.fabButtonIcon = "arrow_back";
        } else {
          if (!this.canViewUserClientLink) {
            this.currentView = "no-permissions";
            this.fabButtonIconShow = false;
          } else {
            this.currentView = "user-client-link-list";
          }

          if (this.canAddUserClientLink) {
            this.fabButtonIcon = "add";
            this.fabButtonIconShow = true;
          } else {
            this.fabButtonIconShow = false;
          }
        }
      } else {
        if (this.canViewUserClientLink) {
          this.currentView = "user-client-link-list";
          this.fabButtonIconShow = false;
          this.fabButtonIcon = "add";
        }
      }
    },

    showList() {
      if (this.canViewUserClientLink) {
        this.currentView = "user-client-link-list";
      } else {
        this.currentView = "no-permissions";
      }

      if (this.canAddUserClientLink) {
        this.fabButtonIcon = "add";
        this.fabButtonIconShow = true;
      } else {
        this.fabButtonIconShow = false;
      }
    },

    setPermissions() {
      this.canAddUserClientLink = window._.find(this.permissions, {
        name: "Add User Client Link"
      })
        ? true
        : false;
      this.canViewUserClientLink = window._.find(this.permissions, {
        name: "View User Client Link"
      })
        ? true
        : false;
      this.canEditUserClientLink = window._.find(this.permissions, {
        name: "Edit User Client Link"
      })
        ? true
        : false;
      this.canDeleteUserClientLink = window._.find(this.permissions, {
        name: "Delete User Client Link"
      })
        ? true
        : false;
    },

    initViewBasedOnPermissions() {
      if (this.canViewUserClientLink) {
        this.currentView = "user-client-link-list";
      }

      if (this.canAddUserClientLink) {
        this.currentView = "user-client-link-list";
        this.fabButtonIconShow = true;
      }
    },

    toggleEditUserClientLink(userClientLink) {
      if (this.canEditUserClientLink || this.canViewUserClientLink) {
        if (this.currentView === "user-client-link-list") {
          this.currentVModel = userClientLink;
          this.currentView = "edit-user-client-link";
          this.fabButtonIcon = "arrow_back";
          this.fabButtonIconShow = true;
        } else {
          this.showList();
        }
      } else {
        this.currentView = "no-permissions";
        this.fabButtonIcon = "arrow_back";
        this.fabButtonIconShow = true;
      }
    }
  },
  created() {
    this.setPermissions();
    this.initViewBasedOnPermissions();
  },
  mounted() {},
  beforeDestroy() {}
};
</script>

<style scoped>
.component-fade-enter-active,
.component-fade-leave-active {
  transition: opacity 0.3s ease;
}
.component-fade-enter,
.component-fade-leave-to {
  opacity: 0;
}
</style>