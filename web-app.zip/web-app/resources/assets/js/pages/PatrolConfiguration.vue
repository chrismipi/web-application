]<template>
	
</template>

<script>

export default {
	props: {
		sites: {
			type: Array,
			required: true,
		},
	},
	data: () => ({
		
	}),
	methods: {
		
	},
	mounted() {
	},
	beforeDestroy () {
	},
}
</script>

<style scoped>

</style>