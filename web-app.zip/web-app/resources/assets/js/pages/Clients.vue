<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs12>
        <transition name="component-fade" mode="out-in">
          <component
            v-bind:is="currentView"
            v-model="currentVModel"
            :clients="clients"
            v-on:edit="toggleEditClient"
            v-on:show-list="showList"
            :disabled="!this.canEditClient"
          ></component>
        </transition>
      </v-flex>
    </v-layout>
    <v-fab-transition v-if="fabButtonIconShow">
      <v-btn fixed dark fab bottom left class="teal" @click="addNewClient()">
        <v-icon>{{ fabButtonIcon }}</v-icon>
      </v-btn>
    </v-fab-transition>
  </v-container>
</template>

<script>
import AddClient from "../components/clients/AddClient";
import EditClient from "../components/clients/EditClient";
import ClientList from "../components/clients/ClientList";
import { mapGetters } from "vuex";

export default {
  props: {
    clients: {
      type: Array,
      required: true
    }
  },
  components: {
    AddClient,
    EditClient,
    ClientList
  },
  data: () => ({
    currentView: "no-permissions",
    currentVModel: null,
    fabButtonIcon: "add",
    fabButtonIconShow: false,
    canAddClient: false,
    canViewClient: false,
    canEditClient: false,
    canDeleteClient: false
  }),
  computed: {
    ...mapGetters({
      permissions: "session/permissions"
    })
  },
  methods: {
    addNewClient() {
      if (this.canAddClient) {
        if (this.currentView === "client-list") {
          this.currentView = "add-client";
          this.fabButtonIcon = "arrow_back";
        } else {
          if (!this.canViewClient) {
            this.currentView = "no-permissions";
            this.fabButtonIconShow = false;
          } else {
            this.currentView = "client-list";
          }

          if (this.canAddClient) {
            this.fabButtonIcon = "add";
            this.fabButtonIconShow = true;
          } else {
            this.fabButtonIconShow = false;
          }
        }
      } else {
        if (this.canViewClient) {
          this.currentView = "client-list";
          this.fabButtonIconShow = false;
          this.fabButtonIcon = "add";
        }
      }
    },

    showList() {
      if (this.canViewClient) {
        this.currentView = "client-list";
      } else {
        this.currentView = "no-permissions";
      }

      if (this.canAddClient) {
        this.fabButtonIcon = "add";
        this.fabButtonIconShow = true;
      } else {
        this.fabButtonIconShow = false;
      }
    },

    setPermissions() {
      this.canAddClient = window._.find(this.permissions, {
        name: "Add Client"
      })
        ? true
        : false;
      this.canViewClient = window._.find(this.permissions, {
        name: "View Client"
      })
        ? true
        : false;
      this.canEditClient = window._.find(this.permissions, {
        name: "Edit Client"
      })
        ? true
        : false;
      this.canDeleteClient = window._.find(this.permissions, {
        name: "Delete Client"
      })
        ? true
        : false;
    },

    initViewBasedOnPermissions() {
      if (this.canViewClient) {
        this.currentView = "client-list";
      }

      if (this.canAddClient) {
        this.currentView = "client-list";
        this.fabButtonIconShow = true;
      }
    },

    toggleEditClient(client) {
      if (this.canEditClient || this.canViewClient) {
        if (this.currentView === "client-list") {
          this.currentVModel = client;
          this.currentView = "edit-client";
          this.fabButtonIcon = "arrow_back";
          this.fabButtonIconShow = true;
        } else {
          this.showList();
        }
      } else {
        this.currentView = "no-permissions";
        this.fabButtonIcon = "arrow_back";
        this.fabButtonIconShow = true;
      }
    }
  },
  created() {
    this.setPermissions();
    this.initViewBasedOnPermissions();
  },
  mounted() {},
  beforeDestroy() {}
};
</script>

<style scoped>
.component-fade-enter-active,
.component-fade-leave-active {
  transition: opacity 0.3s ease;
}
.component-fade-enter,
.component-fade-leave-to {
  opacity: 0;
}
</style>