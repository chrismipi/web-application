<template>
	<v-container grid-list-md text-xs-center>
		<v-layout row wrap>		
			<v-flex xs6 @click="goToPage('/clients')">
				<v-card height="25vh" :hover="true" class="hover-color" v-if="canViewClients">
					<v-card-text class="px-0">Manage Clients</v-card-text>
					<v-card-text class="px-0"><v-icon large>people</v-icon></v-card-text>
				</v-card>
			</v-flex>
			<v-flex xs6 @click="goToPage('/security-companies')" v-if="canViewSecurityCompanies">
				<v-card height="25vh" :hover="true" class="hover-color">
					<v-card-text class="px-0">Manage Security Companies</v-card-text>
					<v-card-text class="px-0"><v-icon large>security</v-icon></v-card-text>
				</v-card>
			</v-flex>
			<v-flex xs6 @click="goToPage('/sites')" v-if="canViewSites">
				<v-card height="25vh" :hover="true" class="hover-color">
					<v-card-text class="px-0">Manage Sites</v-card-text>
					<v-card-text class="px-0"><v-icon large>location_city</v-icon></v-card-text>
				</v-card>
			</v-flex>
			<v-flex xs6 @click="goToPage('/users')" v-if="canViewUsers">
				<v-card height="25vh" :hover="true" class="hover-color">
					<v-card-text class="px-0">Manage Users</v-card-text>
					<v-card-text class="px-0"><v-icon large>person</v-icon></v-card-text>
				</v-card>
			</v-flex>
			<v-flex xs6 @click="goToPage('/active-patrols')">
				<v-card height="25vh" :hover="true" class="hover-color">
					<v-card-text class="px-0">Manage Patrols</v-card-text>
					<v-card-text class="px-0"><v-icon large>directions_walk</v-icon></v-card-text>
				</v-card>
			</v-flex>
		</v-layout>
	</v-container>
</template>

<script>
import { mapGetters } from 'vuex';
export default {
	data: () => ({
		canViewClients: false,
		canViewSecurityCompanies: false,
		canViewSites: false,
		canViewUsers: false,
	}),
	computed: {
		...mapGetters({
			permissions :'session/permissions'
		}),
	},
	methods: {
		goToPage(location){
			window.location = location;
		},

		updatePermissions(){
			this.canViewClients = window._.find(this.permissions, { 'name': 'View Client'}) ? true : false;
			this.canViewSecurityCompanies = window._.find(this.permissions, { 'name': 'View Security Company'}) ? true : false;
			this.canViewSites = window._.find(this.permissions, { 'name': 'View Site'}) ? true : false;

			if(window._.find(this.permissions, { 'name': 'View Admin'}) ||
				window._.find(this.permissions, { 'name': 'View Operator'}) ||
				window._.find(this.permissions, { 'name': 'View Client'}) ){
				this.canViewUsers = true;
			}
		},
	},
	mounted() {
		this.updatePermissions();
	},
	beforeDestroy () {
	},
	watch: {
		permissions: {
			handler: function(newValue) {
				this.updatePermissions()
			},
			deep: true
		},
	},
}
</script>

<style scoped>
.hover-color{
	-moz-transition: all .2s ease-in;
	-o-transition: all .2s ease-in;
	-webkit-transition: all .2s ease-in;
	transition: all .2s ease-in;
}

.hover-color:hover{
	background: #4db6ac!important;
}
</style>