<template>
	<v-container grid-list-md text-xs-center>
		<v-layout row wrap>
			<!-- <v-flex xs6>
				<v-card height="25vh">
					<v-card-text class="px-0">Active Patrols</v-card-text>
					<v-card-text>{{ patrols.active.length }}</v-card-text>
				</v-card>
			</v-flex>
			<v-flex xs6>
				<v-card height="25vh">
					<v-card-text class="px-0">Upcomming Patrols</v-card-text>
					<v-card-text>{{ patrols.upcomming.length }}</v-card-text>
				</v-card>
			</v-flex>
			<v-flex xs4>
				<v-card height="25vh">
					<v-card-text class="px-0">Completed Trips This Week</v-card-text>
					<v-card-text>{{ patrols.counts.tripsThisWeek }}</v-card-text>
				</v-card>
			</v-flex>
			<v-flex xs4>
				<v-card height="25vh">
					<v-card-text class="px-0">Panic Alerts This Week</v-card-text>
					<v-card-text>{{ patrols.counts.alerts }}</v-card-text>
				</v-card>
			</v-flex>
			<v-flex xs4>
				<v-card height="25vh">
					<v-card-text class="px-0">Call Me's This Week</v-card-text>
					<v-card-text>{{ patrols.counts.callMe }}</v-card-text>
				</v-card>
			</v-flex> -->
		</v-layout>
	</v-container>
</template>

<script>

export default {
	props: {
		active: {
			type: Object,
			required: false,
		},
	},
	data: () => ({
		
	}),
	methods: {
		
	},
	mounted() {
	},
	beforeDestroy () {
	},
}
</script>

<style scoped>

</style>