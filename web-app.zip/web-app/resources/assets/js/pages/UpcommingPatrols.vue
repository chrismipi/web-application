<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs12>
        <v-card>
          <v-card-title>
            <v-spacer></v-spacer>
            <v-text-field
              append-icon="search"
              label="Search"
              single-line
              hide-details
              v-model="search"
            ></v-text-field>
          </v-card-title>
          <v-data-table v-bind:headers="headers" v-bind:items="items" v-bind:search="search">
            <template slot="items" slot-scope="props">
              <td>{{ props.item.start_time }}</td>
              <td class="text-xs-right">{{ props.item.end_time }}</td>
              <td class="text-xs-right">{{ props.item.site.name }}</td>
              <td class="text-xs-right">{{ props.item.site.address }}</td>
            </template>
          </v-data-table>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
export default {
  props: {
    patrols: {
      type: Array,
      required: true
    }
  },
  data: () => ({
    search: "",
    headers: [
      {
        text: "Starting At",
        align: "left",
        sortable: false,
        value: "start_time"
      },
      { text: "Ends At", value: "end_time" },
      { text: "Site", value: "site.name" },
      { text: "Address", value: "site.address" }
    ],
    items: []
  }),
  methods: {
    prepData() {
      this.items = this.patrols;
      this.items.forEach(patrol => {});
    }
  },
  mounted() {
    this.prepData();
  },
  beforeDestroy() {}
};
</script>

<style scoped>
</style>
