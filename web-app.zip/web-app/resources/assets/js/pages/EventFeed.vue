<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs12>
        <h5 v-if="event">Event Details</h5>
        <transition name="component-fade" mode="out-in">
          <event-feed-detail v-if="event" v-model="event" v-on:mute-event="muteEvent"></event-feed-detail>
        </transition>
      </v-flex>
      <v-flex xs12>
        <transition name="component-fade" mode="out-in">
          <event-feed-list
            v-if="events"
            v-model="events"
            :events="events"
            v-on:show-event-detail="showEventDetail"
          ></event-feed-list>
        </transition>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
import EventFeedDetail from "../components/eventFeed/EventFeedDetail";

export default {
  props: {
    currentEvent: {
      type: Object,
      required: false
    },
    events: {
      type: Array,
      required: false
    }
  },
  components: {
    EventFeedDetail
  },
  data: () => ({
    event: null
  }),
  methods: {
    muteEvent(notification) {
      this.$store.dispatch("session/removeNotification", notification);
      this.event = null;
    },
    showList() {
      this.$emit("show-event", true);
    },
    showEventDetail(notification) {
      this.event = notification;
    }
  },
  mounted() {
    this.event = this.currentEvent;
  },
  beforeDestroy() {}
};
</script>

<style scoped>
</style>