]<template>
  <v-card>
    <v-card-title>
      <v-spacer></v-spacer>
      <v-text-field append-icon="search" label="Search" single-line hide-details v-model="search"></v-text-field>
    </v-card-title>
    <v-data-table v-bind:headers="headers" v-bind:items="items" v-bind:search="search">
      <template slot="items" slot-scope="props">
        <td>{{ props.item.name }}</td>
        <td class="text-xs-right">{{ props.item.email }}</td>
        <td class="text-xs-right">{{ props.item.contact_number }}</td>
        <td class="text-xs-right">{{ props.item.alternative_contact_number }}</td>
        <td class="text-xs-right">
          <v-chip
            small
            v-for="(role, index) in props.item.associated_roles"
            :class="getChipClass(role.text)"
            :key="index"
            color="green"
            text-color="white"
          >{{ role.text }}</v-chip>
        </td>
        <td class="text-xs-right">
          <v-menu bottom right>
            <v-btn icon slot="activator" light>
              <v-icon>more_vert</v-icon>
            </v-btn>
            <v-list>
              <v-list-tile
                v-for="(action, key) in props.item.actions"
                :key="key"
                @click.native="performActionOnUser(action.name, props.item)"
              >
                <v-list-tile-title>{{ action.name }}</v-list-tile-title>
              </v-list-tile>
            </v-list>
          </v-menu>
        </td>
      </template>
      <template
        slot="pageText"
        slot-scope="{ pageStart, pageStop }"
      >From {{ pageStart }} to {{ pageStop }}</template>
    </v-data-table>
    <delete-user
      v-if="modal.delete.show"
      v-model="modal.delete.data"
      v-on:close-dialog="closeDialog()"
    ></delete-user>
  </v-card>
</template>

<script>
import DeleteUser from './DeleteUser';
import { mapGetters } from 'vuex';

export default {
  props: {
    users: {
      type: Array,
      required: true,
    },
  },
  components: {
    DeleteUser,
  },
  data: () => ({
    search: '',
    headers: [
      {
        text: 'Name',
        align: 'left',
        sortable: false,
        value: 'name'
      },
      { text: 'Address', value: 'email' },
      { text: 'Contact No', value: 'contact_number' },
      { text: 'Alt Contact No', value: 'alternative_contact_number' },
      { text: 'Roles', value: 'associated_roles' },
      { text: '', value: 'actions' },
    ],
    items: [],
    modal: {
      delete: {
        data: {},
        show: false,
      },
      edit: {
        data: {},
        show: false,
      }
    },
    canEditUser: false,
    canDeleteUser: false,
    userRoles: [],
    sitesTotal: 0,
  }),
  computed: {
    ...mapGetters({
      permissions: 'session/permissions',
    }),
  },
  methods: {
    closeDialog() {
      for (const field in this.modal) {
        this.modal[field].show = false;
      }
    },

    getChipClass(roleName) {
      return window._.kebabCase(roleName);
    },

    performActionOnUser(actionName, user) {
      if (actionName === 'Edit' || actionName === 'View') {
        this.$emit('edit', user);
      } else {
        this.modal[window._.camelCase(actionName)].data = user;
        this.modal[window._.camelCase(actionName)].show = true;
      }
    },

    prepData() {
      if (window._.find(this.permissions, { 'name': 'Edit Admin' }) ||
        window._.find(this.permissions, { 'name': 'Edit Operator' }) ||
        window._.find(this.permissions, { 'name': 'Edit Client' })) {
        this.canEditUser = true
      }

      if (window._.find(this.permissions, { 'name': 'Delete Admin' }) ||
        window._.find(this.permissions, { 'name': 'Delete Operator' }) ||
        window._.find(this.permissions, { 'name': 'Delete Client' })) {
        this.canDeleteUser = true;
      }

      this.users.forEach((user) => {
        // Dont list or display device users
        if (window._.findIndex(user.associated_roles, ['text', 'Device User'])) {
          user['name'] = `${user.first_name} ${user.last_name}`;
          user['actions'] = [];

          if (this.canEditUser) {
            user['actions'].push({
              name: 'Edit',
            });
          } else {
            user['actions'].push({
              name: 'View',
            });
          }

          if (this.userRoles.indexOf("Super Admin") !== -1 && user.can_delete) {
            user['actions'].push({
              name: 'Delete',
            });
          }

          this.items.push(user);
        }
      });
    },
  },
  mounted() {
    this.prepData();
  },
  created() {
    this.userRoles = this.$store.getters['session/userRoles'];
  },
  beforeDestroy() {
  },
}
</script>

<style scoped>
.super-admin {
  color: white !important;
  background-color: red !important;
  border-color: red !important;
}

.admin {
  color: white !important;
  background-color: orange !important;
  border-color: orange !important;
}

.operator {
  color: white !important;
  background-color: blue !important;
  border-color: blue !important;
}

.client-owner {
  color: white !important;
  background-color: #4caf50 !important;
  border-color: #4caf50 !important;
}

.security-company-owner {
  color: white !important;
  background-color: purple !important;
  border-color: purple !important;
}
</style>
