<template>

  <v-card class="mb-5">
    <v-card-title>Add New User</v-card-title>
    <v-card-text>
      <user-form v-model="user" :editable-roles="true" v-on:formisvalid="updateUserFormValidation"></user-form>
      <v-btn color="teal" @click.native="createNewUser()" :disabled="!formValid">Create User</v-btn>
      <v-btn @click="clear">clear</v-btn>
    </v-card-text>
  </v-card>
</template>

<script>
  import User from '../../models/User';
  import { EventBus } from '../../utils/event-bus';
  import UserForm from './UserForm';

  export default {
    components: {
      UserForm,
    },
    data: () => ({
      user: {},
      formValid: false,
    }),
    methods: {
      submit () {
        this.$validator.validateAll()
      },

      clear () {
        this.name = ''
        this.email = ''
        this.select = null
        this.checkbox = null
        this.$validator.reset()
      },

      createNewUser (){
        console.log('USER: ', this.user);
        debugger;
        axios.put(`/api/user/`, {
          user: this.user,
        })
        .then((response) => {
          debugger;
          EventBus.$emit('notify', 'success', 'User successfully created!');
          setTimeout(() => {
            window.location.reload();
          }, 2500);
        })
        .catch((error) => {
          debugger;
          let errorMessages = [];
          for (const errorMessage in error.response.data.errors) {
            errorMessages.push(error.response.data.errors[errorMessage]);
          }

          EventBus.$emit('notify', 'error', `Error creating user: ${errorMessages}`);
        });
      },

      updateUserFormValidation (validationStatus){
        this.formValid = validationStatus;
      },
    },
    mounted() {
      this.user = () => new User();
    },
  }
</script>
