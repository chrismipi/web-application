<template>
  <v-layout row justify-center>
    <v-card>
      <v-card-title>
        <span class="headline">User Profile</span>
      </v-card-title>
      <v-card-text>
        <span class="subtitle">User Details</span>
        <user-form v-model="user" :disabled="disabled"></user-form>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn color="blue darken-1" flat @click.native="showList()">Close</v-btn>
        <v-btn color="blue darken-1" flat @click.native="saveUser()" v-if="!disabled">Save</v-btn>
        <v-spacer></v-spacer>
      </v-card-actions>
    </v-card>
  </v-layout>
</template>

<script>
import User from '../../models/User';
import { EventBus } from '../../utils/event-bus';
import UserForm from './UserForm';

export default {
  props: {
    value: {
      type: Object,
      required: true,
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false,
    }
  },
  components: {
    UserForm,
  },
  data: () => ({
    user: {},
    dialog: true,
    user: {},
  }),
  methods: {
    showList() {
      this.$emit('show-list', true);
    },

    saveUser() {
      axios.post(`/api/user/${this.user.id}`, this.user)
      .then((response) => {
        // User successfully created
        EventBus.$emit('notify', 'success', 'User successfully updated!');
        // this.showList();
        setTimeout(() => {
          window.location.reload();
        }, 2500);
      })
      .catch((error) => {
        let errorMessages = [];
        for (const errorMessage in error.response.data.errors) {
          errorMessages.push(error.response.data.errors[errorMessage]);
        }
        // User could not be created
        EventBus.$emit('notify', 'error', `Error updating user: ${errorMessages}`);
      });
    },
  },
  created() {
    this.user = new User(this.value);
  },
  watch: {
    
  },
}
</script>

<style scoped>
.subtitle {
  font-size: 22px!important;
  font-weight: 300;
  line-height: 32px!important;
  letter-spacing: normal!important;
}
.card{
  width: 100% !important;
}
</style>