<template>
    <form>
        <v-text-field v-model="user.first_name" label="First Name" :error-messages="errors.collect('first_name')"
                      v-validate="'required'" data-vv-name="first_name" required :disabled="disabled"></v-text-field>
        <v-text-field v-model="user.last_name" label="Last Name" :error-messages="errors.collect('last_name')"
                      v-validate="'required'" data-vv-name="last_name" required :disabled="disabled"></v-text-field>
        <v-text-field v-model="user.password" label="Password" :error-messages="errors.collect('password')"
                      v-validate="'required'" data-vv-name="password" required :disabled="disabled"
                      :append-icon="showPassword ? 'visibility' : 'visibility_off'"
                      :append-icon-cb="() => (showPassword = !showPassword)"
                      :type="showPassword ? 'password' : 'text'"></v-text-field>
        <v-text-field v-model="user.email" label="Email" :error-messages="errors.collect('email')"
                      v-validate="'required|email'" data-vv-name="email" required :disabled="disabled"></v-text-field>
        <v-text-field v-model="user.contact_number" label="Contact Number"
                      :error-messages="errors.collect('contact_number')" v-validate="'required'"
                      data-vv-name="contact_number" required :disabled="disabled"></v-text-field>
        <v-text-field v-model="user.alternative_contact_number" required label="Alternative Contact Number"
                      :error-messages="errors.collect('alternative_contact_number')" 
                      data-vv-name="alternative_contact_number"  :disabled="disabled"></v-text-field>
        <v-select label="User Role(s)" :items="rolesList" v-model="user.associated_roles" multiple chips
                  hint="The role(s) assigned to this user." persistent-hint prepend-icon="vpn_key" item-text="name"
                  item-value="id" :disabled="!editableRoles || disabled" v-validate="'required'"
                  data-vv-name="associated_roles" required></v-select>
    </form>
</template>

<script>
    import User from '../../models/User';
    import {EventBus} from '../../utils/event-bus';

    export default {
        props: {
            value: {
                // type: Object || Function,
                required: true,
            },
            disabled: {
                type: Boolean,
                required: false,
                default: false,
            },
            editableRoles: {
                type: Boolean,
                required: false,
                default: true,
            },
            defaultRoles: {
                type: Array,
                required: false,
                default: () => [],
            },
        },
        data: () => ({
            user: {},
            // roles: [],
            rolesList: [],
            showPassword: false,
        }),
        methods: {
            submit() {
                this.$validator.validateAll()
            },

            clear() {
                this.name = ''
                this.email = ''
                this.password = ''
                this.select = null
                this.checkbox = null
                this.$validator.clean()
            },

            loadRoles() {
               axios.get(`/api/roles/${this.$store.getters['session/userRoles'][0]}`)
                    .then((response) => {
                        this.rolesList = response.data.roles;
                        this.setDefaultRoles();
                    })
                    .catch((error) => {
                        EventBus.$emit('notify', 'error', 'Roles could not be retrieved. Please try again later.');
                    })
                    .then(() => {
                        this.$validator.validateAll();
                    });
            },

            setDefaultRoles() {
                this.defaultRoles.forEach((role) => {
                      this.user.associated_roles.push(role);                   
                });
            },
        },
        created() {
            this.loadRoles();
        },
        mounted() {
            this.user = new User(this.value);
        },
        watch: {
            user: {
                handler: function (newValue) {
                    this.$emit('input', this.user);

                    this.$validator.validateAll()
                        .then(result => {
                            this.$emit('formisvalid', result);
                        });
                },
                deep: true
            },
        }
    }
</script>
