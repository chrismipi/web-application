<template>
  <v-dialog v-model="dialog" lazy persistent max-width="450px">
    <v-card>
      <v-card-title class="headline">Delete {{ user.first_name }} {{ user.last_name }}</v-card-title>
      <v-card-text>
        <v-alert warning="true" v-bind:value="true">You are about to delete {{ user.first_name }} {{ user.last_name }}. Note that the user information will still be kept for record keeping.</v-alert>
      </v-card-text>
      <v-card-text>Are you sure you want to delete {{ user.first_name }} {{ user.last_name }}?</v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn class="grey--text darken-1" flat @click.native="closeDialog()">Cancel</v-btn>
        <v-btn class="red" @click.native="deleteUser()">Delete</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import User from '../../models/User';
import { EventBus } from '../../utils/event-bus';

export default {
  props: {
    value: {
      type: Object,
      required: true,
    },
  },
  data: () => ({
    user: {},
    dialog: true,
    user: {},
  }),
  methods: {
    closeDialog() {
      this.$emit('close-dialog', true);
    },

    deleteUser() {
      axios.delete(`/api/user/${this.user.id}`)
      .then((response) => {
        // User successfully deleted
        EventBus.$emit('notify', 'success', 'User successfully deleted!');
        setTimeout(() => {
          window.location.reload();
        }, 2500);
      })
      .catch((error) => {
        let errorMessages = [];
        for (const errorMessage in error.response.data.errors) {
          errorMessages.push(error.response.data.errors[errorMessage]);
        }
        // User could not be deleted
        EventBus.$emit('notify', 'error', `Error deleting user: ${errorMessages}`);
      });
    },
  },
  created() {
    this.user = new User(this.value);
  },
  watch: {
    
  },
}
</script>

<style scoped>
.subtitle {
  font-size: 22px!important;
  font-weight: 300;
  line-height: 32px!important;
  letter-spacing: normal!important;
}
</style>