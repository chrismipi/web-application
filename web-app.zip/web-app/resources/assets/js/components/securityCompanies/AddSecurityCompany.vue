<template>
  <v-stepper v-model="e1">
    <v-stepper-header>
      <v-stepper-step step="1" :complete="e1 > 1">Setup User</v-stepper-step>
      <v-divider></v-divider>
      <v-stepper-step step="2" :complete="e1 > 2">Setup Security Company</v-stepper-step>
      <v-divider></v-divider>
      <v-stepper-step step="3">Review</v-stepper-step>
    </v-stepper-header>
    <v-stepper-content step="1">
      <v-switch v-bind:label="`Create New User`" v-model="creatingNewUser"></v-switch>
      <v-text-field
        v-if="!creatingNewUser"
        v-model="newUserEmail"
        label="Enter Email Address of Existing User"
        :error-messages="errors.collect('newUserEmail')"
        v-validate="'required|email'"
        data-vv-name="newUserEmail"
        required
      ></v-text-field>
      <user-form
        v-else
        v-model="user"
        v-on:formisvalid="updateUserFormValidation"
        :editable-roles="false"
        :default-roles="defaultUserRoles"
      ></user-form>
      <v-btn color="teal" @click.native="e1 = 2" :disabled="!formValid.stepOne">Continue</v-btn>
    </v-stepper-content>
    <v-stepper-content step="2">
      <security-company-form
        v-model="securityCompany"
        v-on:formisvalid="updateSecurityCompanyFormValidation"
      ></security-company-form>
      <v-btn color="teal" @click.native="e1 = 3" :disabled="!formValid.stepTwo">Continue</v-btn>
      <v-btn flat @click.native="e1 = 1">Back</v-btn>
    </v-stepper-content>
    <v-stepper-content step="3">
      <v-card color="teal lighten-5" class="mb-5">
        <v-card-title>Security Company Manager Details</v-card-title>
        <v-card-text>
          <user-form
            v-model="user"
            v-if="formValid.stepTwo"
            v-on:formisvalid="updateUserFormValidation"
            :disabled="true"
          ></user-form>
        </v-card-text>
      </v-card>
      <v-card color="teal lighten-5" class="mb-5">
        <v-card-title>Security Company Details</v-card-title>
        <v-card-text>
          <security-company-form
            v-if="formValid.stepTwo"
            v-model="securityCompany"
            :disabled="true"
          ></security-company-form>
        </v-card-text>
      </v-card>
      <v-btn
        color="teal"
        @click.native="createNewClinet()"
        :disabled="!formValid.stepOne || !formValid.stepTwo"
      >Create Security Company</v-btn>
      <v-btn flat @click.native="e1 = 2">Back</v-btn>
    </v-stepper-content>
  </v-stepper>
</template>

<script>
import User from "../../models/User";
import SecurityCompany from "../../models/SecurityCompany";
import { EventBus } from "../../utils/event-bus";
import SecurityCompanyForm from "./SecurityCompanyForm";

export default {
  data: () => ({
    creatingNewUser: false,
    defaultUserRoles: [4],
    securityCompany: {},
    e1: 0,
    formValid: {
      stepOne: false,
      stepTwo: false
    },
    newUserEmail: "",
    user: {}
  }),
  components: {
    SecurityCompanyForm
  },
  methods: {
    createNewClinet() {
      axios
        .put(`/api/security-company/`, {
          user: this.user,
          securityCompany: this.securityCompany
        })
        .then(response => {
          // Security Company successfully created
          EventBus.$emit(
            "notify",
            "success",
            "Security Company successfully created!"
          );
          setTimeout(() => {
            window.location.reload();
          }, 2500);
        })
        .catch(error => {
          let errorMessages = [];
          for (const errorMessage in error.response.data.errors) {
            errorMessages.push(error.response.data.errors[errorMessage]);
          }
          // Security Company could not be created
          EventBus.$emit(
            "notify",
            "error",
            `Error creating security company: ${errorMessages}`
          );
        });
    },

    updateUserFormValidation(validationStatus) {
      this.formValid.stepOne = validationStatus;
    },

    updateSecurityCompanyFormValidation(validationStatus) {
      this.formValid.stepTwo = validationStatus;
    }
  },
  mounted() {
    this.user = () => new User();
    this.securityCompany = () => new SecurityCompany();
  },
  watch: {
    newUserEmail: function(newVal) {
      if (!this.creatingNewUser) {
        this.$validator.validateAll().then(result => {
          if (result) {
            // Set the user model with the user from the DB....
            axios
              .get(`/api/user/verify/${this.newUserEmail}`)
              .then(response => {
                if (!response.data.user) {
                  // Notify email does not exist
                  EventBus.$emit(
                    "notify",
                    "error",
                    `User with email ${this.newUserEmail} does not exist.`
                  );
                  this.updateUserFormValidation(false);
                } else {
                  EventBus.$emit(
                    "notify",
                    "error",
                    `User found: ${response.data.user.first_name} ${response.data.user.last_name}.`
                  );
                  // Email does exist, populate the user object...
                  this.user = response.data.user;
                  this.updateUserFormValidation(true);
                }
              })
              .catch(error => {
                EventBus.$emit(
                  "notify",
                  "error",
                  "Could not add security company"
                );
              });
          }
        });
      }
    }
  }
};
</script>
