<template>
  <form>
    <v-text-field v-model="securityCompany.name" label="Security Company Name" :error-messages="errors.collect('name')" v-validate="'required'" data-vv-name="name" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="securityCompany.contact_number" label="Contact Number"
                      :error-messages="errors.collect('contact_number')" v-validate="'required'"
                      data-vv-name="contact_number" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="securityCompany.alternative_contact_number" label="Alternative Contact Number"
                      :error-messages="errors.collect('alternative_contact_number')" 
                      data-vv-name="alternative_contact_number" required :disabled="disabled"></v-text-field>
  </form>
</template>

<script>
import SecurityCompany from '../../models/SecurityCompany';

export default {
  props: {
    value: {
      required: true,
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false,
    }
  },
  data: () => ({
    securityCompany: {},
  }),
  methods: {
    submit () {
      this.$validator.validateAll()
    },

    clear () {
      this.securityCompany.name = ''
      this.securityCompany.address = ''
      this.$validator.clean()
    },
  },
  created() {
    this.securityCompany = new SecurityCompany(this.value);
  },
  watch: {
    securityCompany: {
      handler: function(newValue) {
        this.$emit('input', this.securityCompany);
        this.$validator.validateAll()
        .then(result => {
          this.$emit('formisvalid', result);
        });
      },
      deep: true
    },
  }
}
</script>
