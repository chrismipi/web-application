<template>
  <v-layout row justify-center>
    <v-card>
      <v-card-title>
        <span class="headline">Security Company Profile</span>
      </v-card-title>
      <v-card-text>
        <span class="subtitle">Security Company Manager</span>
        <user-form v-model="user" :disabled="true"></user-form>
      </v-card-text>
      <v-card-text>
        <span class="subtitle">Security Company Details</span>
        <security-company-form v-model="securityCompany" :disabled="disabled"></security-company-form>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn color="blue darken-1" flat @click.native="showList()">Close</v-btn>
        <v-btn color="blue darken-1" flat @click.native="saveSecurityCompany()" v-if="!disabled">Save</v-btn>
        <v-spacer></v-spacer>
      </v-card-actions>
    </v-card>
  </v-layout>
</template>

<script>
import SecurityCompany from '../../models/SecurityCompany';
import User from '../../models/User';
import { EventBus } from '../../utils/event-bus';
import SecurityCompanyForm from './SecurityCompanyForm';
import UserForm from '../users/UserForm';

export default {
  props: {
    value: {
      type: Object,
      required: true,
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false,
    }
  },
  components: {
    SecurityCompanyForm,
    UserForm,
  },
  data: () => ({
    securityCompany: {},
    dialog: true,
    user: {},
  }),
  methods: {
    showList() {
      this.$emit('show-list', true);
    },

    saveSecurityCompany() {
      axios.post(`/api/security-company/${this.securityCompany.id}`, this.securityCompany)
      .then((response) => {
        // Security Company successfully created
        EventBus.$emit('notify', 'success', 'Security Company successfully updated!');
        // this.showList();
        setTimeout(() => {
          window.location.reload();
        }, 2500);
      })
      .catch((error) => {
        let errorMessages = [];
        for (const errorMessage in error.response.data.errors) {
          errorMessages.push(error.response.data.errors[errorMessage]);
        }
        // Security Company could not be created
        EventBus.$emit('notify', 'error', `Error updating security company: ${errorMessages}`);
      });
    },
  },
  created() {
    this.securityCompany = new SecurityCompany(this.value);
    this.user = new User(this.value.manager);
  },
  watch: {
    
  },
}
</script>

<style scoped>
.subtitle {
  font-size: 22px!important;
  font-weight: 300;
  line-height: 32px!important;
  letter-spacing: normal!important;
}
.card{
  width: 100% !important;
}
</style>