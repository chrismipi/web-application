<template>
  <v-card>
    <v-card-title>
      <v-spacer></v-spacer>
      <v-text-field append-icon="search" label="Search" single-line hide-details v-model="search"></v-text-field>
    </v-card-title>
    <v-data-table v-bind:headers="headers" v-bind:items="items" v-bind:search="search">
      <template slot="items" slot-scope="props">
        <td>{{ props.item.name }}</td>
        <td class="text-xs-right">{{ props.item.fullName }}</td>
        <td class="text-xs-right">{{ props.item.contactNumber }}</td>
        <td class="text-xs-right">{{ props.item.alternativeContactNumber }}</td>
        <td class="text-xs-right">{{ props.item.siteCount }}</td>
        <td class="text-xs-right">
          <v-menu bottom right>
            <v-btn icon slot="activator" light>
              <v-icon>more_vert</v-icon>
            </v-btn>
            <v-list>
              <v-list-tile
                v-for="(action, key) in props.item.actions"
                :key="key"
                @click.native="performActionOnSecurityCompany(action.name, props.item)"
              >
                <v-list-tile-title>{{ action.name }}</v-list-tile-title>
              </v-list-tile>
            </v-list>
          </v-menu>
        </td>
      </template>
      <template
        slot="pageText"
        slot-scope="{ pageStart, pageStop }"
      >From {{ pageStart }} to {{ pageStop }}</template>
    </v-data-table>
    <delete-security-company
      v-if="canDeleteSecurityCompany && modal.delete.show"
      v-model="modal.delete.data"
      v-on:close-dialog="closeDialog()"
    ></delete-security-company>
  </v-card>
</template>

<script>
import DeleteSecurityCompany from './DeleteSecurityCompany';
import { mapGetters } from 'vuex';

export default {
  props: {
    securityCompanies: {
      type: Array,
      required: true,
    },
  },
  components: {
    DeleteSecurityCompany,
  },
  data: () => ({
    search: '',
    headers: [
      {
        text: 'Name',
        align: 'left',
        sortable: false,
        value: 'name'
      },
      { text: 'Manager', value: 'fullName' },
      { text: 'Contact Number', value: 'contactNumber' },
      { text: 'Alt Contact No', value: 'alternativeContactNumber' },
      { text: '# Sites', value: 'siteCount' },
      { text: '', value: 'actions' },
    ],
    items: [],
    modal: {
      delete: {
        data: {},
        show: false,
      },
      edit: {
        data: {},
        show: false,
      }
    },
    canEditSecurityCompany: false,
    canDeleteSecurityCompany: false,
  }),
  computed: {
    ...mapGetters({
      permissions: 'session/permissions'
    }),
  },
  methods: {
    closeDialog() {
      for (const field in this.modal) {
        this.modal[field].show = false;
      }
    },

    performActionOnSecurityCompany(actionName, securityCompany) {
      if (actionName === 'Edit' || actionName === 'View') {
        this.$emit('edit', securityCompany);
      } else {
        this.modal[window._.camelCase(actionName)].data = securityCompany;
        this.modal[window._.camelCase(actionName)].show = true;
      }
    },

    prepData() {
      this.canEditSecurityCompany = window._.find(this.permissions, { 'name': 'Edit Security Company' }) ? true : false;
      this.canDeleteSecurityCompany = window._.find(this.permissions, { 'name': 'Delete Security Company' }) ? true : false;

      this.items = this.securityCompanies;
      this.items.forEach((securityCompany) => {
        securityCompany['fullName'] = `${securityCompany.manager.first_name} ${securityCompany.manager.last_name}`;
        securityCompany['contactNumber'] = securityCompany.contact_number;
        securityCompany['alternativeContactNumber'] = securityCompany.alternative_contact_number;
        securityCompany['siteCount'] = securityCompany.sites.length;
        securityCompany['actions'] = [];

        if (this.canEditSecurityCompany) {
          securityCompany['actions'].push({
            name: 'Edit',
          });
        } else {
          securityCompany['actions'].push({
            name: 'View',
          });
        }

        if (this.canDeleteSecurityCompany && securityCompany.sites.length === 0) {
          securityCompany['actions'].push({
            name: 'Delete',
          });
        }
      });
    },
  },
  mounted() {
    this.prepData();
  },
  beforeDestroy() {
  },
}
</script>

<style scoped>
</style>
