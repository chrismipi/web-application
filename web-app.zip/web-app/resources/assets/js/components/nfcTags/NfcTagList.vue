<template>
  <v-layout row wrap>
    <v-flex xs12>
      <v-list>
        <template v-for="(nfcTag,index) in nfcTags">
          <v-list-tile avatar v-bind:key="nfcTag.title">
            <v-list-tile-avatar>
              <v-icon large class="teal--text lighten-2">nfc</v-icon>
            </v-list-tile-avatar>
            <v-list-tile-content>
              <v-list-tile-title>#{{ getTagSequence(nfcTag.sequence_no) }}</v-list-tile-title>
              <v-list-tile-title>
                <small>{{ nfcTag.serial_no }}</small>
              </v-list-tile-title>
            </v-list-tile-content>
            <v-list-tile-action>
              <v-btn icon ripple @click="removeTag(index)" :disabled="disabled">
                <v-icon color="red lighten-2">clear</v-icon>
              </v-btn>
            </v-list-tile-action>
          </v-list-tile>
          <v-divider v-if="nfcTags.length > 1" v-bind:inset="false"></v-divider>
        </template>
      </v-list>
    </v-flex>
  </v-layout>
</template>

<script>
import NfcTag from '../../models/NfcTag';
import { EventBus } from '../../utils/event-bus';

export default {
  props: {
    value: {
      type: Array,
      required: true,
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false,
    },
  },
  data: () => ({
    nfcTags: [],
  }),
  methods: {
    removeTag(index) {
      const tag = this.nfcTags[index];
      axios.delete(`/api/tag/${tag.id}`)
        .then(() => {
          this.nfcTags.splice(this.nfcTags, 1);
          EventBus.$emit('notify', 'success', 'Site successfully deleted!');
        })
        .catch((error) => {
          let errorMessages = [];
          for (const errorMessage in error.response.data.errors) {
            errorMessages.push(error.response.data.errors[errorMessage]);
          }
          EventBus.$emit('notify', 'error', `Error deleting tag: ${errorMessages}`);
        });
    },
    getTagSequence(tag) {
      switch (tag) {
        case -1: {
          return 'Last';
        }
        case 0: {
          return 'First';
        }
          defaul: {
            return tag;
          }
      };
    },
  },
  created() {
    this.value.forEach((nfcTag) => {
      this.nfcTags.push(new NfcTag(nfcTag));
    });
  },
  watch: {
    value: {
      handler: function (newValue) {
        this.nfcTags = newValue;
      },
      deep: true
    },
    nfcTags: {
      handler: function (newValue) {
        this.$emit('input', this.nfcTags);
      },
      deep: true
    },
  }
}
</script>

<style scoped>
</style>
