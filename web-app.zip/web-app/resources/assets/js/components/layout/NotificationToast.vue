<template>
	<v-snackbar :bottom="true" :timeout="timeout" :success="context === 'success'" :info="context === 'info'" :warning="context === 'warning'" :error="context === 'error'" :primary="context === 'primary'" :secondary="context === 'secondary'" v-model="visible">
		{{ text }}
		<v-btn dark flat @click.native="visible = false">Close</v-btn>
	</v-snackbar>
</template>

<script>
import { EventBus } from '../../utils/event-bus';

export default {
	data: () => ({
		visible: false,
		context: '',
		timeout: 6000,
		text: '',
	}),
	mounted() {
		EventBus.$on('notify', (type, message) => {
			this.text = message;
			this.context = type;
			this.visible = true;
		});
	},
}
</script>
