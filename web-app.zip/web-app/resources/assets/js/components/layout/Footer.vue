<template>
	<v-footer app fixed
			  class="font-weight-medium pull-right">
		&copy; {{ currentYear }} {{ appName }}. Powered by <strong><a href="http://www.tharageconsulting.co.za/">Tharage Consulting (Pty) Ltd.</a></strong>
	</v-footer>
</template>

<script>
export default {
	data: () => ({
		appName: 'Dycom Radio',
		currentYear: new Date().getFullYear(),
	}),
}
</script>
