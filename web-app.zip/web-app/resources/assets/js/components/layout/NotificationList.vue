<template>
	<v-list dense>
		<v-list-tile>
			<v-list-tile-content>
				<v-list-tile-title>Notifications</v-list-tile-title>
			</v-list-tile-content>
		</v-list-tile>
		<v-list-tile :class="generateStyle(notification.context)" v-for="(notification,index) in notifications" :key="index" @click.stop="openNotification(notification)">
			<v-list-tile-action>
				<v-icon>{{ notification.icon }}</v-icon>
			</v-list-tile-action>
			<v-list-tile-content>
				<v-list-tile-title>{{ notification.title }} <small class="event-time">{{ notification.eventTime }}</small></v-list-tile-title>
			</v-list-tile-content>
		</v-list-tile>
	</v-list>
</template>

<script>
export default {
  data: () => ({
    notifications: [
    {
      context: 'error',
      details: 'Panic Alert at 4 Pieter Wenning Road @ 18h00',
      eventTime: '5 Min Ago',
      icon: 'add_alert',
      title: 'Guard Panic Alert',
    },
    {
      context: 'info',
      details: 'Gaurd has signed in at 4 Pieter Wenning Road @ 18h00',
      eventTime: '10 Min Ago',
      icon: 'info',
      title: 'Guard Sign In',
    },
    {
      context: 'info',
      details: 'Gaurd has signed in at 4 Pieter Wenning Road @ 18h00',
      eventTime: '1 Hour Ago',
      icon: 'info',
      title: 'Guard Sign In',
    },
    ],
  }),
  methods: {
    generateStyle(context) {
      return {
        red: context === 'error',
        blue: context === 'info',
        'lighten-4': true,
        'margined-list-tile': true,
      };
    },
    openNotification(notification){
    },
  },
}
</script>

<style scoped>
.margined-list-tile{
  margin-bottom: 5px;
}

.event-time{
  float: right;
}
</style>