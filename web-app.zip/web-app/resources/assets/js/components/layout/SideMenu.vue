<template>
	<v-list dense>
		<template v-for="(item, i) in items">
			<v-list-group v-if="item.children" v-model="item.model" no-action>
				<v-list-tile slot="item" @click="">
					<v-list-tile-action>
						<v-icon>{{ item.model ? item.icon : item['icon-alt'] }}</v-icon>
					</v-list-tile-action>
					<v-list-tile-content>
						<v-list-tile-title>
							{{ item.text }}
						</v-list-tile-title>
					</v-list-tile-content>
				</v-list-tile>
				<v-list-tile v-model="child.state" v-for="(child, i) in item.children" :key="i" @click="goToLink(child.url)">
					<v-list-tile-action v-if="child.icon">
						<v-icon>{{ child.icon }}</v-icon>
					</v-list-tile-action>
					<v-list-tile-content>
						<v-list-tile-title>
							{{ child.text }}
						</v-list-tile-title>
					</v-list-tile-content>
				</v-list-tile>
			</v-list-group>
			<v-list-tile v-model="item.state" v-else @click="goToLink(item.url)">
				<v-list-tile-action>
					<v-icon>{{ item.icon }}</v-icon>
				</v-list-tile-action>
				<v-list-tile-content>
					<v-list-tile-title>
						{{ item.text }}
					</v-list-tile-title>
				</v-list-tile-content>
			</v-list-tile>
		</template>
	</v-list>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
	data: () => ({
		items: [
			{ 
				icon: 'dashboard',
				text: 'Dashboard',
				url: '/dashboard',
				state: window.location.pathname === '/dashboard'
			},
		],
	}),
	computed: {
		...mapGetters({
			permissions :'session/permissions'
		}),
	},
	methods: {
		goToLink(location){
			window.location = location;
		},

		updateMenuList(){
		/**	if(window._.find(this.permissions, { 'name': 'View Event'}) ||
				window._.find(this.permissions, { 'name': 'View Trip'}) ||
				window._.find(this.permissions, { 'name': 'View Event Details'}) ) {
				if(!window._.find(this.items, { 'text': 'Live Event Feed'})){
					this.items.push({ 
						icon: 'rss_feed',
						text: 'Live Event Feed',
						url: '/event-feed',
						state: window.location.pathname.includes('/event-feed')
					});
				}
			} */

			if(window._.find(this.permissions, { 'name': 'View Client'})){
				if(!window._.find(this.items, { 'text': 'Clients'})){
					this.items.push({ 
						icon: 'people',
						text: 'Clients',
						url: '/clients',
						state: window.location.pathname === '/clients'
					});
				}
			}

			if(window._.find(this.permissions, { 'name': 'View Security Company'})){
				if(!window._.find(this.items, { 'text': 'Security Companies'})){
					this.items.push({ 
						icon: 'security',
						text: 'Security Companies',
						url: '/security-companies',
						state: window.location.pathname === '/security-companies'
					});
				}
			}


			if(window._.find(this.permissions, { 'name': 'View User Client Link'})){
				if(!window._.find(this.items, { 'text': 'User Client Link'})){
					this.items.push({ 
						icon: 'people',
						text: 'User Client Link',
						url: '/user-client-links',
						state: window.location.pathname === '/user-client-links'
					});
				}
			}

			if(window._.find(this.permissions, { 'name': 'View Site'})){
				if(!window._.find(this.items, { 'text': 'Sites'})){
					this.items.push({ 
						icon: 'location_city',
						text: 'Sites',
						url: '/sites',
						state: window.location.pathname === '/sites'
					});
				}
			}

			if(window._.find(this.permissions, { 'name': 'View Admin'}) ||
				window._.find(this.permissions, { 'name': 'View Operator'}) ||
				window._.find(this.permissions, { 'name': 'View Client'}) ){
				if(!window._.find(this.items, { 'text': 'Users'})){
					this.items.push({ 
						icon: 'person',
						text: 'Users',
						url: '/users',
						state: window.location.pathname === '/users'
					});
				}
			}


			if(window._.find(this.permissions, { 'name': 'View Trip'}) ){
				if(!window._.find(this.items, { 'text': 'Patrols'})){
					this.items.push({ 
						icon: 'keyboard_arrow_up',
						'icon-alt': 'directions_walk',
						text: 'Patrols',
						model: window.location.pathname === '/patrol-overview' || window.location.pathname === '/active-patrols' || window.location.pathname === '/active-patrols' || window.location.pathname === '/upcomming-patrols' || window.location.pathname === '/patrol-history' || window.location.pathname === '/patrol-configuration',
						children: [
						// { 
						// 	icon: 'dashboard',
						// 	text: 'Overview',
						// 	url: '/patrol-overview', 
						// 	state: window.location.pathname === '/patrol-overview'
						// },
						{
							icon: 'play_arrow',
							text: 'Active Patrols',
							url: '/active-patrols',
							state: window.location.pathname === '/active-patrols'
						},
						// {
						// 	icon: 'fast_forward',
						// 	text: 'Upcomming Patrols',
						// 	url: '/upcomming-patrols',
						// 	state: window.location.pathname === '/upcomming-patrols'
						// },
						// {
						// 	icon: 'history',
						// 	text: 'History',
						// 	url: '/patrol-history',
						// 	state: window.location.pathname === '/patrol-history'
						// },
						// { 
						// 	icon: 'settings',
						// 	text: 'Configure Patrols',
						// 	url: '/patrol-configuration',
						// 	state: window.location.pathname === '/patrol-configuration'
						// },
						]
					});
				}
			}
		},
	},
	mounted() {
		// Push menu items in based on permissions
		this.updateMenuList()
	},
	watch: {
		permissions: {
			handler: function(newValue) {
				this.updateMenuList()
			},
			deep: true
		},
	},
}
</script>
