<template>
	<v-list dense>
		<v-list-tile>
			<v-list-tile-content>
				<v-list-tile-title>Notifications</v-list-tile-title>
			</v-list-tile-content>
		</v-list-tile>
        <v-list-tile v-if="notifications.length == 0">
            <v-list-tile-content>
                <p>There are no new notifications.</p>
            </v-list-tile-content>
        </v-list-tile>
        <v-list-tile v-else :class="generateStyle(notification.event_type)" v-for="(notification,index) in notifications" :key="index">
         <v-list-tile-action @click.stop="openNotification(notification)">
            <v-icon>{{ getNotificationIcon(notification.event_type) }}</v-icon>
        </v-list-tile-action>
        <v-list-tile-content @click.stop="openNotification(notification)">
            <v-list-tile-title>{{ notification.site.name }} - {{ getFriendlyTitle(notification.event_type) }} <small class="event-time">{{ notification.created_at }}</small></v-list-tile-title>
        </v-list-tile-content>
        <v-list-tile-action>
          <v-btn icon ripple @click="muteEvent(notification)">
            <v-icon color="grey lighten-1">close</v-icon>
        </v-btn>
    </v-list-tile-action>
</v-list-tile>
</v-list>
</template>

<script>
import moment from 'moment';
export default {
   props: {
      value: {
         required: true,
         type: Array,
     },
 },
 data: () => ({
   notifications: [],
}),
 methods: {
   generateStyle(event_type) {
      return {
        red: event_type === 'PANIC_ALERT' || event_type ===  'INCIDENT',
        green: event_type === 'TRIP_START' ||  event_type === 'PATROL_START',
        grey: event_type === 'CALL_ME' || event_type === 'CALL_BACK',
        blue: event_type === 'TRIP_END' ||  event_type === 'PATROL_COMPLETE',
        orange:  event_type !== 'PATROL_START' && event_type !== 'PATROL_COMPLETE' && event_type !== 'PANIC_ALERT' && event_type !== 'TRIP_START' && event_type !== 'CALL_ME' && event_type !== 'CALL_BACK' &&  event_type !== 'INCIDENT'
                && event_type !== 'TRIP_END',
        'lighten-4': true,
        'margined-list-tile': true,
        'custom-notification-tile': true,
     };
 },

 getNotificationIcon(event_type){
    if(event_type === 'PANIC_ALERT' || event_type === 'CALL_ME' || event_type === 'INCIDENT'){
        return 'notifications_active';
    }
    return 'info';
},

getFriendlyTitle(title){
    return window._.startCase(window._.lowerCase(title));
},

openNotification(notification){
  window.location = `/event-feed/${notification.id}`;
},

muteEvent(notification){
    const newNotification = window._.clone(notification);
    this.notifications.splice(notification, 1);
    this.$emit('mute-event', newNotification);
},

updateNotifications(newNotifications){
    this.notifications = [];
    newNotifications.forEach((value, key) => {
        const newValue = value;

        switch(newValue.context){
            case 'error' :{
                newValue.icon = 'add_alert';
                break;
            }
            default :{
                newValue.icon = 'info';
                break;
            }
        }

        this.notifications.unshift(newValue);
    });
},
},
mounted(){
    this.updateNotifications(this.value);
},
watch: {
   value: {
    handler: function(newValue) {
        this.updateNotifications(newValue);
    },
},
},
}
</script>

<style scoped>
.margined-list-tile{
  margin-bottom: 5px;
}

.event-time{
  float: right;
}

.custom-notification-tile{
  cursor: pointer;
}
</style>