<template>
  <v-toolbar color="teal lighten-2" dark app clipped-left clipped-right fixed>
    <v-toolbar-title style="width: 300px" class="ml-0 pl-3">
      <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
      {{ appTitle }}
    </v-toolbar-title>
    <!-- <v-text-field solo prepend-icon="search" placeholder="Search"></v-text-field> -->
    <v-spacer></v-spacer>
    <v-toolbar-title>{{ userName }} [{{ userRoles[0] }}]</v-toolbar-title>
    <!-- <v-btn icon>
      <v-icon>help</v-icon>
    </v-btn>-->
    <v-btn icon @click="logout()">
      <v-icon>power_settings_new</v-icon>
    </v-btn>
  </v-toolbar>
</template>

<script>
import { EventBus } from '../../utils/event-bus';

export default {
  props: {
    value: {
      type: Boolean,
      required: true,
    },
  },
  data: () => ({
    appLogo: 'https://vuetifyjs.com/static/doc-images/logo.svg',
    appTitle: 'Dycom Radio',
    drawer: this.value,
    userName: '',
    roleName: '',
  }),
  methods: {
    logout() {
      // axios.post(`${window.location.protocol}//${window.location.hostname}/logout`)
      axios.post('/logout')
        .then((response) => {
          // debugger;
          EventBus.$emit('notify', 'info', 'Successfully logged out!');
          this.$store.dispatch('session/clear').then(() => {
            console.log('Sessions cleared!');
            window.location = '/';
          });
        })
        .catch((error) => {
          // debugger;
          EventBus.$emit('notify', 'error', 'Could not logout. Please try again.');
          console.log('Could not logout!', error);
        });
    },
  },
  mounted() {
  },
  created() {
    this.userName = this.$store.getters['session/userName'];
    this.userRoles = this.$store.getters['session/userRoles'];
  },
  watch: {
    drawer(newValue) {
      this.$emit('input', !newValue);
    },
  }
}
</script>
