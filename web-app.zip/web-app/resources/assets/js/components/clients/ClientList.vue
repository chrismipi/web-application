<template>
  <v-card>
    <v-card-title>
      <v-spacer></v-spacer>
      <v-text-field append-icon="search" label="Search" single-line hide-details v-model="search"></v-text-field>
    </v-card-title>
    <v-data-table v-bind:headers="headers" v-bind:items="items" v-bind:search="search">
      <template slot="items" slot-scope="props">
        <td>{{ props.item.name }}</td>
        <td class="text-xs-right">{{ props.item.address }}</td>
        <td class="text-xs-right">{{ props.item.fullName }}</td>
        <td class="text-xs-right">{{ props.item.contactNumber }}</td>        
        <td class="text-xs-right">{{ props.item.alternativeContactNumber }}</td>
        <td class="text-xs-right">{{ props.item.siteCount }}</td>
        <td class="text-xs-right">
          <v-menu bottom right>
            <v-btn icon slot="activator" light>
              <v-icon>more_vert</v-icon>
            </v-btn>
            <v-list>
              <v-list-tile
                v-for="(action, key) in props.item.actions"
                :key="key"
                @click.native="performActionOnclient(action.name, props.item)"
              >
                <v-list-tile-title>{{ action.name }}</v-list-tile-title>
              </v-list-tile>
            </v-list>
          </v-menu>
        </td>
      </template>
      <template
        slot="pageText"
        slot-scope="{ pageStart, pageStop }"
      >From {{ pageStart }} to {{ pageStop }}</template>
    </v-data-table>
    <delete-client
      v-if="canDeleteClient && modal.delete.show"
      v-model="modal.delete.data"
      v-on:close-dialog="closeDialog()"
    ></delete-client>
  </v-card>
</template>

<script>

import DeleteClient from './DeleteClient';
import { mapGetters } from 'vuex';

import {EventBus} from '../../utils/event-bus';

export default {
  props: {
    clients: {
      type: Array,
      required: true,
    },
  },
  components: {
    DeleteClient,
  },
  data: () => ({
    search: '',
    headers: [
      {
        text: 'Name',
        align: 'left',
        sortable: false,
        value: 'name'
      },
      { text: 'Address', value: 'address' },
      { text: 'Manager', value: 'fullName' },
      { text: 'Contact No', value: 'contactNumber' },
      { text: 'Alt Contact No', value: 'alternativeContactNumber' },
      { text: '# Sites', value: 'siteCount' },
      { text: '', value: 'actions' },
    ],
    items: [],
    modal: {
      delete: {
        data: {},
        show: false,
      },
      edit: {
        data: {},
        show: false,
      }
    },
    canEditClient: false,
    canDeleteClient: false,
  }),
  computed: {
    ...mapGetters({
      permissions: 'session/permissions'
    }),
  },
  methods: {
    closeDialog() {
      for (const field in this.modal) {
        this.modal[field].show = false;
      }
    },

    performActionOnclient(actionName, client) {
      if (actionName === 'Edit' || actionName === 'View') {
        this.$emit('edit', client);
      } else {
        this.modal[window._.camelCase(actionName)].data = client;
        this.modal[window._.camelCase(actionName)].show = true;
      }
    },

    prepData() {
      this.canEditClient = window._.find(this.permissions, { 'name': 'Edit Client' }) ? true : false;
      this.canDeleteClient = window._.find(this.permissions, { 'name': 'Delete Client' }) ? true : false;

      this.items = this.clients;
      this.items.forEach((client) => {
        client['fullName'] = `${client.manager.first_name} ${client.manager.last_name}`;
        client['contactNumber'] = client.contact_number;
        client['alternativeContactNumber'] = client.alternative_contact_number;
        client['siteCount'] = client.sites.length;
        client['actions'] = [];

        if (this.canEditClient) {
          client['actions'].push({
            name: 'Edit',
          });
        } else {
          client['actions'].push({
            name: 'View',
          });
        }

        if (this.canDeleteClient && client.sites.length === 0) {
          client['actions'].push({
            name: 'Delete',
          });
        }
      });
    },
  },
  mounted() {
    this.items = this.clients;
    this.prepData();
  },
  beforeDestroy() {
  },
}
</script>

<style scoped>
</style>
