<template>
  <form>
    <v-text-field v-model="client.name" label="Client Name" :error-messages="errors.collect('name')" v-validate="'required'" data-vv-name="name" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="client.address" label="Client Address" :error-messages="errors.collect('address')" v-validate="'required'" data-vv-name="address" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="client.contact_number" label="Contact Number"
                      :error-messages="errors.collect('contact_number')" v-validate="'required'"
                      data-vv-name="contact_number" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="client.alternative_contact_number" label="Alternative Contact Number"
                      :error-messages="errors.collect('alternative_contact_number')" 
                      data-vv-name="alternative_contact_number" required :disabled="disabled"></v-text-field>
  </form>
</template>

<script>
import Client from '../../models/Client';

export default {
  props: {
    value: {
      required: true,
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false,
    }
  },
  data: () => ({
    client: {},
  }),
  methods: {
    submit () {
      this.$validator.validateAll()
    },

    clear () {
      this.client.name = ''
      this.client.address = ''
      this.$validator.clean()
    },
  },
  mounted() {
    this.client = new Client(this.value);
    setTimeout(() => {
      this.$validator.validateAll();
    }, 200)
  },
  watch: {
    client: {
      handler: function(newValue) {
        this.$emit('input', this.client);
        this.$validator.validateAll()
        .then(result => {
          this.$emit('formisvalid', result);
        });
      },
      deep: true
    },
  }
}
</script>
