<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs12>
        <v-card :class="getClasses">
          <v-card-title primary-title class="text-xs-center">
            <div class="text-xs-center" style="width: 100%;">
              <h3 class="headline mb-0">{{ getFriendlyTitle(event.event_type) }}</h3>
              <h6>
                <strong>{{ event.created_at }}</strong> @
                <strong>{{ event.site.name }}</strong>
              </h6>
              <!-- <div>Located two hours south of Sydney in the <br>Southern Highlands of New South Wales, ...</div> -->
            </div>
          </v-card-title>
          <v-card-text>
            <p v-if="isTripStart">
              Patrols:
              <br />
              <v-chip
                v-for="(trip,key) in tripStartData"
                :key="key"
                color="teal lighten-2"
                text-color="white"
              >{{ getFriendlyTime(trip) }}</v-chip>
            </p>
            <p v-else-if="!isSignIn">
              Detail:
              <strong>{{ event.detail }}</strong>
            </p>
            <img v-else :src="`data:image/jpg;base64,${event.detail}`" style="max-height: 150px;" />
            <p>
              Guard:
              <strong>{{ event.name }}</strong>
            </p>
            <p>
              Priority:
              <strong>{{ event.priority }}</strong>
            </p>
            <p>
              Client:
              <strong>{{ event.site.client.name }}</strong>
            </p>
            <p>
              Address:
              <strong>{{ event.site.client.address }}</strong>
            </p>
            <p>
              Manager:
              <strong>{{ event.site.client.manager.first_name }} {{ event.site.client.manager.last_name }}</strong>
            </p>
            <p>
              Manager Contact:
              <strong>{{ event.site.client.manager.contact_number }}</strong>
            </p>
            <p>
              Manager Alternative Contact:
              <strong>{{ event.site.client.manager.alternative_contact_number }}</strong>
            </p>
            <p>
              Phone One:
              <strong>{{ event.site.contact_number }}</strong>
            </p>
            <p>
              Phone Two:
              <strong>{{ event.site.alternative_contact_number }}</strong>
            </p>
          </v-card-text>
          <v-card-actions>
            <v-btn block color="teal" @click="muteEvent" :disabled="event.ack">Mute</v-btn>
          </v-card-actions>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
import moment from "moment";

export default {
  props: {
    value: {
      type: Object,
      required: false
    }
  },
  data: () => ({
    event: {},
    isSignIn: false,
    isTripStart: false,
    tripStartData: null
  }),
  computed: {
    getClasses() {
      return {
        red:
          window._.snakeCase(this.event.event_type).toLowerCase() ===
            "panic_alert" ||
          window._.snakeCase(this.event.event_type).toLowerCase() ===
            "incident",
        green:
          window._.snakeCase(this.event.event_type).toLowerCase() ===
             "trip_start" ||
          window._.snakeCase(this.event.event_type).toLowerCase() ===
             "patrol_start",
        grey:
          window._.snakeCase(this.event.event_type).toLowerCase() ===
            "call_me" ||
          window._.snakeCase(this.event.event_type).toLowerCase() ===
            "call_back",
        blue:
          window._.snakeCase(this.event.event_type).toLowerCase() ===
                "trip_end" ||
           window._.snakeCase(this.event.event_type).toLowerCase() ===
                "patrol_complete",
        orange:
          window._.snakeCase(this.event.event_type).toLowerCase() !==
            "panic_alert" &&
          window._.snakeCase(this.event.event_type).toLowerCase() !==
            "trip_start" &&
          window._.snakeCase(this.event.event_type).toLowerCase() !==
            "patrol_start" &&
          window._.snakeCase(this.event.event_type).toLowerCase() !==
            "call_me" &&
          window._.snakeCase(this.event.event_type).toLowerCase() !==
            "call_back" &&
          window._.snakeCase(this.event.event_type).toLowerCase() !==
             "incident" &&
          window._.snakeCase(this.event.event_type).toLowerCase() !==
              "patrol_complete" &&
          window._.snakeCase(this.event.event_type).toLowerCase() !==
            "trip_end",
        "lighten-4": true
      };
    }
  },
  methods: {
    getFriendlyTitle(title) {
      return window._.startCase(window._.lowerCase(title));
    },

    getFriendlyTime(timestamp) {
      const time = new Date(timestamp);
      const hours =
        time.getHours().toString().length > 1
          ? time.getHours()
          : `0${time.getHours()}`;
      const minutes =
        time.getMinutes.toString().length > 1
          ? time.getMinutes()
          : `0${time.getMinutes()}`;
      return `${hours}:${minutes}`;
    },

    muteEvent() {
      this.$emit("mute-event", this.event);
    }
  },
  created() {
    this.event = this.value;
    this.isSignIn =
      window._.snakeCase(this.event.event_type) === "guard_sign_in";
    this.isTripStart =
      window._.snakeCase(this.event.event_type) === "trip_start" || window._.snakeCase(this.event.event_type) === "patrol_start";

    if (this.isTripStart) {
      this.tripStartData = JSON.parse(this.event.detail);
    }
  },
  beforeDestroy() {},
  watch: {
    value: {
      handler: function(newValue) {
        this.event = newValue;
      },
      deep: true
    }
  }
};
</script>

<style scoped>
</style>
