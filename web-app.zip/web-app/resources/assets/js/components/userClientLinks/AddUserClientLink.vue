<template>
  <v-stepper v-model="e1">
    <v-stepper-header>
      <v-stepper-step step="1" :complete="e1 > 1">Choose User</v-stepper-step>
      <v-divider></v-divider>
      <v-stepper-step step="2" :complete="e1 > 2">Choose Client</v-stepper-step>
      <v-divider></v-divider>
      <v-stepper-step step="3">Review</v-stepper-step>
    </v-stepper-header>
    <v-stepper-content step="1">
      <v-select
        label="Enter Email Address of Existing User"
        autocomplete
        :loading="loaders.user"
        cache-items
        required
        :items="userList"
        :search-input.sync="userSearch"
        v-model="userId"
        prepend-icon="people"
        item-text="email"
        item-value="id"
      ></v-select>
      <v-btn color="teal" @click.native="e1 = 2" :disabled="!formValid.stepOne">Continue</v-btn>
    </v-stepper-content>
    <v-stepper-content step="2">
      <v-select
        label="Client Name"
        autocomplete
        :loading="loaders.client"
        cache-items
        required
        :items="clientList"
        :search-input.sync="clientSearch"
        v-model="clientId"
        prepend-icon="people"
        item-text="name"
        item-value="id"
      ></v-select>
      <v-btn color="teal" @click.native="e1 = 3" :disabled="!formValid.stepTwo">Continue</v-btn>
      <v-btn flat @click.native="e1 = 1">Back</v-btn>
    </v-stepper-content>
    <v-stepper-content step="3">
      <v-card color="teal lighten-5" class="mb-5">
        <v-card-title>User Details</v-card-title>
        <v-card-text>
          <user-form v-model="user" v-if="formValid.stepTwo" :disabled="true"></user-form>
        </v-card-text>
      </v-card>
      <v-card color="teal lighten-5" class="mb-5">
        <v-card-title>Client Details</v-card-title>
        <v-card-text>
          <client-form v-model="client" v-if="formValid.stepTwo" :disabled="true"></client-form>
        </v-card-text>
      </v-card>
      <v-btn
        color="teal"
        @click.native="creatingNewUserClientLink()"
        :disabled="!formValid.stepOne || !formValid.stepTwo"
      >Link User And Client</v-btn>
      <v-btn flat @click.native="e1 = 2">Back</v-btn>
    </v-stepper-content>
  </v-stepper>
</template>

<script>
import Client from "../../models/Client";
import User from "../../models/User";
import UserClientLink from "../../models/UserClientLink";
import { EventBus } from "../../utils/event-bus";
import ClientForm from "../clients/ClientForm";
import UserForm from "../users/UserForm";

export default {
  components: {
    ClientForm,
    UserForm
  },
  data: () => ({
    client: null,
    clientId: 0,
    clientList: [],
    clientSearch: null,
    defaultUserRoles: [5],
    e1: 0,
    formValid: {
      stepOne: false,
      stepTwo: false,
      stepThree: false
    },
    newUserEmail: "",
    user: null,
    userId: 0,
    userList: [],
    userSearch: null,
    userClientLink: {},
    loaders: {
      client: false,
      user: false
    }
  }),
  methods: {
    creatingNewUserClientLink() {
      this.userClientLink.client_id = this.client.id;
      this.userClientLink.manager_id = this.user.id;
      axios
        .put(`/api/user-client-link/`, {
          userClientLink: this.userClientLink
        })
        .then(response => {
          // Client successfully created
          EventBus.$emit(
            "notify",
            "success",
            "User and client successfully linked!"
          );
          setTimeout(() => {
            window.location.reload();
          }, 2500);
        })
        .catch(error => {
          let errorMessages = [];
          for (const errorMessage in error.response.data.errors) {
            errorMessages.push(error.response.data.errors[errorMessage]);
          }

          // Client could not be created
          EventBus.$emit(
            "notify",
            "error",
            `Error linking user and client: ${errorMessages}`
          );
        });
    },

    queryClientSelection(v) {
      this.loaders.client = true;
      axios
        .get(`/api/client/search?content=${v}`)
        .then(response => {
          this.clientList = response.data.result;
        })
        .catch(error => {
          EventBus.$emit(
            "notify",
            "error",
            "Clients could not be retrieved. Please try again later."
          );
        })
        .then(() => {
          this.loaders.client = false;
        });
    },

    queryUserSelection(v) {
      this.loaders.user = true;
      axios
        .get(`/api/user/search?content=${v}`)
        .then(response => {
          this.userList = response.data.result;
        })
        .catch(error => {
          EventBus.$emit(
            "notify",
            "error",
            "Users could not be retrieved. Please try again later."
          );
        })
        .then(() => {
          this.loaders.user = false;
        });
    },

    updateUserFormValidation(validationStatus) {
      this.formValid.stepOne = validationStatus;
    },

    updateClientFormValidation(validationStatus) {
      this.formValid.stepTwo = validationStatus;
    }
  },
  mounted() {
    this.user = () => new User();
    this.client = () => new Client();
  },
  watch: {
    clientSearch(val) {
      val && this.queryClientSelection(val);
    },

    clientId(val) {
      if (val !== 0) {
        this.client = window._.find(this.clientList, ["id", val]);
        this.formValid.stepTwo = true;
      } else {
        this.formValid.stepTwo = false;
      }
    },

    userSearch(val) {
      val && this.queryUserSelection(val);
    },

    userId(val) {
      if (val !== 0) {
        this.user = window._.find(this.userList, ["id", val]);
        this.formValid.stepOne = true;
      } else {
        this.formValid.stepOne = false;
      }
    }
  }
};
</script>
