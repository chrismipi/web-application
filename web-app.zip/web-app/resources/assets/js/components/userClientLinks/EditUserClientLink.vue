<template>
  <v-layout row justify-center>
    <v-card>
      <v-card-title>
        <span class="headline">User Client Link</span>
      </v-card-title>
      <v-card-text>
        <span class="subtitle">User Details</span>
        <user-form v-model="user" :disabled="true"></user-form>
      </v-card-text>
      <v-card-text>
        <span class="subtitle">Client Details</span>
        <client-form v-model="client" :disabled="true"></client-form>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn color="blue darken-1" flat @click.native="showList()">Close</v-btn>
        <v-btn color="blue darken-1" flat @click.native="saveUserClientLink()" v-if="!disabled">Save</v-btn>
        <v-spacer></v-spacer>
      </v-card-actions>
    </v-card>
  </v-layout>
</template>

<script>
import UserClientLink from "../../models/UserClientLink";
import Client from "../../models/Client";
import User from "../../models/User";
import { EventBus } from "../../utils/event-bus";
import ClientForm from "../clients/ClientForm";
import UserForm from "../users/UserForm";

export default {
  props: {
    value: {
      type: Object,
      required: true
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  components: {
    ClientForm,
    UserForm
  },
  data: () => ({
    dialog: true,
    userClientLink: {},
    client: {},
    user: {}
  }),
  methods: {
    showList() {
      this.$emit("show-list", true);
    },

    saveUserClientLink() {
      axios
        .post(
          `/api/user-client-link/${this.userClientLink.id}`,
          this.userClientLink
        )
        .then(response => {
          // User Client successfully created
          EventBus.$emit(
            "notify",
            "success",
            "User Client updated successfully!"
          );
          setTimeout(() => {
            window.location.reload();
          }, 2500);
        })
        .catch(error => {
          let errorMessages = [];
          for (const errorMessage in error.response.data.errors) {
            errorMessages.push(error.response.data.errors[errorMessage]);
          }
          // Client could not be created
          EventBus.$emit(
            "notify",
            "error",
            `Error updating client: ${errorMessages}`
          );
        });
    }
  },
  created() {
    this.userClientLink = new UserClientLink(this.value);
    this.client = new Client(this.value.client);
    this.user = new User(this.value.manager);
  },
  watch: {}
};
</script>

<style scoped>
.subtitle {
  font-size: 22px !important;
  font-weight: 300;
  line-height: 32px !important;
  letter-spacing: normal !important;
}
.card {
  width: 100% !important;
}
</style>