<template>
  <v-dialog v-model="dialog" lazy persistent max-width="450px">
    <v-card>
      <v-card-title
        class="headline"
      >Delink {{ client.name }} and {{user.first_name}} {{user.last_name}}</v-card-title>
      <v-card-text>
        <v-alert
          warning="true"
          v-bind:value="true"
        >You are about to delink {{ client.name }} and {{user.first_name}} {{user.last_name}} . Note that the client information will still be kept for record keeping.</v-alert>
      </v-card-text>
      <v-card-text>Are you sure you want to delink {{ client.name }} and {{user.first_name}} {{user.last_name}}?</v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn class="grey--text darken-1" flat @click.native="closeDialog()">Cancel</v-btn>
        <v-btn class="red" @click.native="deleteUserClientLink()">Delete</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import UserClientLink from "../../models/UserClientLink";
import Client from "../../models/Client";
import User from "../../models/User";
import { EventBus } from "../../utils/event-bus";

export default {
  props: {
    value: {
      type: Object,
      required: true
    }
  },
  data: () => ({
    userClientLink: {},
    client: {},
    user: {},
    dialog: true
  }),
  methods: {
    closeDialog() {
      this.$emit("close-dialog", true);
    },

    deleteUserClientLink() {
      axios
        .delete(`/api/user-client-link/${this.userClientLink.id}`)
        .then(response => {
          // User Client successfully delinked
          EventBus.$emit(
            "notify",
            "success",
            "User and Client successfully delinked!"
          );
          setTimeout(() => {
            window.location.reload();
          }, 2500);
        })
        .catch(error => {
          let errorMessages = [];
          for (const errorMessage in error.response.data.errors) {
            errorMessages.push(error.response.data.errors[errorMessage]);
          }
          // Client could not be deleted
          EventBus.$emit(
            "notify",
            "error",
            `Error deleting client: ${errorMessages}`
          );
        });
    }
  },
  created() {
    this.userClientLink = new UserClientLink(this.value);
    this.client = new Client(this.value.client);
    this.user = new User(this.value.manager);
  },
  watch: {}
};
</script>

<style scoped>
.subtitle {
  font-size: 22px !important;
  font-weight: 300;
  line-height: 32px !important;
  letter-spacing: normal !important;
}
</style>