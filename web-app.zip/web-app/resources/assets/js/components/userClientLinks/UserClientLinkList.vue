<template>
  <v-card>
    <v-card-title>
      <v-spacer></v-spacer>
      <v-text-field append-icon="search" label="Search" single-line hide-details v-model="search"></v-text-field>
    </v-card-title>
    <v-data-table v-bind:headers="headers" v-bind:items="items" v-bind:search="search">
      <template slot="items" slot-scope="props">
        <td class="text-xs-right">{{ props.item.fullName }}</td>
        <td class="text-xs-right">{{ props.item.email }}</td>
        <td>{{ props.item.clientName }}</td>
        <td class="text-xs-right">{{ props.item.address }}</td>
        <td class="text-xs-right">
          <v-menu bottom right>
            <v-btn icon slot="activator" light>
              <v-icon>more_vert</v-icon>
            </v-btn>
            <v-list>
              <v-list-tile
                v-for="(action, key) in props.item.actions"
                :key="key"
                @click.native="performActionOnUserClientLink(action.name, props.item)"
              >
                <v-list-tile-title>{{ action.name }}</v-list-tile-title>
              </v-list-tile>
            </v-list>
          </v-menu>
        </td>
      </template>
      <template
        slot="pageText"
        slot-scope="{ pageStart, pageStop }"
      >From {{ pageStart }} to {{ pageStop }}</template>
    </v-data-table>
    <delete-user-client-link
      v-if="canDeleteUserClientLink && modal.delete.show"
      v-model="modal.delete.data"
      v-on:close-dialog="closeDialog()"
    ></delete-user-client-link>
  </v-card>
</template>

<script>
import DeleteUserClientLink from "./DeleteUserClientLink";
import { mapGetters } from "vuex";

export default {
  props: {
    userClientLinks: {
      type: Array,
      required: true
    }
  },
  components: {
    DeleteUserClientLink
  },
  data: () => ({
    search: "",
    headers: [
      {
        text: "User Details",
        align: "left",
        sortable: true,
        value: "fullName"
      },
      { text: "Address", value: "email" },
      { text: "Client Details", value: "clientName" },
      { text: "Address", value: "address" },
      { text: "", value: "actions" }
    ],
    items: [],
    modal: {
      delete: {
        data: {},
        show: false
      },
      edit: {
        data: {},
        show: false
      }
    },
    canEditUserClientLink: false,
    canDeleteUserClientLink: false
  }),
  computed: {
    ...mapGetters({
      permissions: "session/permissions"
    })
  },
  methods: {
    closeDialog() {
      for (const field in this.modal) {
        this.modal[field].show = false;
      }
    },

    performActionOnUserClientLink(actionName, userClientLink) {
      if (actionName === "Edit" || actionName === "View") {
        this.$emit("edit", userClientLink);
      } else {
        this.modal[window._.camelCase(actionName)].data = userClientLink;
        this.modal[window._.camelCase(actionName)].show = true;
      }
    },

    prepData() {
      this.canEditUserClientLink = window._.find(this.permissions, {
        name: "Edit User Client Link"
      })
        ? true
        : false;
      this.canDeleteUserClientLink = window._.find(this.permissions, {
        name: "Delete User Client Link"
      })
        ? true
        : false;

      this.items = this.userClientLinks;
      this.items.forEach(userClientLink => {
        userClientLink[
          "fullName"
        ] = `${userClientLink.manager.first_name} ${userClientLink.manager.last_name}`;
        userClientLink["email"] = userClientLink.manager.email;
        userClientLink["clientName"] = userClientLink.client.name;
        userClientLink["address"] = userClientLink.client.address;
        userClientLink["actions"] = [];

        if (this.canEditUserClientLink) {
          userClientLink["actions"].push({
            name: "View"
          });
        } else {
          userClientLink["actions"].push({
            name: "View"
          });
        }

        if (this.canDeleteUserClientLink) {
          userClientLink["actions"].push({
            name: "Delete"
          });
        }
      });
    }
  },
  mounted() {
    this.prepData();
  },
  beforeDestroy() {}
};
</script>

<style scoped>
</style>