<template>
  <v-layout row wrap>
    <v-flex xs12>
      <v-list>
        <template v-for="(shift,index) in shifts">
          <v-list-tile avatar v-bind:key="shift.title" @click>
            <v-list-tile-avatar>
              <v-icon large class="teal--text lighten-2">directions_walk</v-icon>
            </v-list-tile-avatar>
            <v-list-tile-content>
              <v-list-tile-title>{{ shift.start_time }} to {{ shift.end_time }}</v-list-tile-title>
              <v-list-tile-title>
                <small>{{ shift.patrol_count }} Patrols,</small>
                <small>with {{ shift.rest_time }} min restin inbetween,</small>
                <small>day of the week({{ days[shift.day_of_week].name }})</small>
              </v-list-tile-title>
            </v-list-tile-content>
            <v-list-tile-action>
              <v-btn icon ripple @click="removeShift(index)" :disabled="disabled">
                <v-icon color="red lighten-2">clear</v-icon>
              </v-btn>
            </v-list-tile-action>
          </v-list-tile>
          <v-divider v-if="shifts.length > 1" v-bind:inset="false"></v-divider>
        </template>
      </v-list>
    </v-flex>
    <v-flex xs12 v-if="!disabled">
      <v-layout row wrap>
        <v-flex xs1>
          <v-select
            label="Day"
            :items="days"
            v-model="newShift.day_of_week"
            :error-messages="errors.collect('day_of_week')"
            v-validate="'required'"
            data-vv-name="day_of_week"
            item-text="name"
            item-value="id"
            required
          ></v-select>
        </v-flex>
        <v-flex xs1>
          <v-text-field
            class="pr-1"
            mask="##h##"
            name="start_time"
            label="Start Time"
            v-model="newShift.start_time"
            :error-messages="errors.collect('start_time')"
            v-validate="'required'"
            data-vv-name="start_time"
            required
          ></v-text-field>
        </v-flex>
        <v-flex xs2>
          <v-text-field
            class="pr-1"
            mask="##h##"
            name="end_time"
            label="End Time"
            v-model="newShift.end_time"
            :error-messages="errors.collect('end_time')"
            v-validate="'required'"
            data-vv-name="end_time"
            required
          ></v-text-field>
        </v-flex>
        <v-flex xs2>
          <v-text-field
            class="pr-1"
            mask="##"
            name="patrol_count"
            label="No Of Patrols"
            v-model="newShift.patrol_count"
            :error-messages="errors.collect('patrol_count')"
            v-validate="'required'"
            data-vv-name="patrol_count"
            required
          ></v-text-field>
        </v-flex>
        <v-flex xs2>
          <v-text-field
            class="pr-1"
            mask="###"
            name="rest_time"
            label="Rest Time (minutes)"
            v-model="newShift.rest_time"
            :error-messages="errors.collect('rest_time')"
            v-validate="'required'"
            data-vv-name="rest_time"
            required
          ></v-text-field>
        </v-flex>
        <v-flex xs2>
          <v-text-field
            class="pr-1"
            mask="###"
            name="trip_duration"
            label="Trip Duration (minutes)"
            v-model="newShift.trip_duration"
            :error-messages="errors.collect('trip_duration')"
            v-validate="'required'"
            data-vv-name="trip_duration"
            required
          ></v-text-field>
        </v-flex>
        <v-flex xs2 class="text-xs-center">
          <v-btn
            class="custom-add-button"
            icon
            ripple
            @click="addShift()"
            :disabled="!newShiftIsValid"
          >
            <v-icon color="teal light-2" large>add</v-icon>
          </v-btn>
        </v-flex>
        <v-flex xs4>
          <v-card :class="patrolTimeClass">
            <v-card-text>
              Min Total Time Spent On
              <strong>Patrol</strong>:
              <strong>{{ getPatrolTimePercentage }}%</strong>
            </v-card-text>
          </v-card>
        </v-flex>
        <v-flex xs4>
          <v-card :class="restTimeClass">
            <v-card-text>
              Min Total Time Spent On
              <strong>Rest</strong>:
              <strong>{{ getRestTimePercentage }}%</strong>
            </v-card-text>
          </v-card>
        </v-flex>
        <v-flex xs4>
          <v-card :class="idleTimeClass">
            <v-card-text>
              Max
              <strong>Idle</strong> Time:
              <strong>{{ getIdleTime }}%</strong>
            </v-card-text>
          </v-card>
        </v-flex>
      </v-layout>
    </v-flex>
  </v-layout>
</template>

<script>
import Shift from "../../models/Shift";
import { EventBus } from "../../utils/event-bus";
// import moment from 'moment';

export default {
  props: {
    value: {
      type: Array,
      required: true
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data: () => ({
    newShift: new Shift(),
    newShiftIsValid: false,
    shifts: [],
    defaultSelected: {
      id: "0",
      name: "All"
    },
    days: [
      { id: 0, name: "All" },
      { id: 1, name: "Monday" },
      { id: 2, name: "Tuesday" },
      { id: 3, name: "Wednesday" },
      { id: 4, name: "Thursday" },
      { id: 5, name: "Friday" },
      { id: 6, name: "Saturday" },
      { id: 7, name: "Sunday" }
    ]
  }),
  computed: {
    getPatrolTimePercentage() {
      if (this.getTripDurationInMinutes()) {
        return Math.floor(
          ((this.newShift.patrol_count * this.newShift.trip_duration) /
            this.getTripDurationInMinutes()) *
            100
        );
      } else {
        return 0;
      }
    },

    getRestTimePercentage() {
      if (this.getTripDurationInMinutes() && this.newShift.rest_time) {
        return Math.floor(
          ((this.newShift.rest_time * (this.newShift.patrol_count - 1)) /
            this.getTripDurationInMinutes()) *
            100
        );
      } else {
        return 0;
      }
    },

    getIdleTime() {
      return 100 - (this.getPatrolTimePercentage + this.getRestTimePercentage);
    },

    patrolTimeClass() {
      return {
        "darken-2": true,
        "white--text": true,
        teal: !(
          this.getPatrolTimePercentage <= 0 ||
          this.getPatrolTimePercentage > 100 ||
          this.getPatrolTimePercentage + this.getRestTimePercentage > 100
        ),
        red:
          this.getPatrolTimePercentage <= 0 ||
          this.getPatrolTimePercentage > 100 ||
          this.getPatrolTimePercentage + this.getRestTimePercentage > 100
      };
    },

    restTimeClass() {
      return {
        "darken-2": true,
        "white--text": true,
        teal: !(
          this.getRestTimePercentage <= 0 ||
          this.getRestTimePercentage >= 100 ||
          this.getPatrolTimePercentage + this.getRestTimePercentage > 100
        ),
        red:
          this.getRestTimePercentage <= 0 ||
          this.getRestTimePercentage >= 100 ||
          this.getPatrolTimePercentage + this.getRestTimePercentage > 100
      };
    },

    idleTimeClass() {
      return {
        "darken-2": true,
        "white--text": true,
        teal: !(
          this.getIdleTime <= 0 ||
          this.getIdleTime >= 100 ||
          this.getPatrolTimePercentage + this.getRestTimePercentage > 100
        ),
        orange:
          this.getIdleTime <= 0 ||
          this.getIdleTime >= 100 ||
          this.getPatrolTimePercentage + this.getRestTimePercentage > 100
      };
    }
  },
  methods: {
    addShift() {
      this.shifts.push(this.newShift);
      this.newShift = new Shift();
    },

    getTripDurationInMinutes() {
      if (this.newShift.start_time && this.newShift.end_time) {
        const startTime = new Date(
          2000,
          0,
          1,
          this.newShift.start_time.split("h")[0],
          this.newShift.start_time.split("h")[1]
        );
        const endTime = new Date(
          2000,
          0,
          1,
          this.newShift.end_time.split("h")[0],
          this.newShift.end_time.split("h")[1]
        );

        if (endTime < startTime) {
          endTime.setDate(endTime.getDate() + 1);
        }

        const diff = endTime - startTime;
        return Math.floor(diff / 1000 / 60);
      } else {
        return 0;
      }
    },

    removeShift(shiftIndex) {
      this.shifts.splice(shiftIndex, 1);
    }
  },
  created() {
    this.value.forEach(shift => {
      this.shifts.push(new Shift(shift));
    });
  },
  watch: {
    value: {
      handler: function(newValue) {
        this.shifts = newValue;
      },
      deep: true
    },
    newShift: {
      handler: function(newValue) {
        this.$validator.validateAll().then(result => {
          this.newShiftIsValid = result;
        });
      },
      deep: true
    },
    shifts: {
      handler: function(newValue) {
        this.$emit("input", this.shifts);
      },
      deep: true
    }
  }
};
</script>

<style scoped>
.custom-add-button {
  margin-top: 14%;
}
</style>
