<template>
  <v-layout row justify-center>
    <v-card>
      <v-card-title>
        <span class="headline">Site Profile</span>
      </v-card-title>
      <v-card-text>
        <span class="subtitle">Site Client</span>
        <client-form v-model="client" :disabled="true"></client-form>
      </v-card-text>
      <v-card-text>
        <span class="subtitle">Site Security Company</span>
        <security-company-form v-model="securityCompany" :disabled="true"></security-company-form>
      </v-card-text>
      <v-card-text>
        <span class="subtitle">Site Details</span>
        <site-form v-model="site" :disabled="disabled"></site-form>
      </v-card-text>
      <v-card-text>
        <span class="subtitle">Shift Details</span>
        <shift-form v-model="site.shifts" :disabled="disabled"></shift-form>
      </v-card-text>
      <v-card-text>
        <span class="subtitle">NFC Tags</span>
        <nfc-tag-list v-model="site.nfc_tags" :disabled="disabled"></nfc-tag-list>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn color="blue darken-1" flat @click.native="showList()">Close</v-btn>
        <v-btn color="blue darken-1" flat @click.native="saveSite()" v-if="!disabled">Save</v-btn>
        <v-spacer></v-spacer>
      </v-card-actions>
    </v-card>
  </v-layout>
</template>

<script>
import Client from '../../models/Client';
import SecurityCompany from '../../models/SecurityCompany';
import Site from '../../models/Site';
import { EventBus } from '../../utils/event-bus';
import SiteForm from './SiteForm';
import ShiftForm from '../shifts/ShiftsForm';
import NfcTagList from '../nfcTags/NfcTagList';
import ClientForm from '../clients/ClientForm';
import SecurityCompanyForm from '../securityCompanies/SecurityCompanyForm';

export default {
  props: {
    value: {
      type: Object,
      required: true,
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false,
    }
  },
  components: {
    SiteForm,
    ShiftForm,
    NfcTagList,
    ClientForm,
    SecurityCompanyForm,
  },
  data: () => ({
    client: {},
    securityCompany: {},
    site: {},
    dialog: true,
    user: {},
  }),
  methods: {
    showList() {
      this.$emit('show-list', true);
    },

    saveSite() {
      axios.post(`/api/site/${this.site.id}`, this.site)
      .then((response) => {
        // Site successfully created
        EventBus.$emit('notify', 'success', 'Site successfully updated!');
        // this.showList();
        setTimeout(() => {
          window.location.reload();
        }, 2500);
      })
      .catch((error) => {
        let errorMessages = [];
        for (const errorMessage in error.response.data.errors) {
          errorMessages.push(error.response.data.errors[errorMessage]);
        }
        // Site could not be created
        EventBus.$emit('notify', 'error', `Error updating client: ${errorMessages}`);
      });
    },
  },
  created() {
    this.client = new Client(this.value.client);
    this.securityCompany = new SecurityCompany(this.value.security_company);
    this.site = new Site(this.value);
  },
  watch: {
    
  },
}
</script>

<style scoped>
.subtitle {
  font-size: 22px!important;
  font-weight: 300;
  line-height: 32px!important;
  letter-spacing: normal!important;
}
.card{
  width: 100% !important;
}
</style>