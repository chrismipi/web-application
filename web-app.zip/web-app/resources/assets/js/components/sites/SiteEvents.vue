<template>
  <v-card>
    <v-card-text>
      <v-card-title>
        <span>
          <b>Site:</b>
          {{ this.value.name}} &nbsp;
        </span>
        <span>
          <b>Address:</b>
          {{ this.value.address}} &nbsp;
        </span>
        <span>
          <b>Client:</b>
          {{ this.value.clientName}} &nbsp;
        </span>
        <span>
          <b>Contact:</b>
          {{ this.value.contactNumber}} &nbsp;
        </span>
        <span>
          <b>Alt Contact No:</b>
          {{ this.value.alternativeContactNumber}} &nbsp;
        </span>
        <span>
          <b>#Event:</b>
          {{ this.value.alertsCount}} &nbsp;
        </span>
        <br>
        <v-spacer></v-spacer>
        <v-text-field append-icon="search" label="Search" single-line hide-details v-model="search"></v-text-field>
      </v-card-title>
      <v-data-table
        :headers="headers"
        :items="site.alerts"
        item-key="id"
        class="elevation-1"
        v-bind:search="search"
      >
        <template slot="headerCell" slot-scope="props">
          <v-tooltip bottom>
            <span slot="activator">{{ props.header.text }}</span>
            <span>{{ props.header.text }}</span>
          </v-tooltip>
        </template>
        <tr slot="items" slot-scope="props" :class="getEventClass(props.item)">
          <td>{{ props.item.created_at }}</td>
          <td class="text-xs-right">{{ props.item.event_type }}</td>
          <td class="text-xs-right">{{ props.item.priority }}</td>
          <td class="text-xs-right">{{ props.item.ack ? 'Yes' : 'No' }}</td>
          <td class="text-xs-right">
            <v-btn color="blue" flat icon @click="showEventDetail(props.item)">
              <v-icon>search</v-icon>
            </v-btn>
            <v-btn color="teal" flat icon @click="muteEvent(props.item)" :disabled="props.item.ack">
              <v-icon>volume_mute</v-icon>
            </v-btn>
          </td>
        </tr>
      </v-data-table>
    </v-card-text>
  </v-card>
</template>

<script>
import Site from "../../models/Site";
export default {
  props: {
    value: {
      type: Object,
      required: false
    }
  },
  data: () => ({
    search: "",
    headers: [
      {
        text: "Timestamp",
        align: "left",
        value: "name"
      },
      { text: "Type", value: "event_type" },
      { text: "Priority", value: "priority" },
      { text: "Ack", value: "ack" }
    ],
    site: {}
  }),
  methods: {
    getEventClass(event) {
      return {
        red:
          window._.snakeCase(event.event_type).toLowerCase() === "panic_alert" ||
          window._.snakeCase(event.event_type).toLowerCase() === "incident",
        green:
          window._.snakeCase(event.event_type).toLowerCase() === "trip_start" ||
          window._.snakeCase(event.event_type).toLowerCase() === "patrol_start",
        grey:
          window._.snakeCase(event.event_type).toLowerCase() === "call_me" ||
          window._.snakeCase(event.event_type).toLowerCase() === "call_back",
        blue:
          window._.snakeCase(event.event_type).toLowerCase() === "trip_end" ||
          window._.snakeCase(event.event_type).toLowerCase() === "patrol_complete",
        orange:
          window._.snakeCase(event.event_type).toLowerCase() !== "panic_alert" &&
          window._.snakeCase(event.event_type).toLowerCase() !== "trip_start" &&
          window._.snakeCase(event.event_type).toLowerCase() !== "patrol_start" &&
          window._.snakeCase(event.event_type).toLowerCase() !== "call_me" &&
          window._.snakeCase(event.event_type).toLowerCase() !== "call_back" &&
          window._.snakeCase(event.event_type).toLowerCase() !== "incident" &&
          window._.snakeCase(event.event_type).toLowerCase() !== "patrol_complete" &&
          window._.snakeCase(event.event_type).toLowerCase() !== "trip_end",
        "lighten-4": true
      };
    },

    muteEvent(notification) {
      this.$store.dispatch("session/removeNotification", notification);
    },

    showEventDetail(notification) {
      window.location = `/event-feed/${notification.id}`;
    }
  },
  mounted() {},
  created() {
    this.site = this.value;
    axios
      .get(`/api/alerts/${this.site.id}`, this.site)
      .then(response => {
        response.data.result.forEach(event => {
          switch (event.event_type) {
            case "panic_alert" || "guard_call_me"  || "incident": {
              event.priority = "High";
              break;
            }
            default: {
              event.priority = "Low";
              break;
            }
          }
          event.event_type = window._.startCase(event.event_type);
          this.site.alerts.push(event);
        });
      })
      .catch(error => {
        EventBus.$emit(
          "notify",
          "error",
          `Error retriving site events: ${error.response}`
        );
      });
  },
  beforeDestroy() {}
};
</script>

<style scoped>
</style>