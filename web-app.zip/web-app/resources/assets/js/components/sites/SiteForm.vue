<template>
  <form>
    <v-text-field v-model="site.name" label="Site Name" :error-messages="errors.collect('name')" v-validate="'required'" data-vv-name="name" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="site.description" label="Site Description" :error-messages="errors.collect('description')" v-validate="'required'" data-vv-name="description" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="site.address" label="Site Address" :error-messages="errors.collect('address')" v-validate="'required'" data-vv-name="address" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="site.contact_number" label="Contact Number"
                      :error-messages="errors.collect('contact_number')" v-validate="'required'"
                      data-vv-name="contact_number" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="site.alternative_contact_number" label="Alternative Contact Number"
                      :error-messages="errors.collect('alternative_contact_number')" 
                      data-vv-name="alternative_contact_number" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="site.latitude" label="Site Latitude" :error-messages="errors.collect('latitude')" v-validate="'required'" data-vv-name="latitude" required :disabled="disabled"></v-text-field>
    <v-text-field v-model="site.longitude" label="Site Longitude" :error-messages="errors.collect('longitude')" v-validate="'required'" data-vv-name="longitude" required :disabled="disabled"></v-text-field>
    <!-- <v-text-field mask="##" v-model="site.patrol_rounds_required" label="Patrol Rounds Required" :error-messages="errors.collect('patrol_rounds_required')" v-validate="'required'" data-vv-name="patrol_round_required" required :disabled="disabled"></v-text-field> -->
  </form>
</template>

<script>
import Site from '../../models/Site';

export default {
  props: {
    value: {
      required: true,
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false,
    }
  },
  data: () => ({
    site: {},
  }),
  methods: {
    submit () {
      this.$validator.validateAll()
    },

    clear () {
      this.site.name = ''
      this.site.address = ''
      this.$validator.clean()
    },
  },
  mounted() {
    this.site = new Site(this.value);
  },
  watch: {
    site: {
      handler: function(newValue) {
        this.$emit('input', this.site);
        this.$validator.validateAll()
        .then(result => {
          this.$emit('formisvalid', result);
        });
      },
      deep: true
    },
  }
}
</script>
