<template>
  <v-stepper v-model="e1">
    <v-stepper-header>
      <v-stepper-step class="teal--text" step="1" :complete="e1 > 1">Choose Client</v-stepper-step>
      <v-divider></v-divider>
      <v-stepper-step step="2" :complete="e1 > 2">Choose Security Company</v-stepper-step>
      <v-divider></v-divider>
      <v-stepper-step step="3" :complete="e1 > 3">Setup Site</v-stepper-step>
      <v-divider></v-divider>
      <v-stepper-step step="4">Review</v-stepper-step>
    </v-stepper-header>
    <v-stepper-content step="1">
      <v-select
        label="Client Name"
        autocomplete
        :loading="loaders.client"
        cache-items
        required
        :items="clientList"
        :search-input.sync="clientSearch"
        v-model="clientId"
        prepend-icon="people"
        item-text="name"
        item-value="id"
      ></v-select>
      <v-btn color="teal" @click.native="e1 = 2" :disabled="!formValid.stepOne">Continue</v-btn>
    </v-stepper-content>
    <v-stepper-content step="2">
      <v-select
        label="Security Company Name"
        autocomplete
        :loading="loaders.securityCompany"
        cache-items
        required
        :items="securityCompanyList"
        :search-input.sync="securityCompanySearch"
        v-model="securityCompanyId"
        prepend-icon="security"
        item-text="name"
        item-value="id"
      ></v-select>
      <v-btn color="teal" @click.native="e1 = 3" :disabled="!formValid.stepTwo">Continue</v-btn>
      <v-btn flat @click.native="e1 = 1">Back</v-btn>
    </v-stepper-content>
    <v-stepper-content step="3">
      <h5>Site Details</h5>
      <site-form v-model="site" v-on:formisvalid="updateSiteFormValidation"></site-form>
      <h5>Patrol Details</h5>
      <shift-form v-model="site.shifts"></shift-form>
      <v-btn color="teal" @click.native="e1 = 4" :disabled="!formValid.stepThree">Continue</v-btn>
      <v-btn flat @click.native="e1 = 2">Back</v-btn>
    </v-stepper-content>
    <v-stepper-content step="4">
      <v-card color="teal lighten-5" class="mb-5">
        <v-card-title>Client Details</v-card-title>
        <v-card-text>
          <client-form v-if="formValid.stepOne" v-model="client" :disabled="true"></client-form>
        </v-card-text>
      </v-card>
      <v-card color="teal lighten-5" class="mb-5">
        <v-card-title>Security Company Details</v-card-title>
        <v-card-text>
          <security-company-form
            v-if="formValid.stepTwo"
            v-model="securityCompany"
            :disabled="true"
          ></security-company-form>
        </v-card-text>
      </v-card>
      <v-card color="teal lighten-5" class="mb-5">
        <v-card-title>Site Details</v-card-title>
        <v-card-text>
          <site-form v-if="formValid.stepThree" v-model="site" :disabled="true"></site-form>
        </v-card-text>
      </v-card>
      <v-card color="teal lighten-5" class="mb-5">
        <v-card-title>Shift Details</v-card-title>
        <v-card-text>
          <shift-form v-if="formValid.stepThree" v-model="site.shifts" :disabled="true"></shift-form>
        </v-card-text>
      </v-card>
      <v-btn
        color="teal"
        @click.native="createNewSite()"
        :disabled="!formValid.stepOne || !formValid.stepTwo || !formValid.stepThree"
      >Create Site</v-btn>
      <v-btn flat @click.native="e1 = 3">Back</v-btn>
    </v-stepper-content>
  </v-stepper>
</template>

<script>
import User from "../../models/User";
import Site from "../../models/Site";
import { EventBus } from "../../utils/event-bus";
import SiteForm from "./SiteForm";
import ShiftForm from "../shifts/ShiftsForm";
import ClientForm from "../clients/ClientForm";
import SecurityCompanyForm from "../securityCompanies/SecurityCompanyForm";

export default {
  components: {
    SiteForm,
    ShiftForm,
    ClientForm,
    SecurityCompanyForm
  },
  data: () => ({
    client: null,
    clientId: 0,
    clientList: [],
    clientSearch: null,
    e1: 0,
    formValid: {
      stepOne: false,
      stepTwo: false,
      stepThree: false
    },
    loaders: {
      client: false,
      securityCompany: false
    },
    securityCompany: null,
    securityCompanyId: 0,
    securityCompanyList: [],
    securityCompanySearch: null,
    site: {}
  }),
  methods: {
    createNewSite() {
      this.site.client_id = this.client.id;
      this.site.security_company_id = this.securityCompany.id;
      axios
        .put(`/api/site/`, {
          site: this.site
        })
        .then(response => {
          // Site successfully created
          EventBus.$emit("notify", "success", "Site successfully created!");
          setTimeout(() => {
            window.location.reload();
          }, 2500);
        })
        .catch(error => {
          let errorMessages = [];
          for (const errorMessage in error.response.data.errors) {
            errorMessages.push(error.response.data.errors[errorMessage]);
          }

          // Site could not be created
          EventBus.$emit(
            "notify",
            "error",
            `Error creating site: ${errorMessages}`
          );
        });
    },

    updateSiteFormValidation(validationStatus) {
      if (validationStatus === true) {
      }
      this.formValid.stepThree = validationStatus;
    },

    queryClientSelection(v) {
      this.loaders.client = true;
      axios
        .get(`/api/client/search?content=${v}`)
        .then(response => {
          this.clientList = response.data.result;
        })
        .catch(error => {
          EventBus.$emit(
            "notify",
            "error",
            "Clients could not be retrieved. Please try again later."
          );
        })
        .then(() => {
          this.loaders.client = false;
        });
    },

    querySecurityCompanySelection(v) {
      this.loaders.securityCompany = true;
      axios
        .get(`/api/security-company/search?content=${v}`)
        .then(response => {
          this.securityCompanyList = response.data.result;
        })
        .catch(error => {
          EventBus.$emit(
            "notify",
            "error",
            "Security Companies could not be retrieved. Please try again later."
          );
        })
        .then(() => {
          this.loaders.securityCompany = false;
        });
    }
  },
  created() {
    this.user = new User();
    this.site = new Site();
  },
  watch: {
    clientSearch(val) {
      val && this.queryClientSelection(val);
    },

    clientId(val) {
      if (val !== 0) {
        this.client = window._.find(this.clientList, ["id", val]);
        this.formValid.stepOne = true;
      } else {
        this.formValid.stepOne = false;
      }
    },

    securityCompanySearch(val) {
      val && this.querySecurityCompanySelection(val);
    },

    securityCompanyId(val) {
      if (val !== 0) {
        this.securityCompany = window._.find(this.securityCompanyList, [
          "id",
          val
        ]);
        this.formValid.stepTwo = true;
      } else {
        this.formValid.stepTwo = false;
      }
    }
  }
};
</script>
