<template>
  <v-card>
    <v-card-title>
      <v-spacer></v-spacer>
      <v-text-field append-icon="search" label="Search" single-line hide-details v-model="search"></v-text-field>
    </v-card-title>
    <v-data-table id="sitesDataTable" v-bind:headers="headers" v-bind:items="items" v-bind:search="search">
      <template slot="items" slot-scope="props">
        <td>{{ props.item.name }}</td>
        <td class="text-xs-right">{{ props.item.address }}</td>
        <td class="text-xs-right">{{ props.item.clientName }}</td>
        <td class="text-xs-right">{{ props.item.contactNumber }}</td>
        <td class="text-xs-right">{{ props.item.alternativeContactNumber }}</td>
        <td class="text-xs-right">{{ props.item.alertsCount }}</td>
        <td class="text-xs-right">
          <v-menu bottom right>
            <v-btn icon slot="activator" light>
              <v-icon>more_vert</v-icon>
            </v-btn>
            <v-list>
              <v-list-tile
                v-for="(action, key) in props.item.actions"
                :key="key"
                @click.native="performActionOnSite(action.name, props.item)"
              >
                <v-list-tile-title>{{ action.name }}</v-list-tile-title>
              </v-list-tile>
            </v-list>
          </v-menu>
        </td>
      </template>
      <template
        slot="pageText"
        slot-scope="{ pageStart, pageStop }"
      >From {{ pageStart }} to {{ pageStop }}</template>
    </v-data-table>
    <delete-site
      v-if="canDeleteSite && modal.delete.show"
      v-model="modal.delete.data"
      v-on:close-dialog="closeDialog()"
    ></delete-site>
  </v-card>
</template>

<script>
import DeleteSite from "./DeleteSite";
import { mapGetters } from "vuex";
export default {
  props: {
    site: {
      type: Object,
      required: false
    },
    sites: {
      type: Array,
      required: true
    }
  },
  components: {    
    DeleteSite
  },
  data: () => ({
    search: "",
    headers: [
      {
        text: "Name",
        align: "left",
        sortable: false,
        value: "name"
      },
      { text: "Address", value: "address" },
      { text: "Client", value: "clientName" },
      { text: "Contact No", value: "contactNumber" },
      { text: "Alt Contact No", value: "alternativeContactNumber" },
      { text: "# Events", value: "alertsCount" },
      { text: "", value: "actions" }
    ],
    items: [],
    modal: {
      delete: {
        data: {},
        show: false
      }
    },
    canEditSite: false,
    canDeleteSite: false
  }),
  computed: {
    ...mapGetters({
      permissions: "session/permissions"
    })
  },
  methods: {
    closeDialog() {
      for (const field in this.modal) {
        this.modal[field].show = false;
      }
    },

    performActionOnSite(actionName, site) {
      if (actionName === "Edit" || actionName === "View") {
        this.$emit("edit", site);
      }else if(actionName === "Events"){        
        this.$emit("site-events", site);
      } else {
        this.modal[window._.camelCase(actionName)].data = site;
        this.modal[window._.camelCase(actionName)].show = true;
      }
    },

    countSiteEvents(site) {
      axios
        .get(`/api/alerts/count/${site.id}`, this.event)
        .then(response => {
          site["alertsCount"] = response.data.alertsCount;
          site["alerts"] =[];
          this.$set(this.items, (this.items.length - 0), site);
        })
        .catch(error => {
          EventBus.$emit(
            "notify",
            "error",
            `Error retriving site events: ${error}`
          );
        });        
    },

    prepData() {
      this.canEditSite = window._.find(this.permissions, { name: "Edit Site" })
        ? true
        : false;
      this.canDeleteSite = window._.find(this.permissions, {
        name: "Delete Site"
      })
        ? true
        : false;
    this.sites.forEach(site => {
        site["clientName"] = site.client.name;
        site["contactNumber"] = site.contact_number;
        site["alternativeContactNumber"] = site.alternative_contact_number;
        site["actions"] = [];
        this.countSiteEvents(site);
        site["actions"].push({
          name: "Events"
        });
        if (this.canEditSite) {
          site["actions"].push({
            name: "Edit"
          });
        } else {
          site["actions"].push({
            name: "View"
          });
        }
        if (this.canDeleteSite) {
          site["actions"].push({
            name: "Delete"
          });
        }
      });      
    }
    
  },
  created(){
    this.prepData();  
  },
  mounted() {
      
  },
  beforeDestroy() {}
};
</script>

<style scoped>
</style>
