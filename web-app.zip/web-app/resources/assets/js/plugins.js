// const toasted = require('lodash');
const notify = require('./utils/notify');
// const store = require('./store/index');

export default {
	notify,
	store,
	// toasted,
	install(Vue, options) {
		// Vue.prototype.$toasted = toasted;
		Vue.prototype.$notify = notify;
		// Vue.prototype.$store = store;
	},
}
