import { EventBus } from './event-bus';

function error(text) {
  EventBus.$emit('notify', 'error', text);
}

function info(text) {
  EventBus.$emit('notify', 'info', text);
}

function success(text) {
  EventBus.$emit('notify', 'success', text);
}

function warning(text) {
  EventBus.$emit('notify', 'warning', text);
}

export default {
  error,
  info,
  success,
  warning,
};
