export default function Client(clientData) {
  const client = clientData || {};

  this.id = client.id || null;
  this.name = client.name || '';
  this.address = client.address || '';
  this.manager_id = client.manager_id || '';
  this.manager_type = client.manager_type || '';
  this.contact_number = client.contact_number || '';
  this.alternative_contact_number = client.alternative_contact_number || '';
}
