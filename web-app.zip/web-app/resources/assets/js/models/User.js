export default function User(userData) {
  const user = userData || {};

  this.id = user.id || null;
  this.first_name = user.first_name || '';
  this.last_name = user.last_name || '';
  this.email = user.email || '';
  this.contact_number = user.contact_number || '';
  this.alternative_contact_number = user.alternative_contact_number || '';
  this.associated_roles = user.associated_roles || [];
}
