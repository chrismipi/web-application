export default function NfcTag(nfcTagData) {
  const nfcTag = nfcTagData || {};

  this.id = nfcTag.id || null;
  this.serial_no = nfcTag.serial_no || '';
  this.latitude = nfcTag.latitude || '';
  this.longitude = nfcTag.longitude || '';
  this.sequence_no = nfcTag.sequence_no || 0;
}
