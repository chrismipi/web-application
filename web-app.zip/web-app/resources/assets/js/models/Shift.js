export default function Shift(securityCompanyData) {
  const securityCompany = securityCompanyData || {};

  this.id = securityCompany.id || null;
  this.site_id = securityCompany.site_id || '';
  this.start_time = securityCompany.start_time || '';
  this.end_time = securityCompany.end_time || '';
  this.patrol_count = securityCompany.patrol_count || '';
  this.rest_time = securityCompany.rest_time || '';
  this.trip_duration = securityCompany.trip_duration || '';  
  this.day_of_week = securityCompany.day_of_week || 0;
}
