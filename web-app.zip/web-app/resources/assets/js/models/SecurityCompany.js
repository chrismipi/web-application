export default function SecurityCompany(securityCompanyData) {
  const securityCompany = securityCompanyData || {};

  this.id = securityCompany.id || null;
  this.name = securityCompany.name || '';
  this.manager_id = securityCompany.manager_id || '';
  this.manager_type = securityCompany.manager_type || '';
  this.contact_number = securityCompany.contact_number || '';
  this.alternative_contact_number = securityCompany.alternative_contact_number || '';
}
