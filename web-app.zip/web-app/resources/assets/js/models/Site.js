export default function Site(siteData) {
  const site = siteData || {};

  this.id = site.id || null;
  this.name = site.name || '';
  this.description = site.description || '';
  this.address = site.address || '';
  this.shifts = site.shifts || [];
  this.nfc_tags = site.nfc_tags || [];
  this.latitude = site.latitude || '';
  this.longitude = site.longitude || '';
  this.client_id = site.client_id || '';
  this.security_company_id = site.security_company_id || '';
  this.contact_number = site.contact_number || '';
  this.alternative_contact_number = site.alternative_contact_number || '';
}
