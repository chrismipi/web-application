export default function UserClientLink(userClientLinkData) {
  const userClientLink = userClientLinkData || {};
  this.id = userClientLink.id || null;
  this.manager_id = userClientLink.manager_id || '';
  this.manager_type = userClientLink.manager_type || '';
  this.client_id = userClientLink.client_id || '';
}
