
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

// const Vuex = require('vuex');
// const CreatePersistedState = require('vuex-persistedstate');
const Vuetify = require('vuetify');
const VeeValidate = require('vee-validate');
// const plugins = require('./plugins');
// const Toasted = require('vue-toasted');
const store = require('./store/index').default;
const moment = require('moment');

// const store = new Vuex.Store({
//   plugins: [CreatePersistedState()]
// })

Vue.use(Vuetify);
Vue.use(VeeValidate);
// Vue.use(plugins);
// Vue.use(Toasted);
Vue.use(store);

Vue.filter('timeFromNow', function (time) {
	const friendlyTime = moment(time).fromNow();
	return friendlyTime;
})

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

/**
 * Layouts
 */

require('./layouts/index.js');

/**
 * Pages
 */
require('./pages/index.js');


const app = new Vue({
    el: '#app',
    store,
});
