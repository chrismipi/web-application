<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Shift extends Model
{
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'start_time', 'end_time', 'patrol_count', 'rest_time', 'trip_duration','day_of_week', 'created_at', 'updated_at', 'deleted_at',
    ];

    protected $casts = [
        'patrol_count' => 'integer',
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * Get the site that owns the shift.
     */
    public function site()
    {
        return $this->belongsTo('App\Site');
    }
}
