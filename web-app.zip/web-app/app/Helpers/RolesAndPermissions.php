<?php

namespace App\Helpers;

abstract class RolesAndPermissions
{
    // Roles
    const SuperAdminUser = 'Super Admin';
    const AdminUser = 'Admin';
    const OperatorUser = 'Operator';
    const ClientUser = 'Client Owner';
    const SecurityCompanyUser = 'Security Company Owner';
    const DeviceUser = 'Device User';

    // Permissions
    const AddAdmin = 'Add Admin';
    const ViewAdmin = 'View Admin';
    const EditAdmin = 'Edit Admin';
    const DeleteAdmin = 'Delete Admin';

    const AddOperator = 'Add Operator';
    const ViewOperator = 'View Operator';
    const EditOperator = 'Edit Operator';
    const DeleteOperator = 'Delete Operator';

    const AddSecurityCompany = 'Add Security Company';
    const ViewSecurityCompany = 'View Security Company';
    const EditSecurityCompany = 'Edit Security Company';
    const DeleteSecurityCompany = 'Delete Security Company';

    const AddUserClientLink = 'Add User Client Link';
    const ViewUserClientLink = 'View User Client Link';
    const EditUserClientLink = 'Edit User Client Link';
    const DeleteUserClientLink = 'Delete User Client Link';

    const AddSite = 'Add Site';
    const ViewSite = 'View Site';
    const EditSite = 'Edit Site';
    const DeleteSite = 'Delete Site';

    const AddClient = 'Add Client';
    const ViewClient = 'View Client';
    const EditClient = 'Edit Client';
    const DeleteClient = 'Delete Client';

    const ViewTrip = 'View Trip';

    const GenerateReport = 'Generate Report';
    const ViewReport = 'View Report';

    const ViewEvent = 'View Event';
    const ViewEventDetails = 'View Event Details';
}
