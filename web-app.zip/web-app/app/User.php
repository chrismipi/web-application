<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use Notifiable;
    use HasRoles;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'first_name', 'last_name', 'email', 'password', 'physical_address', 'contact_number',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token', 'associated_roles',
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['associated_roles', 'can_delete'];

    /**
     * Get the clients for the this user.
     */
    public function securityCompanies()
    {
        return $this->morphMany('App\SecurityCompany', 'manager');
    }

    /**
     * Get the clients for the this user.
     */
    public function clients()
    {
        return $this->morphMany('App\Client', 'manager');
    }

    public function fullNames()
    {
        return $this->attributes['first_name'] ." ". $this->attributes['last_name'];
    }

    public function getCanDeleteAttribute()
    {
        $clients = Client::where('manager_id', $this->attributes['id'])->get();
        $securityCompanies = SecurityCompany::where('manager_id', $this->attributes['id'])->get();

        $cl_count = count($clients);
        $se_count = count($securityCompanies);

        return ($cl_count == 0) && ($se_count == 0);
    }
    
    /**
     * Returns the associated roles for this user.
     */
    public function getAssociatedRolesAttribute()
    {
        $result = [];
        foreach ($this->getRoleNames() as $name) {
            $role = Role::findByName($name);
            array_push($result, [
                'id' => $role->id,
                'text' => $role->name,
            ]);
        }

        return $this->attributes['associated_roles'] = $result;
    }
}
