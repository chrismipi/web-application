<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Scout\Searchable;

class Client extends Model
{
    use SoftDeletes, Searchable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'address', 'created_at', 'updated_at', 'deleted_at','contact_number', 'alternative_contact_number',
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * Get the index name for the model.
     *
     * @return string
     */
    public function searchableAs()
    {
        return 'clients_index';
    }

    /**
     * Get the sites for the this client.
     */
    public function sites()
    {
        return $this->hasMany('App\Site');
    }

    /**
     * Get the user that manage this client.
     */
    public function manager()
    {
        return $this->morphTo();
        // return $this->belongsTo('App\User');
    }

  
}
