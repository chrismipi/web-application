<?php

namespace App\Providers;

use App\Alert;
use App\Client;
use App\SecurityCompany;
use App\Site;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Log;
use App\UserClientLink;

class ViewServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('*', function ($view) {
            $user = request()->user();

            $userName = 'User';
            $clients = [];
            $securityCompanies = [];
            $sites = [];
            $alerts = [];
            $permissions = [];
            $userRoles = [];

            if ($user) {
                $userName = $user->fullNames();

                $superAdminUser = Role::findByName('Super Admin');
                $adminUser = Role::findByName('Admin');

                foreach ($user["associated_roles"] as $role) {
                    array_push($userRoles, $role["text"]);
                }
                if ($user->hasRole([$superAdminUser, $adminUser])) {
                    $clients = Client::select('id')->get()->toArray();
                    $securityCompanies = SecurityCompany::select('id')->get()->toArray();
                    $sites = Site::select('id')->get()->toArray();
                } else {
                    $clients = $user->clients()->select('id')->get()->toArray();
                    $securityCompanies = $user->securityCompanies()->select('id')->get()->toArray();
                    $userClientLinks  = UserClientLink::where('manager_id', $user->id)->pluck('client_id')->toArray();
                    $sites = Site::whereIn('client_id', $userClientLinks)->pluck('id')->toArray();
                }
                $alerts = Alert::whereIn('site_id', $sites)->where('ack', false)->with(['site'])->get()->toArray();
                $permissions = $user->getPermissionsViaRoles();
            }

            View::share('data', [
                "userName" => $userName,
                "userRoles" => $userRoles,
                "clients" => $clients,
                "securityCompanies" => $securityCompanies,
                "sites" => $sites,
                "alerts" => $alerts,
                "permissions" => $permissions,
            ]);

            // $view->with('user', $user);
        });
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
