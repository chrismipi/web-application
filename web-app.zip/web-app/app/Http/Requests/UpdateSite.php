<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateSite extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $siteId = $this->input('id');
        $result = [
            'id' => 'required|exists:sites,id',
            'client_id' => 'required|exists:clients,id',
            'security_company_id' => 'required|exists:security_companies,id',
            'name' => [
                'required',
                'max:65',
                Rule::unique('sites')->ignore($siteId),
            ],
            'description' => 'required|max:65',
            // 'shifts' => 'required',
            'address' => 'required|max:65',
            'latitude' => 'required|regex:(\-?\d+(\.\d+)?)',
            'longitude' => 'required|regex:(\-?\d+(\.\d+)?)',
        ];

        return $result;
    }
}
