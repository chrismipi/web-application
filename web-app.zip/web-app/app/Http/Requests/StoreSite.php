<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreSite extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $result = [
            'site' => 'required',
            'site.client_id' => 'required|exists:clients,id',
            'site.security_company_id' => 'required|exists:security_companies,id',
            'site.name' => 'required|max:65|unique:sites,name',
            'site.description' => 'required|max:65',
            'site.contact_number' => 'required',
            // 'site.shifts' => 'required',
            'site.address' => 'required|max:65',
            'site.latitude' => 'required|regex:(\-?\d+(\.\d+)?)',
            'site.longitude' => 'required|regex:(\-?\d+(\.\d+)?)',
        ];

        return $result;
    }
}
