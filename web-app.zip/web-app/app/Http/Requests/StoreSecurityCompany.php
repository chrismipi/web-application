<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreSecurityCompany extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $result = [
            'user' => 'required',
            'user.id' => 'present',
            'user.first_name' => 'required|max:65',
            'user.last_name' => 'required|max:65',
            'user.contact_number' => 'required',
            'securityCompany' => 'required',
            'securityCompany.name' => 'required|unique:security_companies,name|max:255',
        ];

        $userObject = $this->input('user');
        if (!empty($userObject['id'])) {
            $result['user.email'] = "required|unique:users,email,{$userObject['id']}";
        } else {
            $result['user.email'] = 'required|unique:users,email';
        }

        return $result;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            // 'user.required' => 'A new security company needs to be linked to a user!',
            'securityCompany.required' => 'Please provide the security company details',
        ];
    }
}
