<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreClient extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $result = [
            'user' => 'required',
            'user.id' => 'present',
            'user.first_name' => 'required|max:65',
            'user.last_name' => 'required|max:65',
            'user.contact_number' => 'required|max:255',
            'client' => 'required',
            'client.name' => 'required|unique:clients,name|max:255',
            'client.address' => 'required|unique:clients,address|max:255',
            'client.contact_number' => 'required|max:255',
        ];

        $userObject = $this->input('user');
        if (!empty($userObject['id'])) {
            $result['user.email'] = "required|unique:users,email,{$userObject['id']}";
        } else {
            $result['user.email'] = 'required|unique:users,email';
        }

        return $result;
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            // 'user.required' => 'A new client needs to be linked to a user!',
            'client.required' => 'Please provide the client details',
        ];
    }
}
