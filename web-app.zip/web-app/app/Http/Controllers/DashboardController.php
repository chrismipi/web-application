<?php

namespace App\Http\Controllers;

use App\Alert;
use App\Client;
use App\SecurityCompany;
use App\Site;
use Auth;
use Spatie\Permission\Models\Role;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        $clients = [];
        $securityCompanies = [];
        $sites = [];

        $superAdminUser = Role::findByName('Super Admin');
        $adminUser = Role::findByName('Admin');

        if ($user->hasRole([$superAdminUser, $adminUser])) {
            $clients = Client::select('id')->get()->toArray();
            $securityCompanies = SecurityCompany::select('id')->get()->toArray();
            $sites = Site::select('id')->get()->toArray();
        } else {
            $clients = $user->clients()->select('id')->get()->toArray();
            $securityCompanies = $user->securityCompanies()->select('id')->get()->toArray();

            foreach ($user->clients() as $client) {
                $sites = array_unique(array_merge($sites, $client->sites()->select('id')));
            }

            foreach ($user->securityCompanies() as $securityCompany) {
                $sites = array_unique(array_merge($sites, $securityCompany->sites()->select('id')));
            }
        }

        $alerts = Alert::whereIn('site_id', $sites)->where('ack', false)->get()->toArray();

        return view('pages.dashboard', [
            "userName" => $user->fullNames(),
            "clients" => $clients,
            "securityCompanies" => $securityCompanies,
            "sites" => $sites,
            "alerts" => $alerts,
        ]);
    }
}
