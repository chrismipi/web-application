<?php

namespace App\Http\Controllers;

use App\Client;
use App\Http\Requests\StoreClient;
use App\Http\Requests\UpdateClient;
use App\Site;
use App\User;
use Auth;
use Illuminate\Http\Request;
use RolesAndPermissions;

use Illuminate\Support\Facades\Log;

class ClientsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the list of clients.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        $clients = [];

        if ($user->hasRole('Super Admin') || $user->hasRole('Admin') || $user->hasRole('Operator')) {
            $clients = Client::with(['manager', 'sites'])->get()->toArray();
        } else if ($user->hasRole('Security Company Owner')) {
            $securityCompanies = $user->securityCompanies;
            // TODO fix, make sure it pulls the clients which belong to the loged in user
            // TODO clean up
            $sites = Site::all();

            $securityCompanySites = [];
            foreach ($securityCompanies as $securityCompany) {
                $securityCompanySites = $securityCompany->sites->merge($securityCompanySites);
            }

            $securityCompanySiteClients = [];
            foreach ($securityCompanySites as $securityCompanySite) {
                array_push($securityCompanySiteClients, $securityCompanySite->client->with(['manager', 'sites'])->get());
            }

            // $clients = array_unique($securityCompanySiteClients)[0];
            // TODO: check what this next line does
            $clients = Client::where('manager_id', $user->id)->with(['manager', 'sites'])->get()->toArray();
        }
        return view('pages.clients', ['clients' => $clients]);
    }

    /**
     * Store a newly created client in database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreClient $request)
    {

        $user = User::where('email', $request->user['email'])->first();

        // Check if the given user is new or not and
        // create the user if new
        if (!$user) {
            $tempUserObj = $request->user;
            $tempUserObj['password'] = \Hash::make('manage');
            $user = User::create($tempUserObj);
        }

        // If the user does not have a client role, assign it.
        if (!$user->hasRole(RolesAndPermissions::ClientUser)) {
            $user->assignRole(RolesAndPermissions::ClientUser);
            $user->save();
        }

        $client = $user->clients()->create($request->client);

        return response()->json([
            'user' => $user,
            'client' => $client,
        ], 201);
    }

    /**
     * Update the specified client in database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Site  $site
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateClient $request, $id)
    {
        $client = Client::where('id', $id)->update($request->all());
        return response()->json($client, 200);
    }

    /**
     * Remove the specified client from database.
     *
     * @param  \App\Site  $site
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $client = Client::find($id);
        $client->forceDelete();
        return response()->json($client, 200);
    }

    /**
     * Searches the table for the given content.
     *
     * NOTE: For some reason, the call to the Scout
     * "get" method sometimes returns an associative
     * array. The iteration is to ensure the returned
     * structure is flat.
     */
    public function search(Request $request)
    {
        $result = [];
        $clients = Client::where('name', 'ilike', '%' . $request->query('content') . '%')->get()->toArray();
        return response()->json([
            'result' => $clients,
        ], 200);
    }
}
