<?php

namespace App\Http\Controllers;

use App\Client;
use App\UserClientLink;
use App\Http\Requests\StoreSite;
use App\Http\Requests\UpdateSite;
use App\NfcTag;
use App\SecurityCompany;
use App\Shift;
use App\Site;
use App\Alert;
use Auth;
use GuzzleHttp\Client as GuzzleClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class SitesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        Log::info("starting to get sites");
        $user = Auth::user();
        $sites = [];
        if ($user->hasRole('Super Admin') || $user->hasRole('Admin') || $user->hasRole('Operator')) {
            Log::info("User is Super Admin,Admin operator to get site");
            $sites = Site::with(['client', 'securityCompany', 'shifts', 'nfcTags', 'devices'])->get()->toArray();
        } else {
            Log::info("User is Security Company Owner or client owner to get site");
            $userClientLinks  = UserClientLink::where('manager_id', $user->id)->pluck('client_id')->toArray();
            $sites = Site::with(['client', 'securityCompany', 'shifts', 'nfcTags', 'devices'])->whereIn('client_id', $userClientLinks)->get()->toArray();
        }        
        Log::info("Ending to get sites");
        return view('pages.sites', ['sites' => $sites]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSite $request)
    {
        $client = Client::find($request->site['client_id']);
        $securityCompany = SecurityCompany::find($request->site['security_company_id']);

        $dataWithoutShifts = array_except($request->site, 'shifts');
        $site = Site::make($dataWithoutShifts);

        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        // Link all the new shifts
        $newShifts = [];
        foreach ($request->site['shifts'] as $shift) {
            $shiftObj = $site->shifts()->save(new Shift($shift));
            $tempShift = $shiftObj;

            $tempShift['device_id'] = $site->devices()->get()->toArray()[0]['id'] ?? 0;
            $tempShift['device_token'] = $site->devices()->get()->toArray()[0]['device_token'] ?? '0';
            array_push($newShifts, $tempShift);
        }
        $site->save();
        Log::info(print_r($newShifts, true));
        // Update Site Config on CouchDB
        $this->sendRequest('POST', '/api/shift-config/', $newShifts);

        return response()->json([
            'site' => $site,
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateSite $request, $id)
    {
        Log::info("Updating Site");
        Log::info("Delete all the previous shifts");
        $site = Site::find($id);
        $oldShifts = [];
        foreach ($site->shifts as $shift) {
            array_push($oldShifts, $shift->id);
        }
        $site->shifts()->delete();
        $site->save();

        Log::info("Update Site Config on CouchDB");
        if ($oldShifts != null) {
            $this->sendRequest('DELETE', '/api/shift-configs/', $oldShifts);
        }
        Log::info("Link all the new shifts");
        $newShifts = [];
        foreach ($request->shifts as $shift) {
            $shiftObj = $site->shifts()->save(new Shift($shift));
            $tempShift = $shiftObj;

            $tempShift['device_id'] = $site->devices()->get()->toArray()[0]['id'] ?? 0;
            $tempShift['device_token'] = $site->devices()->get()->toArray()[0]['device_token'] ?? '0';
            array_push($newShifts, $tempShift);
        }
        $site->save();
        Log::info(print_r($newShifts, true));
        Log::info("Update Site Config on CouchDB");
        $this->sendRequest('POST', '/api/shift-config/', $newShifts);
        $withoutShifts = array_except($request->all(), ['shifts', 'nfc_tags']);
        $site = Site::where('id', $id)->update($withoutShifts);
        Log::info("Done Updating Site");
        return response()->json($withoutShifts, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Log::info("Deleting Site");
        Log::info("delete shifts first");
        $site = Site::find($id);
        $oldShifts = [];
        foreach ($site->shifts as $shift) {
            array_push($oldShifts, $shift->id);
        }
        $site->shifts()->forceDelete();
        $site->save();
        Log::info("Update Site Config on CouchDB");
        if ($oldShifts != null) {
            $this->sendRequest('DELETE', '/api/shift-configs/', $oldShifts);
        }       
        Log::info("then delete sites");
        $site = Site::find($id);
        $site->forceDelete();
        Log::info("Done Deleting Site");
        return response()->json($site, 200);
    }

    public function deletetag($id)
    {
        $tag = NfcTag::find($id);
        $tag->forceDelete();
        return response()->json($tag, 200);
    }

    public function sendRequest($method, $url, $data)
    {
        $client = new GuzzleClient([
          //  'base_uri' => 'http://api:8000',
          'base_uri' => 'http://dycom-backend:9090',
            // 'base_uri' => env('UTILITY_SERVICE_HOST'),
            'defaults' => [
                'exceptions' => false,
            ],
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Basic emNvdWNoX2R5Y29tX3BhdHJvbHM6VyFza0V5RCFzdGlsbCZy',
                // 'Authorization' => env('UTILITY_SERVICE_AUTH'),
            ],
        ]);

        return $client->request($method, $url, ['json' => $data]);
    }
}
