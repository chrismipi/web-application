<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUser;
use App\Http\Requests\UpdateUser;
use App\Site;
use App\User;
use Auth;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();

        $users = [];

        if ($user->hasRole('Super Admin') || $user->hasRole('Admin')) {
            $users = User::all()->makeVisible(['associated_roles', 'clients', 'securityCompanies']);
        } else {
            $users = [];
        }


        return view('pages.users', [
            'users' => $users,
        ]);
    }

    /**
     * Store a newly created user in database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreUser $request)
    {
        $tempUserObj = $request->user;
        unset($tempUserObj['id']);

        if (!$tempUserObj['password']) {
            $tempUserObj['password'] = \Hash::make('manage');
        } else {
            $tempUserObj['password'] = \Hash::make($tempUserObj['password']);
        }

        $user = User::create($tempUserObj);

        // Assign roles to the user
        foreach ($request->user['associated_roles'] as $roleId) {
            $role = Role::find($roleId);
            $user->assignRole($role);
        }

        return response()->json([
            'user' => $user,
        ], 201);
    }

    /**
     * Update the specified user in database.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Site  $site
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUser $request, $id)
    {
        $user = User::find($id);

        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->contact_number = $request->contact_number;
        $user->alternative_contact_number = $request->alternative_contact_number;
        $user->email = $request->email;

        if ($request->password) {
            $user->password = \Hash::make($request->password);
        }

        $roles = [];
        foreach ($request->associated_roles as $associated_role) {
            if (!empty($associated_role['text'])) {
                array_push($roles, Role::findByName($associated_role['text'])->name);
            } else if (!empty($associated_role['id'])) {
                array_push($roles, Role::find($associated_role['id'])->name);
            } else {
                array_push($roles, Role::find($associated_role)->name);
            }
        }

        // Sync the user roles
        $user->syncRoles($roles);

        $user->save();

        return response()->json([
            'user' => $user,
        ], 200);
    }

    /**
     * Remove the specified user from database.
     *
     * @param  \App\Site  $site
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::find($id);
        $user->forceDelete();
        return response()->json($user, 200);
    }

    /**
     * Verifies wheather a user exists in the DB or not...
     *
     * @return \Illuminate\Http\Response
     */
    public function verifyUser(String $email)
    {
        return response()->json([
            'user' => User::where('email', $email)->first() ?? false,
        ]);
    }

    /**
     * Searches the table for the given content.
     *
     * NOTE: For some reason, the call to the Scout
     * "get" method sometimes returns an associative
     * array. The iteration is to ensure the returned
     * structure is flat.
     */
    public function search(Request $request)
    {
        $result = [];
        $users = User::where('email', 'ilike', '%' . $request->query('content') . '%')->get()->toArray();
        return response()->json([
            'result' => $users,
        ], 200);
    }
}
