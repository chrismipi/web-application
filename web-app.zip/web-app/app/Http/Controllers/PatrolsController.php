<?php

namespace App\Http\Controllers;

use App\Alert;
use App\Client;
use App\Events\AlertEvent;
use App\SecurityCompany;
use App\Shift;
use App\Site;
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\UserClientLink;

class PatrolsController extends Controller
{
    /**
     * Show the patrol overview.
     *
     * @return \Illuminate\Http\Response
     */
    public function overview()
    {
        return view('pages.patrols.overview', [
            'patrols' => [
                'active' => [],
                'upcomming' => [],
                'counts' => [
                    'tripsThisWeek' => 155,
                    'alerts' => 3,
                    'callMe' => 7,
                ],
            ],
        ]);
    }

    /**
     * Show list of active patrols.
     *
     * Returns all the shift that are meant to be running at the moment.
     *
     */
    public function activePatrols()
    {
        $user = Auth::user();
        $sites = [];

        if ($user->hasRole('Super Admin') || $user->hasRole('Admin')) {
            $sites = Site::select('id');
        } else {
            Log::info("User is Security Company Owner or client owner to activePatrols");
            $userClientLinks  = UserClientLink::where('manager_id', $user->id)->pluck('client_id')->toArray();
            Log::info("Found userClientLinks ********".count($userClientLinks));
            $sites = Site::whereIn('client_id', $userClientLinks)->pluck('id')->toArray();    
        }

        $allShifts = Shift::whereIn('site_id', $sites)->with('site')->get()->toArray();

        $activeShifts = [];
        $now = Carbon::now();
        foreach ($allShifts as $shift) {
            $startHour = substr($shift['start_time'], 0, 2);
            $endHour = substr($shift['end_time'], 0, 2);

            if ($startHour > $endHour || $startHour == $endHour) {
                // Set the end time to the following day
                $endTime = Carbon::createFromFormat('G:i', str_replace("h", ":", $shift['end_time']))->addDays(1);
            } else {
                $endTime = Carbon::createFromFormat('G:i', str_replace("h", ":", $shift['end_time']));
            }

            $startTime = Carbon::createFromFormat('G:i', str_replace("h", ":", $shift['start_time']));

            if ($now->between($startTime, $endTime)) {
                array_push($activeShifts, $shift);
            }
        }

        $events = Alert::whereIn('site_id', $sites)->where('event_type', 'TRIP_START')->with('site')->get()->toArray();

        return view('pages.patrols.active', [
            'events' => $events,
            'patrols' => $activeShifts,
        ]);
    }

    /**
     *
     * Show list of upcomming patrols
     */
    public function upcommingPatrols()
    {
        $user = Auth::user();
        $sites = [];

        if ($user->hasRole('Super Admin') || $user->hasRole('Admin')) {
            $sites = Site::select('id');
        } else {
            Log::info("User is Security Company Owner or client owner to activePatrols");
            $userClientLinks  = UserClientLink::where('manager_id', $user->id)->pluck('client_id')->toArray();
            Log::info("Found userClientLinks ********".count($userClientLinks));
            $sites = Site::whereIn('client_id', $userClientLinks)->pluck('id')->toArray();  
        }

        $allShifts = Shift::whereIn('site_id', $sites)->with('site')->get()->toArray();

        $upcommingShifts = [];
        $now = Carbon::now();
        foreach ($allShifts as $shift) {
            $startTime = Carbon::createFromFormat('G:i', str_replace("h", ":", $shift['start_time']));
            if ($now->diffInHours($startTime, false) > 0 && $now->diffInHours($startTime, false) < 1) {
                array_push($upcommingShifts, $shift);
            }
        }

        $events = Alert::whereIn('site_id', $sites)->where('event_type', 'TRIP_START')->with('site')->get()->toArray();

        return view('pages.patrols.upcomming', [
            'events' => $events,
            'patrols' => $upcommingShifts,
        ]);
    }

    /**
     * Show patrol history list.
     *
     */
    public function patrolHistory()
    { 

        $user = Auth::user();
        $sites = [];
        if ($user->hasRole('Super Admin') || $user->hasRole('Admin')) {
            $sites = Site::select('id');
        } else {
            Log::info("User is Security Company Owner or client owner to patrolHistory");
            $userClientLinks  = UserClientLink::where('manager_id', $user->id)->pluck('client_id')->toArray();
            Log::info("Found userClientLinks ********".count($userClientLinks));
            $sites = Site::whereIn('client_id', $userClientLinks)->pluck('id')->toArray();  
        }

        $patrols = Alert::whereIn('site_id', $sites)->where('event_type', 'TRIP_START')->with('site')->get()->toArray();

        return view('pages.patrols.history', [
            'patrols' => $patrols,
        ]);
    }

    /**
     * Show the patrol configuration view.
     *
     * @return \Illuminate\Http\Response
     */
    public function configure()
    {
        return view('pages.patrols.configuration', [
            'sites' => Site::all(),
        ]);
    }

    /**
     * Shows the notifications for the application.
     */
    public function viewNotifications(Request $request, $siteId, $notificationTimestamp)
    {
        // $notification = explode("-", $notificationId, 2);
        return view('pages.patrols.notifications', [
            'activeNotification' => [
                "site_id" => $siteId,
                "timestamp" => $notificationTimestamp,
            ],
        ]);
    }

    /**
     * Handles the publication of a new alert event.
     */
    public function publishAlertNotification(Request $request)
    {
        event(new AlertEvent($request->all()));

        return response()->json([
            'message' => 'Event Successfully Published!',
        ]);
    }
}
