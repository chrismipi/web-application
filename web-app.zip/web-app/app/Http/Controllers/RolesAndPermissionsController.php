<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use App\User;
use Spatie\Permission\Traits\HasRoles;

class RolesAndPermissionsController extends Controller
{

    /**
     * Get all the registered roles.
     *
     * @param $userRole
     * @return \Illuminate\Http\Response
     */
    public function getRoles($userRole)
    {        
        $user = Auth::user();
        $allRoles = Role::all();
        $roles = [];
        foreach ($allRoles as $role) {
            if (strtolower($userRole) == strtolower('Super Admin') ){
                $roles = $allRoles;
                break;        
            }else{
                //&& strtolower($role['name']) != strtolower('Admin')
                if(strtolower($role['name']) != strtolower('Super Admin')){
                    array_push($roles, $role);
                }
            }
        }
        return response()->json([
            'roles' => $roles,
        ], 200);
    }
}
