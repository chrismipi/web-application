<?php

namespace App\Http\Controllers;

use App\Alert;
use App\Events\AlertEvent;
use App\Site;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\UserClientLink;
use Carbon\Carbon;


class EventFeedController extends Controller
{
    /**
     * Show the event-feed overview.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Due to limitations with Postgres, simple "group by" will not work.
        $user = Auth::user();
        $sites = [];
        $eventBySites = [];
        $alertsLength = 0;
        if ($user->hasRole('Super Admin') || $user->hasRole('Admin') || $user->hasRole('Operator')) {
            $sites = Site::all();
        } else {
            $userClientLinks  = UserClientLink::where('manager_id', $user->id)->pluck('client_id')->toArray();
            $sites = Site::whereIn('client_id', $userClientLinks)->get();
        }
        foreach ($sites as $site) {
            array_push($eventBySites, [
                "site_id" => $site->id,
                "name" => $site->name,
                'alertsLength' => Alert::where('site_id', $site->id)->count()
            ]);
        }
        return view('pages.event-feed', [
            "events" => $eventBySites,
        ]);
    }

     /**
     * Show the event-feed overview.
     *
     * @return \Illuminate\Http\Response
     */
    public function countSiteEvents(Request $request, $siteId)
    {       
        $count =  Alert::where('site_id',$siteId)->count();
        return response()->json([
            'alertsCount' => $count,
        ], 200);
    }

    /**
     * Show the event-feed overview.
     *
     * @return \Illuminate\Http\Response
     */
    public function siteEvents(Request $request, $siteId)
    {
        $alerts = Alert::with(['site.client.manager', 'site.devices'])->where('site_id', $siteId)->where("created_at", ">", Carbon::now()->subMonths(1))->orderBy('ack', 'asc')->orderBy('created_at', 'desc')->get()->toArray();
        return response()->json([
            'result' => $alerts,
        ], 200);
    }

    /**
     * Marks a given notification as acknowledged
     */
    public function get(Request $request, $alertId)
    {
        $alert = Alert::find($alertId);
        $alert->ack = true;
        $alert->save();
        return response()->json([
            "message" => "Event Successfully Acknowledged!",
        ]);
    }

    /**
     * Show a specific event detail.
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $eventId)
    {
        return view('pages.event-feed', [
            "event" => Alert::where('id', $eventId)->with(['site.client.manager', 'site.devices'])->where("created_at", ">", Carbon::now()->subMonths(2))->get()[0] ?? null,
        ]);
    }

    /**
     * Handles the publication of a new alert event.
     */
    public function handleAlertEvent(Request $request)
    {

        $tempAlertObj = $request->all();

        $eventTitle = "Notification";
        $eventContext = "info";

        // Setup the alert type
        switch ($tempAlertObj['event_type']) {
            case 'device_register': {
                    $eventTitle = 'New Guard Device Registered';
                    break;
                }
            case 'guard_sign_in': {
                    $eventTitle = 'Guard Signed In';
                    break;
                }
            case 'failed_to_patrol': {
                    $eventTitle = 'Failed To Start Patrol';
                    break;
                }
            case 'device_offline': {
                    $eventTitle = 'Device has been offline for more than 30 minutes';
                    break;
                }
            case 'guard_sign_out': {
                    $eventTitle = 'Guard Signed Out';
                    break;
                }
            case 'panic_alert': {
                    $eventTitle = 'Guard Panic Alert';
                    $eventContext = "error";
                    break;
                }
            case 'incident': {
                    $eventTitle = 'Incident Report';
                    $eventContext = "error";
                    break;
                }
            case 'guard_call_me': {
                    $eventTitle = 'Guard Call Me Request';
                    $eventContext = "error";
                    break;
                }
            default: {
                    $eventTitle = "Notification";
                    $eventContext = "info";
                }
        }

        $tempAlertObj['title'] = $tempAlertObj['event_type'];
        $tempAlertObj['context'] = $eventContext;
        $tempAlertObj['ack'] = false;
        $alert = Alert::create($tempAlertObj);
        Log::info(print_r($alert, true));
        event(new AlertEvent($alert));

        return response()->json([
            'message' => 'Event Successfully Published!',
        ]);
    }

    /**
     * Marks a given notification as acknowledged
     */
    public function acknowledgeEvent(Request $request, $alertId)
    {
        $alert = Alert::find($alertId);
        $alert->ack = true;
        $alert->save();
        return response()->json([
            "message" => "Event Successfully Acknowledged!",
        ]);
    }
}
