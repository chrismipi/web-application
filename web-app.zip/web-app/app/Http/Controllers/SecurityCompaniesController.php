<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSecurityCompany;
use App\Http\Requests\UpdateSecurityCompany;
use App\SecurityCompany;
use App\User;
use Auth;
use Illuminate\Http\Request;

class SecurityCompaniesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();

        $securityCompanies = [];

        if ($user->hasRole('Super Admin') || $user->hasRole('Admin')) {
            $securityCompanies = SecurityCompany::with(['manager', 'sites'])->get()->toArray();
        } else {
            $securityCompanies = SecurityCompany::where('manager_id', $user->id)->with(['manager', 'sites'])->get()->toArray();
        }

        return view('pages.security-companies', ['securityCompanies' => $securityCompanies]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSecurityCompany $request)
    {
        $user = User::where('email', $request->user['email'])->first();

        // Check if the given user is new or not and
        // create the user if new
        if (!$user) {
            $tempUserObj = $request->user;
            $tempUserObj['password'] = \Hash::make('manage');
            $user = User::create($tempUserObj);
        }

        $securityCompany = $user->securityCompanies()->create($request->securityCompany);

        return response()->json([
            'user' => $user,
            'securityCompany' => $securityCompany,
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SecurityCompany  $securityCompanies
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateSecurityCompany $request, $id)
    {
        $client = SecurityCompany::where('id', $id)->update($request->all());
        return response()->json($client, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SecurityCompany  $securityCompanies
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $securityCompany = SecurityCompany::find($id);
        $securityCompany->forceDelete();
        return response()->json($securityCompany, 200);
    }

    /**
     * Searches the table for the given content.
     *
     * NOTE: For some reason, the call to the Scout
     * "get" method sometimes returns an associative
     * array. The iteration is to ensure the returned
     * structure is flat.
     */
    public function search(Request $request)
    {
        $securityCompanies = SecurityCompany::where('name', 'ilike', '%' . $request->query('content') . '%')->get()->toArray();
        return response()->json([
            'result' => $securityCompanies,
        ], 200);
    }
}
