<?php

namespace App\Http\Controllers;

use App\User;
use App\Client;
use App\UserClientLink;
use App\Http\Requests\StoreUserClientLink;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Http\Request;
use RolesAndPermissions;

class UserClientLinksController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the list of clients.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        Log::info("starting to get userClientlinks");
        $user = Auth::user();
        $userClientlinks = [];
        if ($user->hasRole('Super Admin') || $user->hasRole('Admin')) {            
            $userClientlinks = UserClientLink::with(['client', 'manager'])->get()->toArray();
        }
        Log::info("Found userClientlinks  ********************".count($userClientlinks));
        return view('pages.user-client-links', [
            'userClientlinks' => $userClientlinks,
        ]);

    }
     /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreUserClientLink $request)
    {
        Log::info("starting to link user and client");
        $client = Client::find($request->userClientLink['client_id']);
        Log::info("Client Id ".$request->userClientLink['client_id']);
        $user = User::find($request->userClientLink['manager_id']);
        Log::info("User Id ".$request->userClientLink['manager_id']);
        $userClientLink = new UserClientLink();
        $userClientLink->client()->associate($client);
        $userClientLink->manager()->associate($user);
        $userClientLink->save();
        Log::info("Ending to link user and client");
        return response()->json([
            'userClientLink' => $userClientLink,
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UserClientLink  $userClientLink
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUserClientLink $request, $id)
    {
        $userClientLink = UserClientLink::where('id', $id)->update($request->all());
        return response()->json($userClientLink, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UserClientLink  $userClientLink
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $userClientLink = UserClientLink::find($id);
        $userClientLink->forceDelete();
        return response()->json($userClientLink, 200);
    }

    /**
     * Searches the table for the given content.
     *
     * NOTE: For some reason, the call to the Scout
     * "get" method sometimes returns an associative
     * array. The iteration is to ensure the returned
     * structure is flat.
     */
    public function search(Request $request)
    {
        $result = [];
        $userClientLinks = UserClientLink::search($request->query('content'))->get();
        foreach ($userClientLinks as $userClientLink) {
            array_push($result, $userClientLink);
        }

        return response()->json([
            'result' => $result,
        ], 200);
    }

}
