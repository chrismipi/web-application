<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Site extends Model
{
    use SoftDeletes;

    

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'description', 'address', 'latitude', 'longitude', 'created_at', 'updated_at', 'deleted_at','contact_number', 'alternative_contact_number',
    ];   

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * Get the client that owns the site.
     */
    public function securityCompany()
    {
        return $this->belongsTo('App\SecurityCompany');
    }

    /**
     * Get the client that owns the site.
     */
    public function client()
    {
        return $this->belongsTo('App\Client');
    }

    /**
     * Get the shifts for this site.
     */
    public function shifts()
    {
        return $this->hasMany('App\Shift');
    }

    /**
     * Get the devices for the this site.
     */
    public function devices()
    {
        return $this->hasMany('App\Device');
    }

    /**
     * Get the nfcTags for the this site.
     */
    public function nfcTags()
    {
        return $this->hasMany('App\NfcTag');
    }


    /**
     * Get the alerts for the this site.
     */
    public function alerts()
    {
        return $this->hasMany('App\Alert');
    }     
}
