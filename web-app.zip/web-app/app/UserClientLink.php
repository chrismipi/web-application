<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Scout\Searchable;

class UserClientLink extends Model
{
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'created_at', 'updated_at', 'deleted_at',
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

     /**
     * Get the index name for the model.
     *
     * @return string
     */
    public function searchableAs()
    {
        return 'user_client_link_index';
    }


    /**
     * Get the client that owns the site.
     */
    public function manager()
    {
        return $this->belongsTo('App\user');
    }

    /**
     * Get the client that owns the site.
     */
    public function client()
    {
        return $this->belongsTo('App\Client');
    }
}
