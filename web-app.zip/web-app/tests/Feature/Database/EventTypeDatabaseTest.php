<?php

namespace Tests\Feature\Database;

use App\EventType;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Tests for the Event Type model.
 */
class EventTypeDatabaseTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Tests that an event type can be created successfully.
     *
     * @return void
     */
    public function testCreateEventType()
    {
        $name = 'Tag Registration';
        $description = 'The registration of a new tag at a site';
        $created_at = new Carbon();
        $updated_at = new Carbon();

        $eventType = EventType::create([
            'name' => $name,
            'description' => $description,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);

        $this->assertDatabaseHas('event_types', [
            'name' => $name,
            'description' => $description,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);
    }

    /**
     * Tests that all event types can be queried successfully.
     *
     * @return void
     */
    public function testQueryAllevent_types()
    {
        $event_types = factory(EventType::class, 5)->create();

        $event_types->each(function ($event_type, $key) {
            $event_type->save();
        });

        $this->assertTrue(sizeof($event_types) === 5);

        foreach ($event_types as $eventType) {
            $this->assertDatabaseHas('event_types', [
                'name' => $eventType->name,
                'description' => $eventType->description,
                'created_at' => $eventType->created_at,
                'updated_at' => $eventType->updated_at,
            ]);
        }
    }

    /**
     * Tests that a specific event types can be queried successfully.
     *
     * @return void
     */
    public function testQueryOneEventType()
    {
        $eventType = factory(EventType::class)->create();

        $this->assertTrue(sizeof($eventType) === 1);

        $this->assertDatabaseHas('event_types', [
            'name' => $eventType->name,
            'description' => $eventType->description,
            'created_at' => $eventType->created_at,
            'updated_at' => $eventType->updated_at,
        ]);
    }

    /**
     * Tests that an event type can be updated successfully.
     *
     * @return void
     */
    public function testUpdateEventType()
    {
        $eventType = factory(EventType::class)->create();

        $newName = 'New Role';
        $newDescription = 'A New Role For Testing...';
        $newUpdatedAt = new Carbon();

        $eventType->name = $newName;
        $eventType->description = $newDescription;
        $eventType->updated_at = $newUpdatedAt;
        $eventType->save();

        $this->assertDatabaseHas('event_types', [
            'name' => $newName,
            'description' => $newDescription,
            'created_at' => $eventType->created_at,
            'updated_at' => $newUpdatedAt,
        ]);
    }

    /**
     * Tests that an event type can be deleted successfully.
     *
     * Should soft delete the entity.
     *
     * @return void
     */
    public function testDeleteEventType()
    {
        $eventType = factory(EventType::class)->create();
        $eventType->delete();

        $this->assertSoftDeleted('event_types', [
            'name' => $eventType->name,
            'description' => $eventType->description,
            'created_at' => $eventType->created_at,
            'updated_at' => $eventType->updated_at,
            'deleted_at' => $eventType->deleted_at,
        ]);
    }
}
