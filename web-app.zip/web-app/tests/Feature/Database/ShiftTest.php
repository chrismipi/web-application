<?php

namespace Tests\Feature\Database;

use App\Client;
use App\SecurityCompany;
use App\Shift;
use App\Site;
use App\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ShiftTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Tests that a shift can be created successfully.
     *
     * @return void
     */
    public function testCreateShift()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $start_time = '06h00';
        $end_time = '22h00';
        $patrol_count = 10;
        $rest_time = '00h10';
        $trip_duration = '00h10';
        $created_at = new Carbon();
        $updated_at = new Carbon();

        $shift = $site->shifts()->create([
            'start_time' => $start_time,
            'end_time' => $end_time,
            'patrol_count' => $patrol_count,
            'rest_time' => $rest_time,
            'trip_duration' => $trip_duration,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);

        $shift->save();

        $this->assertDatabaseHas('shifts', [
            'start_time' => $start_time,
            'end_time' => $end_time,
            'patrol_count' => $patrol_count,
            'rest_time' => $rest_time,
            'trip_duration' => $trip_duration,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);
    }

    /**
     * Tests that all sites can be queried successfully.
     *
     * @return void
     */
    public function testQueryAllShifts()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $shifts = factory(Shift::class, 5)->make();

        foreach ($shifts as $shift) {
            $site->shifts()->create($shift->toArray());
        }

        $this->assertTrue(sizeof($shifts) === 5);

        foreach ($shifts as $shift) {
            $this->assertDatabaseHas('shifts', [
                'start_time' => $shift->start_time,
                'end_time' => $shift->end_time,
                'patrol_count' => $shift->patrol_count,
                'rest_time' => $shift->rest_time,
                'trip_duration' => $shift->trip_duration,
                'created_at' => $shift->created_at,
                'updated_at' => $shift->updated_at,
            ]);
        }
    }

    /**
     * Tests that a specific site can be queried successfully.
     *
     * @return void
     */
    public function testQueryOneShift()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $shift = $site->shifts()->create(factory(Shift::class)->make()->toArray());

        $this->assertDatabaseHas('shifts', [
            'start_time' => $shift->start_time,
            'end_time' => $shift->end_time,
            'patrol_count' => $shift->patrol_count,
            'rest_time' => $shift->rest_time,
            'trip_duration' => $shift->trip_duration,
            'created_at' => $shift->created_at,
            'updated_at' => $shift->updated_at,
        ]);
    }

    /**
     * Tests that a site can be updated successfully.
     *
     * @return void
     */
    public function testUpdateShift()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $shift = $site->shifts()->create(factory(Shift::class)->make()->toArray());
        $shift->save();

        $newStartTime = '16h00';
        $newEndTime = '22h00';
        $newUpdatedAt = new Carbon();

        $shift->start_time = $newStartTime;
        $shift->end_time = $newEndTime;
        $shift->updated_at = $newUpdatedAt;
        $shift->save();

        $this->assertDatabaseHas('shifts', [
            'start_time' => $newStartTime,
            'end_time' => $newEndTime,
            'patrol_count' => $shift->patrol_count,
            'rest_time' => $shift->rest_time,
            'trip_duration' => $shift->trip_duration,
            'created_at' => $shift->created_at,
            'updated_at' => $newUpdatedAt,
        ]);
    }

    /**
     * Tests that a site can be deleted successfully.
     *
     * Should soft delete the entity.
     *
     * @return void
     */
    public function testDeleteShift()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $shift = $site->shifts()->create(factory(Shift::class)->make()->toArray());
        $shift->save();

        $shift->delete();

        $this->assertSoftDeleted('shifts', [
            'start_time' => $shift->start_time,
            'end_time' => $shift->end_time,
            'patrol_count' => $shift->patrol_count,
            'rest_time' => $shift->rest_time,
            'trip_duration' => $shift->trip_duration,
            'created_at' => $shift->created_at,
            'updated_at' => $shift->updated_at,
        ]);
    }
}
