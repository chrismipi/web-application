<?php

namespace Tests\Feature\Database;

use App\Client;
use App\SecurityCompany;
use App\Site;
use App\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SiteTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Tests that site can be created successfully.
     *
     * @return void
     */
    public function testCreateSite()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $name = 'KFC Fourways';
        $description = 'KFC Fourways Branch';
        $address = '4 Pieter Wenning Road, Fourways, Johannesburg, South Africa';
        $latitude = '-26.003283';
        $longitude = '28.011520';
        $created_at = new Carbon();
        $updated_at = new Carbon();

        $site = Site::make([
            'name' => $name,
            'description' => $description,
            'address' => $address,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $this->assertDatabaseHas('sites', [
            'name' => $name,
            'description' => $description,
            'address' => $address,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);
    }

    /**
     * Tests that all sites can be queried successfully.
     *
     * @return void
     */
    public function testQueryAllSites()
    {
        $sites = factory(Site::class, 5)->make();

        $sites->each(function ($site, $key) {
            $user = factory(User::class)->create();
            $client = $user->clients()->save(factory(Client::class)->make());
            $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

            $site->client()->associate($client);
            $site->securityCompany()->associate($securityCompany);
            $site->save();
        });

        $this->assertTrue(sizeof($sites) === 5);

        foreach ($sites as $site) {
            $this->assertDatabaseHas('sites', [
                'name' => $site->name,
                'description' => $site->description,
                'address' => $site->address,
                'latitude' => $site->latitude,
                'longitude' => $site->longitude,
                'created_at' => $site->created_at,
                'updated_at' => $site->updated_at,
            ]);
        }
    }

    /**
     * Tests that a specific site can be queried successfully.
     *
     * @return void
     */
    public function testQueryOneSite()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $this->assertDatabaseHas('sites', [
            'name' => $site->name,
            'description' => $site->description,
            'address' => $site->address,
            'latitude' => $site->latitude,
            'longitude' => $site->longitude,
            'created_at' => $site->created_at,
            'updated_at' => $site->updated_at,
        ]);
    }

    /**
     * Tests that a site can be updated successfully.
     *
     * @return void
     */
    public function testUpdateSite()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $newName = 'Chicken Licken Fourways';
        $newDescription = 'Chicken Licken Fourways Branch';
        $newUpdatedAt = new Carbon();

        $site->name = $newName;
        $site->description = $newDescription;
        $site->updated_at = $newUpdatedAt;
        $site->save();

        $this->assertDatabaseHas('sites', [
            'name' => $newName,
            'description' => $newDescription,
            'address' => $site->address,
            'latitude' => $site->latitude,
            'longitude' => $site->longitude,
            'created_at' => $site->created_at,
            'updated_at' => $newUpdatedAt,
        ]);
    }

    /**
     * Tests that a site can be deleted successfully.
     *
     * Should soft delete the entity.
     *
     * @return void
     */
    public function testDeleteSite()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $site->delete();

        $this->assertSoftDeleted('sites', [
            'name' => $site->name,
            'description' => $site->description,
            'address' => $site->address,
            'latitude' => $site->latitude,
            'longitude' => $site->longitude,
            'created_at' => $site->created_at,
            'updated_at' => $site->updated_at,
        ]);
    }
}
