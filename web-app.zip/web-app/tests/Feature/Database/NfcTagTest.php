<?php

namespace Tests\Feature\Database;

use App\Client;
use App\NfcTag;
use App\SecurityCompany;
use App\Site;
use App\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class NfcTagTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Tests that a nfcTag can be created successfully.
     *
     * @return void
     */
    public function testCreateNfcTags()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $serial_no = 'XYZ1234567891098765432ABC';
        $latitude = '-26.003283';
        $longitude = '28.011520';
        $sequence_no = 1;
        $created_at = new Carbon();
        $updated_at = new Carbon();

        $nfcTag = $site->nfcTags()->create([
            'serial_no' => $serial_no,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'sequence_no' => $sequence_no,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);

        $this->assertDatabaseHas('nfc_tags', [
            'serial_no' => $serial_no,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'sequence_no' => $sequence_no,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);
    }

    /**
     * Tests that all sites can be queried successfully.
     *
     * @return void
     */
    public function testQueryAllNfcTags()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $nfcTags = $site->nfcTags()->createMany(factory(NfcTag::class, 5)->make()->toArray());

        $nfcTags->each(function ($nfcTag, $key) {
            $nfcTag->save();
        });

        $this->assertTrue(sizeof($nfcTags) === 5);

        foreach ($nfcTags as $nfcTag) {
            $this->assertDatabaseHas('nfc_tags', [
                'serial_no' => $nfcTag->serial_no,
                'latitude' => $nfcTag->latitude,
                'longitude' => $nfcTag->longitude,
                'sequence_no' => $nfcTag->sequence_no,
                'created_at' => $nfcTag->created_at,
                'updated_at' => $nfcTag->updated_at,
            ]);
        }
    }

    /**
     * Tests that a specific site can be queried successfully.
     *
     * @return void
     */
    public function testQueryOneNfcTags()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $nfcTag = $site->nfcTags()->create(factory(NfcTag::class)->make()->toArray());

        $this->assertDatabaseHas('nfc_tags', [
            'serial_no' => $nfcTag->serial_no,
            'latitude' => $nfcTag->latitude,
            'longitude' => $nfcTag->longitude,
            'sequence_no' => $nfcTag->sequence_no,
            'created_at' => $nfcTag->created_at,
            'updated_at' => $nfcTag->updated_at,
        ]);
    }

    /**
     * Tests that a site can be updated successfully.
     *
     * @return void
     */
    public function testUpdateNfcTags()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $nfcTag = $site->nfcTags()->create(factory(NfcTag::class)->make()->toArray());
        $nfcTag->save();

        $newSerialNo = 'QWE0981237893453POIU';
        $newLatitude = '12.128973';
        $newLongitutde = '-12.948736';
        $newSequenceNo = -1;
        $newUpdatedAt = new Carbon();

        $nfcTag->serial_no = $newSerialNo;
        $nfcTag->latitude = $newLatitude;
        $nfcTag->longitude = $newLongitutde;
        $nfcTag->sequence_no = $newSequenceNo;
        $nfcTag->updated_at = $newUpdatedAt;
        $nfcTag->save();

        $this->assertDatabaseHas('nfc_tags', [
            'serial_no' => $newSerialNo,
            'latitude' => $newLatitude,
            'longitude' => $newLongitutde,
            'sequence_no' => $newSequenceNo,
            'created_at' => $nfcTag->created_at,
            'updated_at' => $newUpdatedAt,
        ]);
    }

    /**
     * Tests that a site can be deleted successfully.
     *
     * Should soft delete the entity.
     *
     * @return void
     */
    public function testDeleteNfcTags()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $nfcTag = $site->nfcTags()->create(factory(NfcTag::class)->make()->toArray());
        $nfcTag->save();

        $nfcTag->delete();

        $this->assertSoftDeleted('nfc_tags', [
            'serial_no' => $nfcTag->serial_no,
            'latitude' => $nfcTag->latitude,
            'longitude' => $nfcTag->longitude,
            'sequence_no' => $nfcTag->sequence_no,
            'created_at' => $nfcTag->created_at,
            'updated_at' => $nfcTag->updated_at,
        ]);
    }
}
