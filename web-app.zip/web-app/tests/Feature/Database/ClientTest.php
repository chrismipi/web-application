<?php

namespace Tests\Feature\Database;

use App\Client;
use App\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ClientTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Tests that an event type can be created successfully.
     *
     * @return void
     */
    public function testCreateClient()
    {
        $user = factory(User::class)->create();

        $name = 'ADT Security';
        $address = '4 Peiter Wenning Road, Fourways, South Africa';
        $created_at = new Carbon();
        $updated_at = new Carbon();

        $client = $user->clients()->create([
            'name' => $name,
            'address' => $address,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);

        $this->assertDatabaseHas('clients', [
            'name' => $name,
            'address' => $address,
            'created_at' => $client->created_at,
            'updated_at' => $updated_at,
        ]);
    }

    /**
     * Tests that all event types can be queried successfully.
     *
     * @return void
     */
    public function testQueryAllClients()
    {
        $user = factory(User::class)->create();

        $clients = $user->clients()->createMany(factory(Client::class, 5)->make()->toArray());

        $clients->each(function ($client, $key) {
            $client->save();
        });

        $this->assertTrue(sizeof($clients) === 5);

        foreach ($clients as $client) {
            $this->assertDatabaseHas('clients', [
                'name' => $client->name,
                'address' => $client->address,
                'created_at' => $client->created_at,
                'updated_at' => $client->updated_at,
                'deleted_at' => $client->deleted_at,
            ]);
        }
    }

    /**
     * Tests that a specific event types can be queried successfully.
     *
     * @return void
     */
    public function testQueryOneClient()
    {
        $user = factory(User::class)->create();

        $client = $user->clients()->create(factory(Client::class)->make()->toArray());
        $client->save();

        $this->assertTrue(sizeof($client) === 1);

        $this->assertDatabaseHas('clients', [
            'name' => $client->name,
            'address' => $client->address,
            'created_at' => $client->created_at,
            'updated_at' => $client->updated_at,
            'deleted_at' => $client->deleted_at,
        ]);
    }

    /**
     * Tests that an event type can be updated successfully.
     *
     * @return void
     */
    public function testUpdateClient()
    {
        $user = factory(User::class)->create();

        $client = $user->clients()->create(factory(Client::class)->make()->toArray());
        $client->save();

        $newName = 'New Role';
        $newAddress = 'A New Role For Testing...';
        $newUpdatedAt = new Carbon();

        $client->name = $newName;
        $client->address = $newAddress;
        $client->updated_at = $newUpdatedAt;
        $client->save();

        $this->assertDatabaseHas('clients', [
            'name' => $newName,
            'address' => $newAddress,
            'created_at' => $client->created_at,
            'updated_at' => $newUpdatedAt,
            'deleted_at' => $client->deleted_at,
        ]);
    }

    /**
     * Tests that an event type can be deleted successfully.
     *
     * Should soft delete the entity.
     *
     * @return void
     */
    public function testDeleteClient()
    {
        $user = factory(User::class)->create();

        $client = $user->clients()->create(factory(Client::class)->make()->toArray());
        $client->save();

        $client->delete();

        $this->assertSoftDeleted('clients', [
            'name' => $client->name,
            'address' => $client->address,
            'created_at' => $client->created_at,
            'updated_at' => $client->updated_at,
            'deleted_at' => $client->deleted_at,
        ]);
    }
}
