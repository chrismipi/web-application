<?php

namespace Tests\Feature\Database;

use App\Client;
use App\Device;
use App\SecurityCompany;
use App\Site;
use App\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class DeviceTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Tests that a device can be created successfully.
     *
     * @return void
     */
    public function testCreateDevice()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $serial_no = 'XYZ1234567891098765432ABC';
        $device_token = 'XYZ1234567891098765432ABC';
        $contact_number = '01112345667';
        $created_at = new Carbon();
        $updated_at = new Carbon();

        $device = $site->devices()->create([
            'serial_no' => $serial_no,
            'device_token' => $device_token,
            'contact_number' => $contact_number,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);

        $this->assertDatabaseHas('devices', [
            'serial_no' => $serial_no,
            'device_token' => $device_token,
            'contact_number' => $contact_number,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);
    }

    /**
     * Tests that all sites can be queried successfully.
     *
     * @return void
     */
    public function testQueryAllDevice()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $devices = $site->devices()->createMany(factory(Device::class, 5)->make()->toArray());

        $devices->each(function ($device, $key) {
            $device->save();
        });

        $this->assertTrue(sizeof($devices) === 5);

        foreach ($devices as $device) {
            $this->assertDatabaseHas('devices', [
                'serial_no' => $device->serial_no,
                'device_token' => $device->device_token,
                'contact_number' => $device->contact_number,
                'created_at' => $device->created_at,
                'updated_at' => $device->updated_at,
            ]);
        }
    }

    /**
     * Tests that a specific site can be queried successfully.
     *
     * @return void
     */
    public function testQueryOneDevice()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $device = $site->devices()->create(factory(Device::class)->make()->toArray());

        $this->assertDatabaseHas('devices', [
            'serial_no' => $device->serial_no,
            'device_token' => $device->device_token,
            'contact_number' => $device->contact_number,
            'created_at' => $device->created_at,
            'updated_at' => $device->updated_at,
        ]);
    }

    /**
     * Tests that a site can be updated successfully.
     *
     * @return void
     */
    public function testUpdateDevice()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $device = $site->devices()->create(factory(Device::class)->make()->toArray());
        $device->save();

        $newSerialNo = 'QWE0981237893453POIU';
        $newDeviceToken = 'QWE0981237893453POIU';
        $newContactNumber = '0193789234';
        $newUpdatedAt = new Carbon();

        $device->serial_no = $newSerialNo;
        $device->device_token = $newDeviceToken;
        $device->contact_number = $newContactNumber;
        $device->updated_at = $newUpdatedAt;
        $device->save();

        $this->assertDatabaseHas('devices', [
            'serial_no' => $newSerialNo,
            'device_token' => $newDeviceToken,
            'contact_number' => $newContactNumber,
            'created_at' => $device->created_at,
            'updated_at' => $newUpdatedAt,
        ]);
    }

    /**
     * Tests that a site can be deleted successfully.
     *
     * Should soft delete the entity.
     *
     * @return void
     */
    public function testDeleteDevice()
    {
        $user = factory(User::class)->create();
        $client = $user->clients()->save(factory(Client::class)->make());
        $securityCompany = $user->securityCompanies()->save(factory(SecurityCompany::class)->make());

        $site = factory(Site::class)->make();
        $site->client()->associate($client);
        $site->securityCompany()->associate($securityCompany);
        $site->save();

        $device = $site->devices()->create(factory(Device::class)->make()->toArray());
        $device->save();

        $device->delete();

        $this->assertSoftDeleted('devices', [
            'serial_no' => $device->serial_no,
            'device_token' => $device->device_token,
            'contact_number' => $device->contact_number,
            'created_at' => $device->created_at,
            'updated_at' => $device->updated_at,
        ]);
    }
}
