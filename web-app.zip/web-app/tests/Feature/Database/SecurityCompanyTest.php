<?php

namespace Tests\Feature\Database;

use App\SecurityCompany;
use App\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SecurityCompanyTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Tests that an event type can be created successfully.
     *
     * @return void
     */
    public function testCreateSecurityCompany()
    {
        $user = factory(User::class)->create();

        $name = 'ADT Security';
        $created_at = new Carbon();
        $updated_at = new Carbon();

        $securityCompany = $user->securityCompanies()->create([
            'name' => $name,
            'created_at' => $created_at,
            'updated_at' => $updated_at,
        ]);

        $this->assertDatabaseHas('security_companies', [
            'name' => $name,
            'created_at' => $securityCompany->created_at,
            'updated_at' => $updated_at,
        ]);
    }

    /**
     * Tests that all event types can be queried successfully.
     *
     * @return void
     */
    public function testQueryAllSecurityCompanies()
    {
        $user = factory(User::class)->create();

        $securityCompanies = $user->securityCompanies()->createMany(factory(SecurityCompany::class, 5)->make()->toArray());

        $securityCompanies->each(function ($securityCompany, $key) {
            $securityCompany->save();
        });

        $this->assertTrue(sizeof($securityCompanies) === 5);

        foreach ($securityCompanies as $securityCompany) {
            $this->assertDatabaseHas('security_companies', [
                'name' => $securityCompany->name,
                'created_at' => $securityCompany->created_at,
                'updated_at' => $securityCompany->updated_at,
                'deleted_at' => $securityCompany->deleted_at,
            ]);
        }
    }

    /**
     * Tests that a specific event types can be queried successfully.
     *
     * @return void
     */
    public function testQueryOneSecurityCompany()
    {
        $user = factory(User::class)->create();

        $securityCompany = $user->securityCompanies()->create(factory(SecurityCompany::class)->make()->toArray());
        $securityCompany->save();

        $this->assertTrue(sizeof($securityCompany) === 1);

        $this->assertDatabaseHas('security_companies', [
            'name' => $securityCompany->name,
            'created_at' => $securityCompany->created_at,
            'updated_at' => $securityCompany->updated_at,
            'deleted_at' => $securityCompany->deleted_at,
        ]);
    }

    /**
     * Tests that an event type can be updated successfully.
     *
     * @return void
     */
    public function testUpdateSecurityCompany()
    {
        $user = factory(User::class)->create();

        $securityCompany = $user->securityCompanies()->create(factory(SecurityCompany::class)->make()->toArray());
        $securityCompany->save();

        $newName = 'New Role';
        $newAddress = 'A New Role For Testing...';
        $newUpdatedAt = new Carbon();

        $securityCompany->name = $newName;
        $securityCompany->updated_at = $newUpdatedAt;
        $securityCompany->save();

        $this->assertDatabaseHas('security_companies', [
            'name' => $newName,
            'created_at' => $securityCompany->created_at,
            'updated_at' => $newUpdatedAt,
            'deleted_at' => $securityCompany->deleted_at,
        ]);
    }

    /**
     * Tests that an event type can be deleted successfully.
     *
     * Should soft delete the entity.
     *
     * @return void
     */
    public function testDeleteSecurityCompany()
    {
        $user = factory(User::class)->create();

        $securityCompany = $user->securityCompanies()->create(factory(SecurityCompany::class)->make()->toArray());
        $securityCompany->save();

        $securityCompany->delete();

        $this->assertSoftDeleted('security_companies', [
            'name' => $securityCompany->name,
            'created_at' => $securityCompany->created_at,
            'updated_at' => $securityCompany->updated_at,
            'deleted_at' => $securityCompany->deleted_at,
        ]);
    }
}
