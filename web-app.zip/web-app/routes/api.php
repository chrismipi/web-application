<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
 */

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/user/verify/{email}', 'UsersController@verifyUser')->name('verify-user-api');

Route::put('/user', 'UsersController@store')->name('create-user-api');
Route::post('/user/{id}', 'UsersController@update')->name('update-user-api');
Route::delete('/user/{id}', 'UsersController@destroy')->name('delete-user-api');
Route::get('/user/search', 'UsersController@search')->name('search-user-api');

Route::put('/security-company', 'SecurityCompaniesController@store')->name('create-security-company-api');
Route::post('/security-company/{id}', 'SecurityCompaniesController@update')->name('update-security-company-api');
Route::delete('/security-company/{id}', 'SecurityCompaniesController@destroy')->name('delete-security-company-api');
Route::get('/security-company/search', 'SecurityCompaniesController@search')->name('search-security-company-api');

Route::put('/client', 'ClientsController@store')->name('create-client-api');
Route::post('/client/{id}', 'ClientsController@update')->name('update-client-api');
Route::delete('/client/{id}', 'ClientsController@destroy')->name('delete-client-api');
Route::get('/client/search', 'ClientsController@search')->name('search-client-api');

Route::put('/site', 'SitesController@store')->name('create-site-api');
Route::post('/site/{id}', 'SitesController@update')->name('update-site-api');
Route::delete('/site/{id}', 'SitesController@destroy')->name('delete-site-api');

Route::delete('/tag/{id}', 'SitesController@deletetag')->name('delete-tag-api');

Route::get('/roles/{id}', 'RolesAndPermissionsController@getRoles')->name('get-roles-api');

Route::post('/alert/publish', 'EventFeedController@handleAlertEvent')->name('handle-alert-event-api');
Route::get('/alert/ack/{alertId}', 'EventFeedController@acknowledgeEvent')->name('ack-alert-api');
Route::get('/alerts/{siteId}', 'EventFeedController@siteEvents')->name('view-site-event-feed');    
Route::get('/alerts/count/{siteId}', 'EventFeedController@countSiteEvents')->name('count-site-event'); 

Route::post('/auth', function (Request $request) {
    if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
        return response()->json([
            "message" => "Authentication Success.",
        ]);
    } else {
        return response()->json([
            "message" => "Authentication Failed. Invalid Credentials",
        ], 401);
    }
});
Route::put('/user-client-link', 'UserClientLinksController@store')->name('create-user-client-link-api');
Route::post('/user-client-link/{id}', 'UserClientLinksController@update')->name('update-user-client-link-api');
Route::delete('/user-client-link/{id}', 'UserClientLinksController@destroy')->name('delete-user-client-link-api');

