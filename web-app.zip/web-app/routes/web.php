<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Auth::routes();

/**
 * Only Authenticated users may access these routes
 *
 */
Route::middleware('auth')->group(function () {

    // Redirect all calls to / to /dashboard
    Route::get('/', function () {
        return redirect()->route('dashboard');
    });

    // Redirect all calls to /home to /dashboard
    Route::get('/home', function () {
        return redirect()->route('dashboard');
    });

    Route::get('/dashboard', 'DashboardController@index')->name('dashboard');

    Route::get('/security-companies', 'SecurityCompaniesController@index')->name('security-companies');
  
    Route::get('/clients', 'ClientsController@index')->name('clients');

    Route::get('/user-client-links', 'UserClientLinksController@index')->name('user-client-links');

    Route::get('/sites', 'SitesController@index')->name('sites');

    Route::get('/users', 'UsersController@index')->name('users');

    Route::get('/active-patrols', 'PatrolsController@activePatrols')->name('active-patrols');
    Route::get('/upcomming-patrols', 'PatrolsController@upcommingPatrols')->name('upcomming-patrols');
    Route::get('/patrol-history', 'PatrolsController@patrolHistory')->name('patrol-history');

    Route::get('/patrol-configuration', 'PatrolsController@configure')->name('patrol-configuration');

    Route::get('/event-feed', 'EventFeedController@index')->name('view-event');
    Route::get('/event-feed/{eventId}', 'EventFeedController@show')->name('view-event-feed');    
    Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');
});

/**
 * Only Guest users may access these routes
 *
 */
Route::middleware('guest')->group(function () {
    Route::get('/', function () {
        return redirect('login');
    });
});
