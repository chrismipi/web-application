<?php

use App\Site;

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
 */

 Broadcast::channel('App.User.{id}', function ($user, $id) {
     return (int) $user->id === (int) $id;
 });

/**
 * THe channel authentication for site related alerts.
 */
Broadcast::channel('alert.site.{id}', function ($user, $id) {

  //  return true;

     $superAdminUser = Role::findByName('Super Admin');
     $adminUser = Role::findByName('Admin');

    // The user must either be a super admin or an admin user
     if ($user->hasRole([$superAdminUser, $adminUser])) {
         return true;
     }
    // Else the user must be linked to the site
     else {
         $site = Site::find($id);
         $linkedUser = $site->securityCompany()->manager();

         if ($linkedUser->id !== $user->id) {
             $linkedUser = $site->client()->manager();
        }

         return $linkedUser->id === $user->id;
     }
});
