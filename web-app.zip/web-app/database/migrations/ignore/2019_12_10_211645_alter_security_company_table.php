<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterSecurityCompanyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('security_companies', function (Blueprint $table) {
            $table->string('contact_number')->nullable();
            $table->string('alternative_contact_number')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('security_companies', function (Blueprint $table) {
            $table->dropColumn('contact_number');
            $table->dropColumn('alternative_contact_number');
        });
    }
}
