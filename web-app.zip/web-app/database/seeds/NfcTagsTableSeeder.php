<?php

use App\Site;
use Illuminate\Database\Seeder;

class NfcTagsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Site 1 Device
        $siteOne = Site::where('name', 'KFC Fourways')->first();
        $siteOne->nfcTags()->createMany([
            [
                'serial_no' => 'KFC-SER-001',
                'longitude' => '10.123654',
                'latitude' => '-10.123654',
                'sequence_no' => -1,
            ],
            [
                'serial_no' => 'KFC-SER-001',
                'longitude' => '10.123655',
                'latitude' => '-10.123655',
                'sequence_no' => 0,
            ],
        ]);

        // Site 2 Devuce
        $siteTwo = Site::where('name', 'Chicken Licken Fourways')->first();
        $siteTwo->nfcTags()->createMany([
            [
                'serial_no' => 'CLF-SER-001',
                'longitude' => '11.123654',
                'latitude' => '-11.123655',
                'sequence_no' => -1,
            ],
            [
                'serial_no' => 'CLF-SER-001',
                'longitude' => '12.123655',
                'latitude' => '-12.123656',
                'sequence_no' => 0,
            ],
        ]);

        // Site 3 Device
        $siteTwo = Site::where('name', 'Chicken Licken Sandton')->first();
        $siteTwo->nfcTags()->createMany([
            [
                'serial_no' => 'CLS-SER-001',
                'longitude' => '13.123654',
                'latitude' => '-13.123655',
                'sequence_no' => -1,
            ],
            [
                'serial_no' => 'CLS-SER-001',
                'longitude' => '14.123655',
                'latitude' => '-14.123656',
                'sequence_no' => 0,
            ],
        ]);

        // Site 4 Device
        $siteTwo = Site::where('name', 'Inifinity Serviced Office Fourways')->first();
        $siteTwo->nfcTags()->createMany([
            [
                'serial_no' => 'KFC-SER-001',
                'longitude' => '15.123654',
                'latitude' => '-15.123655',
                'sequence_no' => -1,
            ],
            [
                'serial_no' => 'KFC-SER-001',
                'longitude' => '16.123655',
                'latitude' => '-16.123656',
                'sequence_no' => 0,
            ],
        ]);

        // Site 5 Device
        $siteTwo = Site::where('name', 'Inifinity Serviced Office Centurion')->first();
        $siteTwo->nfcTags()->createMany([
            [
                'serial_no' => 'KFC-SER-001',
                'longitude' => '17.123654',
                'latitude' => '-17.123655',
                'sequence_no' => -1,
            ],
            [
                'serial_no' => 'KFC-SER-001',
                'longitude' => '18.123655',
                'latitude' => '-18.123656',
                'sequence_no' => 0,
            ],
        ]);

        // Site 6 Device
        $siteTwo = Site::where('name', 'Inifinity Serviced Office Boksburg')->first();
        $siteTwo->nfcTags()->createMany([
            [
                'serial_no' => 'KFC-SER-001',
                'longitude' => '10.123654',
                'latitude' => '-10.123654',
                'sequence_no' => -1,
            ],
            [
                'serial_no' => 'KFC-SER-001',
                'longitude' => '10.123655',
                'latitude' => '-10.123655',
                'sequence_no' => 0,
            ],
        ]);
    }
}
