<?php

use App\Site;
use Illuminate\Database\Seeder;

class ShiftsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Site 1 Shift
        $siteOne = Site::where('name', 'KFC Fourways')->first();
        $siteOne->shifts()->create([
            'start_time' => '18h00',
            'end_time' => '06h00',
            'patrol_count' => 10,
            'rest_time' => '00h30',
            'trip_duration' => '00h10',
        ]);

        // Site 2 Shift
        $siteTwo = Site::where('name', 'Chicken Licken Fourways')->first();
        $siteTwo->shifts()->create([
            'start_time' => '06h00',
            'end_time' => '18h00',
            'patrol_count' => 10,
            'rest_time' => '00h15',
            'trip_duration' => '00h10',
        ]);

        // Site 2 Shift
        $siteTwo->shifts()->create([
            'start_time' => '18h00',
            'end_time' => '06h00',
            'patrol_count' => 10,
            'rest_time' => '00h30',
            'trip_duration' => '00h10',
        ]);

        // Site 3 Shift
        $siteThree = Site::where('name', 'Chicken Licken Sandton')->first();
        $siteThree->shifts()->create([
            'start_time' => '06h00',
            'end_time' => '18h00',
            'patrol_count' => 10,
            'rest_time' => '00h35',
            'trip_duration' => '00h10',
        ]);

        // Site 3 Shift
        $siteThree->shifts()->create([
            'start_time' => '18h00',
            'end_time' => '21h00',
            'patrol_count' => 10,
            'rest_time' => '00h20',
            'trip_duration' => '00h10',
        ]);

        // Site 3 Shift
        $siteThree->shifts()->create([
            'start_time' => '21h00',
            'end_time' => '00h00',
            'patrol_count' => 10,
            'rest_time' => '00h10',
            'trip_duration' => '00h10',
        ]);

        // Site 3 Shift
        $siteThree->shifts()->create([
            'start_time' => '00h00',
            'end_time' => '06h00',
            'patrol_count' => 10,
            'rest_time' => '00h15',
            'trip_duration' => '00h10',
        ]);

        // Site 4 Shift
        $siteFour = Site::where('name', 'Inifinity Serviced Office Fourways')->first();
        $siteFour->shifts()->create([
            'start_time' => '00h00',
            'end_time' => '00h00',
            'patrol_count' => 10,
            'rest_time' => '00h25',
            'trip_duration' => '00h10',
        ]);

        // Site 5 Shift
        $siteFive = Site::where('name', 'Inifinity Serviced Office Centurion')->first();
        $siteFive->shifts()->create([
            'start_time' => '18h00',
            'end_time' => '06h00',
            'patrol_count' => 10,
            'rest_time' => '00h30',
            'trip_duration' => '00h10',
        ]);

        // Site 6 Shift
        $siteSix = Site::where('name', 'Inifinity Serviced Office Boksburg')->first();
        $siteSix->shifts()->create([
            'start_time' => '18h00',
            'end_time' => '06h00',
            'patrol_count' => 10,
            'rest_time' => '01h00',
            'trip_duration' => '00h10',
        ]);
    }
}
