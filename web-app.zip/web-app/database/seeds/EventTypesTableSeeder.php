<?php

use Illuminate\Database\Seeder;

class EventTypesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('event_types')->insert([
            'name' => 'Remote Device Registration',
            'description' => 'Remote Device Registration',
        ]);

        DB::table('event_types')->insert([
            'name' => 'Remote NFC Tag Registration',
            'description' => 'Remote NFC Tag Registration',
        ]);
    }
}
