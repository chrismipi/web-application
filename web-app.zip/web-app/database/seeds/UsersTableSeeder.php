<?php

use App\User;
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // James User
        // App\Flight::create(['name' => 'Flight 10']);
        $jamesUser = User::create([
            'first_name' => 'James',
            'last_name' => 'Le Roux',
            'email' => 'james@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $jamesUser->assignRole(RolesAndPermissions::SuperAdminUser);

        // Admin User 1
        $adminUserOne = User::create([
            'first_name' => 'Admin',
            'last_name' => 'One',
            'email' => 'adminone@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $adminUserOne->assignRole(RolesAndPermissions::AdminUser);

        // Operator User 1
        $operatorUserOne = User::create([
            'first_name' => 'Operator',
            'last_name' => 'One',
            'email' => 'operatorone@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $operatorUserOne->assignRole(RolesAndPermissions::OperatorUser);

        // Operator User 2
        $operatorUserTwo = User::create([
            'first_name' => 'Operator',
            'last_name' => 'Two',
            'email' => 'operatortwo@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $operatorUserTwo->assignRole(RolesAndPermissions::OperatorUser);

        // Operator User 3
        $operatorUserThree = User::create([
            'first_name' => 'Operator',
            'last_name' => 'Three',
            'email' => 'operatorthree@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $operatorUserThree->assignRole(RolesAndPermissions::OperatorUser);

        // Security Company User 1
        $securityCompanyUserOne = User::create([
            'first_name' => 'Security Comp',
            'last_name' => 'One',
            'email' => 'securitycompone@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $securityCompanyUserOne->assignRole(RolesAndPermissions::SecurityCompanyUser);

        // Security Company User 2
        $securityCompanyUserTwo = User::create([
            'first_name' => 'Security Comp',
            'last_name' => 'Two',
            'email' => 'securitycomptwo@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $securityCompanyUserTwo->assignRole(RolesAndPermissions::SecurityCompanyUser);

        // Security Company User 3
        $securityCompanyUserThree = User::create([
            'first_name' => 'Security Comp',
            'last_name' => 'Three',
            'email' => 'securitycompthree@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $securityCompanyUserThree->assignRole(RolesAndPermissions::SecurityCompanyUser);

        // Client User 1
        $clientUserOne = User::create([
            'first_name' => 'Client',
            'last_name' => 'One',
            'email' => 'clientone@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $clientUserOne->assignRole(RolesAndPermissions::ClientUser);

        // Client User 2
        $clientUserTwo = User::create([
            'first_name' => 'Client',
            'last_name' => 'Two',
            'email' => 'clienttwo@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $clientUserTwo->assignRole(RolesAndPermissions::ClientUser);

        // Client User 3
        $clientUserThree = User::create([
            'first_name' => 'Client',
            'last_name' => 'Three',
            'email' => 'clientthree@mail.com',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
            'password' => bcrypt('manage'),
        ]);
        $clientUserThree->assignRole(RolesAndPermissions::ClientUser);

        // Device User 1
        $deviceUserOne = User::create([
            'first_name' => 'Device',
            'last_name' => 'One',
            'email' => 'deviceone@dycom.com',
            'contact_number' => str_random(10),
            'alternative_contact_number' =>  str_random(10),
            'password' => bcrypt('manage'),
        ]);
        $deviceUserOne->assignRole(RolesAndPermissions::DeviceUser);

        // Device User 2
        $deviceUserTwo = User::create([
            'first_name' => 'Device',
            'last_name' => 'Two',
            'email' => 'devicetwo@dycom.com',
            'contact_number' => str_random(10),
            'alternative_contact_number' =>  str_random(10),
            'password' => bcrypt('manage'),
        ]);
        $deviceUserTwo->assignRole(RolesAndPermissions::DeviceUser);

        // Device User 3
        $deviceUserThree = User::create([
            'first_name' => 'Device',
            'last_name' => 'Three',
            'email' => 'devicethree@dycom.com',
            'contact_number' => str_random(10),
            'alternative_contact_number' =>  str_random(10),
            'password' => bcrypt('manage'),
        ]);
        $deviceUserThree->assignRole(RolesAndPermissions::DeviceUser);

        // Device User 4
        $deviceUserFour = User::create([
            'first_name' => 'Device',
            'last_name' => 'Four',
            'email' => 'devicefour@dycom.com',
            'contact_number' => str_random(10),
            'alternative_contact_number' =>  str_random(10),
            'password' => bcrypt('manage'),
        ]);
        $deviceUserFour->assignRole(RolesAndPermissions::DeviceUser);

        // Device User 5
        $deviceUserFive = User::create([
            'first_name' => 'Device',
            'last_name' => 'Five',
            'email' => 'devicefive@dycom.com',
            'contact_number' => str_random(10),
            'alternative_contact_number' =>  str_random(10),
            'password' => bcrypt('manage'),
        ]);
        $deviceUserFive->assignRole(RolesAndPermissions::DeviceUser);

        // Device User 6
        $deviceUserSix = User::create([
            'first_name' => 'Device',
            'last_name' => 'Six',
            'email' => 'devicesix@dycom.com',
            'contact_number' => str_random(10),
            'alternative_contact_number' =>  str_random(10),
            'password' => bcrypt('manage'),
        ]);
        $deviceUserSix->assignRole(RolesAndPermissions::DeviceUser);
    }
}
