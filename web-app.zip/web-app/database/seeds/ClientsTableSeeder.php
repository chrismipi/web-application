<?php

use App\User;
use Illuminate\Database\Seeder;

class ClientsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Client 1
        $userOne = User::where('first_name', 'Client')->where('last_name', 'One')->first();
        $userOne->clients()->create([
            'name' => 'Infinity Business Park',
            'address' => '4 Pieter Wenning Road, Fourways, South Africa',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);

        // Client User 2
        $userTwo = User::where('first_name', 'Client')->where('last_name', 'Two')->first();
        $userTwo->clients()->create([
            'name' => 'Fourways Mall',
            'address' => '4 Pieter Wenning Road, Fourways, South Africa',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);

        // Client User 3
        $userThree = User::where('first_name', 'Client')->where('last_name', 'Three')->first();
        $userThree->clients()->create([
            'name' => 'Deinfern Square',
            'address' => '4 Pieter Wenning Road, Fourways, South Africa',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);
    }
}
