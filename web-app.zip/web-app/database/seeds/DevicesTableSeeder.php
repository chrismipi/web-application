<?php

use App\Site;
use Illuminate\Database\Seeder;

class DevicesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Site 1 Device
        $siteOne = Site::where('name', 'KFC Fourways')->first();
        $siteOne->devices()->create([
            'serial_no' => 'KFC-SER-001',
            'device_token' => 'da12i0sm8Oc:APA91bFJ9hdhXfqLm-OZMedLZqPdwFXS-NhNbp9fG41V6SX_jxwKkGxyWNH8FizsJ2NngJs--iPJmmLQe7CSsOK1UsLdidSy3pW3RuV8TNnpMlwQvvjqtu5hknpsaaSugNGO5qondLvF',
            'contact_number' => '011 123 45678','alternative_contact_number' => '011 123 45679',
        ]);

        // Site 2 Devuce
        $siteTwo = Site::where('name', 'Chicken Licken Fourways')->first();
        $siteTwo->devices()->create([
            'serial_no' => 'CLF-SER-001',
            'device_token' => 'da12i0sm8Oc:APA91bFJ9hdhXfqLm-OZMedLZqPdwFXS-NhNbp9fG41V6SX_jxwKkGxyWNH8FizsJ2NngJs--iPJmmLQe7CSsOK1UsLdidSy3pW3RuV8TNnpMlwQvvjqtu5hknpsaaSugNGO5qondLvF',
            'contact_number' => '011 123 45678','alternative_contact_number' => '011 123 45679',
        ]);

        // Site 3 Device
        $siteThree = Site::where('name', 'Chicken Licken Sandton')->first();
        $siteThree->devices()->create([
            'serial_no' => 'CLS-SER-001',
            'device_token' => 'da12i0sm8Oc:APA91bFJ9hdhXfqLm-OZMedLZqPdwFXS-NhNbp9fG41V6SX_jxwKkGxyWNH8FizsJ2NngJs--iPJmmLQe7CSsOK1UsLdidSy3pW3RuV8TNnpMlwQvvjqtu5hknpsaaSugNGO5qondLvF',
            'contact_number' => '011 123 45678','alternative_contact_number' => '011 123 45679',
        ]);

        // Site 4 Device
        $siteFour = Site::where('name', 'Inifinity Serviced Office Fourways')->first();
        $siteFour->devices()->create([
            'serial_no' => 'ISOF-SER-001',
            'device_token' => 'da12i0sm8Oc:APA91bFJ9hdhXfqLm-OZMedLZqPdwFXS-NhNbp9fG41V6SX_jxwKkGxyWNH8FizsJ2NngJs--iPJmmLQe7CSsOK1UsLdidSy3pW3RuV8TNnpMlwQvvjqtu5hknpsaaSugNGO5qondLvF',
            'contact_number' => '011 123 45678','alternative_contact_number' => '011 123 45679',
        ]);

        // Site 5 Device
        $siteFive = Site::where('name', 'Inifinity Serviced Office Centurion')->first();
        $siteFive->devices()->create([
            'serial_no' => 'ISOC-SER-001',
            'device_token' => 'da12i0sm8Oc:APA91bFJ9hdhXfqLm-OZMedLZqPdwFXS-NhNbp9fG41V6SX_jxwKkGxyWNH8FizsJ2NngJs--iPJmmLQe7CSsOK1UsLdidSy3pW3RuV8TNnpMlwQvvjqtu5hknpsaaSugNGO5qondLvF',
            'contact_number' => '011 123 45678','alternative_contact_number' => '011 123 45679',
        ]);

        // Site 6 Device
        $siteSix = Site::where('name', 'Inifinity Serviced Office Boksburg')->first();
        $siteSix->devices()->create([
            'serial_no' => 'ISOB-SER-001',
            'device_token' => 'da12i0sm8Oc:APA91bFJ9hdhXfqLm-OZMedLZqPdwFXS-NhNbp9fG41V6SX_jxwKkGxyWNH8FizsJ2NngJs--iPJmmLQe7CSsOK1UsLdidSy3pW3RuV8TNnpMlwQvvjqtu5hknpsaaSugNGO5qondLvF',
            'contact_number' => '011 123 45678','alternative_contact_number' => '011 123 45679',
        ]);
    }
}
