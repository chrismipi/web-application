<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $superAdminRole = Role::create([
            'name' => RolesAndPermissions::SuperAdminUser,
            'guard_name' => 'web',
        ]);
        $superAdminRole->givePermissionTo([
            // Admin Permissions
            RolesAndPermissions::AddAdmin,
            RolesAndPermissions::ViewAdmin,
            RolesAndPermissions::EditAdmin,
            RolesAndPermissions::DeleteAdmin,

            // Operator Permissions
            RolesAndPermissions::AddOperator,
            RolesAndPermissions::ViewOperator,
            RolesAndPermissions::EditOperator,
            RolesAndPermissions::DeleteOperator,

            // Security Company Permissions
            RolesAndPermissions::AddSecurityCompany,
            RolesAndPermissions::ViewSecurityCompany,
            RolesAndPermissions::EditSecurityCompany,
            RolesAndPermissions::DeleteSecurityCompany,

            // Site Permissions
            RolesAndPermissions::AddSite,
            RolesAndPermissions::ViewSite,
            RolesAndPermissions::EditSite,
            RolesAndPermissions::DeleteSite,

            // Client Permissions
            RolesAndPermissions::AddClient,
            RolesAndPermissions::ViewClient,
            RolesAndPermissions::EditClient,
            RolesAndPermissions::DeleteClient,

            // Trip Permissions
            RolesAndPermissions::ViewTrip,

            // Report permissions
            RolesAndPermissions::GenerateReport,
            RolesAndPermissions::ViewReport,

            // Event Permissions
            RolesAndPermissions::ViewEvent,
            RolesAndPermissions::ViewEventDetails,
        ]);

        $adminRole = Role::create([
            'name' => RolesAndPermissions::AdminUser,
            'guard_name' => 'web',
        ]);
        $adminRole->givePermissionTo([
            // Admin Permissions
            RolesAndPermissions::AddAdmin,
            RolesAndPermissions::ViewAdmin,
            RolesAndPermissions::EditAdmin,
            RolesAndPermissions::DeleteAdmin,

            // Operator Permissions
            RolesAndPermissions::AddOperator,
            RolesAndPermissions::ViewOperator,
            RolesAndPermissions::EditOperator,
            RolesAndPermissions::DeleteOperator,

            // Security Company Permissions
            RolesAndPermissions::AddSecurityCompany,
            RolesAndPermissions::ViewSecurityCompany,
            RolesAndPermissions::EditSecurityCompany,
            RolesAndPermissions::DeleteSecurityCompany,

            // Site Permissions
            RolesAndPermissions::AddSite,
            RolesAndPermissions::ViewSite,
            RolesAndPermissions::EditSite,
            RolesAndPermissions::DeleteSite,

            // Client Permissions
            RolesAndPermissions::AddClient,
            RolesAndPermissions::ViewClient,
            RolesAndPermissions::EditClient,
            RolesAndPermissions::DeleteClient,

            // Trip Permissions
            RolesAndPermissions::ViewTrip,

            // Report permissions
            RolesAndPermissions::GenerateReport,
            RolesAndPermissions::ViewReport,

            // Event Permissions
            RolesAndPermissions::ViewEvent,
            RolesAndPermissions::ViewEventDetails,
        ]);

        $adminRole = Role::create([
            'name' => RolesAndPermissions::OperatorUser,
            'guard_name' => 'web',
        ]);
        $adminRole->givePermissionTo([
            // Admin Permissions
            RolesAndPermissions::ViewAdmin,

            // Operator Permissions
            RolesAndPermissions::ViewOperator,

            // Security Company Permissions
            RolesAndPermissions::ViewSecurityCompany,

            // Site Permissions
            RolesAndPermissions::ViewSite,

            // Client Permissions
            RolesAndPermissions::ViewClient,

            // Trip Permissions
            RolesAndPermissions::ViewTrip,

            // Report permissions
            RolesAndPermissions::GenerateReport,
            RolesAndPermissions::ViewReport,

            // Event Permissions
            RolesAndPermissions::ViewEvent,
            RolesAndPermissions::ViewEventDetails,
        ]);

        $securityCompanyUserRole = Role::create([
            'name' => RolesAndPermissions::SecurityCompanyUser,
            'guard_name' => 'web',
        ]);
        $securityCompanyUserRole->givePermissionTo([
            // Site Permissions
            RolesAndPermissions::ViewSite,

            // Client Permissions
            RolesAndPermissions::ViewClient,

            // Trip Permissions
            RolesAndPermissions::ViewTrip,

            // Report permissions
            RolesAndPermissions::GenerateReport,
            RolesAndPermissions::ViewReport,

            // Event Permissions
            RolesAndPermissions::ViewEvent,
        ]);

        $clientUserRole = Role::create([
            'name' => RolesAndPermissions::ClientUser,
            'guard_name' => 'web',
        ]);
        $clientUserRole->givePermissionTo([
            // Site Permissions
            RolesAndPermissions::ViewSite,

            // Trip Permissions
            RolesAndPermissions::ViewTrip,

            // Report Permissions
            RolesAndPermissions::GenerateReport,
            RolesAndPermissions::ViewReport,

            // Event Permissions
            RolesAndPermissions::ViewEvent,
        ]);

        $deviceUserRole = Role::create([
            'name' => RolesAndPermissions::DeviceUser,
            'guard_name' => 'web',
        ]);
    }
}
