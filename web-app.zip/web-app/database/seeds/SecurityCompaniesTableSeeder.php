<?php

use App\User;
use Illuminate\Database\Seeder;

class SecurityCompaniesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Security Company 1
        $userOne = User::where('first_name', 'Security Comp')->where('last_name', 'One')->first();
        $userOne->securityCompanies()->create([
            'name' => 'ADT Security',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);

        // Security Company User 2
        $userTwo = User::where('first_name', 'Security Comp')->where('last_name', 'Two')->first();
        $userTwo->securityCompanies()->create([
            'name' => 'G4S Security',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);

        // Security Company User 3
        $userThree = User::where('first_name', 'Security Comp')->where('last_name', 'Three')->first();
        $userThree->securityCompanies()->create([
            'name' => 'Chub Security',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);
    }
}
