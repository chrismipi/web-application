<?php

use Illuminate\Database\Seeder;
// use RolesAndPermissions;
use Spatie\Permission\Models\Permission;

class PermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Admin Permissions
        // Permission::insert(['name' => 'add admin']);
        Permission::insert([
            [
                'name' => RolesAndPermissions::AddAdmin,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::ViewAdmin,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::EditAdmin,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::DeleteAdmin,
                'guard_name' => 'web',
            ],
        ]);

        // Operator Permissions
        Permission::insert([
            [
                'name' => RolesAndPermissions::AddOperator,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::ViewOperator,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::EditOperator,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::DeleteOperator,
                'guard_name' => 'web',
            ],
        ]);

        // Security Company Permissions
        Permission::insert([
            [
                'name' => RolesAndPermissions::AddSecurityCompany,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::ViewSecurityCompany,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::EditSecurityCompany,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::DeleteSecurityCompany,
                'guard_name' => 'web',
            ],
        ]);

        // Site Permissions
        Permission::insert([
            [
                'name' => RolesAndPermissions::AddSite,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::ViewSite,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::EditSite,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::DeleteSite,
                'guard_name' => 'web',
            ],
        ]);

        // Client Permissions
        Permission::insert([
            [
                'name' => RolesAndPermissions::AddClient,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::ViewClient,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::EditClient,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::DeleteClient,
                'guard_name' => 'web',
            ],
        ]);

        // Trip Permissions
        Permission::insert([
            [
                'name' => RolesAndPermissions::ViewTrip,
                'guard_name' => 'web',
            ],
        ]);

        // Report Permissions
        Permission::insert([
            [
                'name' => RolesAndPermissions::GenerateReport,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::ViewReport,
                'guard_name' => 'web',
            ],
        ]);

        // Event Permissions
        Permission::insert([
            [
                'name' => RolesAndPermissions::ViewEvent,
                'guard_name' => 'web',
            ],
            [
                'name' => RolesAndPermissions::ViewEventDetails,
                'guard_name' => 'web',
            ],
        ]);
    }
}
