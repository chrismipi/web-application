<?php

use App\Client;
use App\SecurityCompany;
use App\Site;
use Illuminate\Database\Seeder;

class SitesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Site 1
        $siteOne = Site::make([
            'name' => 'KFC Fourways',
            'description' => 'KFC Fourways Branch',
            'address' => '2 Pieter Wenning Road, Fourways, South Africa',
            'latitude' => '09.123456',
            'longitude' => '-09.123456',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);
        $clientOne = Client::where('name', 'Infinity Business Park')->first();
        $securityCompanyOne = SecurityCompany::where('name', 'ADT Security')->first();
        $siteOne->client()->associate($clientOne);
        $siteOne->securityCompany()->associate($securityCompanyOne);
        $siteOne->save();

        // Site User 2
        $siteTwo = Site::make([
            'name' => 'Chicken Licken Fourways',
            'description' => 'Chicken Licken Fourways Branch',
            'address' => '3 Pieter Wenning Road, Fourways, South Africa',
            'latitude' => '10.123456',
            'longitude' => '-10.123456',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);
        $siteThree = Site::make([
            'name' => 'Chicken Licken Sandton',
            'description' => 'Chicken Licken Sandton Branch',
            'address' => '4 Sandton Drive, Sandton, South Africa',
            'latitude' => '11.123456',
            'longitude' => '-11.123456',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);
        $clientTwo = Client::where('name', 'Fourways Mall')->first();
        $securityCompanyTwo = SecurityCompany::where('name', 'G4S Security')->first();

        $siteTwo->client()->associate($clientTwo);
        $siteTwo->securityCompany()->associate($securityCompanyTwo);
        $siteTwo->save();

        $siteThree->client()->associate($clientTwo);
        $siteThree->securityCompany()->associate($securityCompanyTwo);
        $siteThree->save();

        // Site User 3
        $siteFour = Site::make([
            'name' => 'Inifinity Serviced Office Fourways',
            'description' => 'Business Park in Fourways',
            'address' => '4 Pieter Wenning Road, Fourways, South Africa',
            'latitude' => '12.123456',
            'longitude' => '-12.123456',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);
        $siteFive = Site::make([
            'name' => 'Inifinity Serviced Office Centurion',
            'description' => 'Business Park in Centurion',
            'address' => '2 West Avenue, Centurion, South Africa',
            'latitude' => '13.123456',
            'longitude' => '-13.123456',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);

        $siteSix = Site::make([
            'name' => 'Inifinity Serviced Office Boksburg',
            'description' => 'Business Park in Boksburg',
            'address' => '9 Boks Drive, Bockburg, South Africa',
            'latitude' => '14.123456',
            'longitude' => '-14.123456',
            'contact_number' => '011 123 4567',
            'alternative_contact_number' => '011 123 4568',
        ]);
        $clientThree = Client::where('name', 'Deinfern Square')->first();
        $securityCompanyThree = SecurityCompany::where('name', 'Chub Security')->first();

        $siteFour->client()->associate($clientThree);
        $siteFour->securityCompany()->associate($securityCompanyThree);
        $siteFour->save();

        $siteFive->client()->associate($clientThree);
        $siteFive->securityCompany()->associate($securityCompanyThree);
        $siteFive->save();

        $siteSix->client()->associate($clientThree);
        $siteSix->securityCompany()->associate($securityCompanyThree);
        $siteSix->save();
    }
}
