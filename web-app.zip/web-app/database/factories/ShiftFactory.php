<?php

use Carbon\Carbon;
use Faker\Generator as Faker;

/* @var Illuminate\Database\Eloquent\Factory $factory */

$factory->define(App\Shift::class, function (Faker $faker) {
    return [
        'start_time' => $faker->time('HH:mm'),
        'end_time' => $faker->time('HH:mm'),
        'patrol_count' => $faker->randomNumber(),
        'rest_time' => $faker->time('HH:mm'),
        'trip_duration' => $faker->time('HH:mm'),
        'created_at' => new Carbon(),
        'updated_at' => new Carbon(),
    ];
});
