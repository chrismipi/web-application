<?php

use Carbon\Carbon;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
 */

$factory->define(App\NfcTag::class, function (Faker $faker) {
    return [
        'serial_no' => $faker->word,
        'latitude' => $faker->randomFloat(6, 10, 99),
        'longitude' => $faker->randomFloat(6, 10, 99),
        'sequence_no' => $faker->numberBetween(-1, 1000),
        'created_at' => new Carbon(),
        'updated_at' => new Carbon(),
    ];
});
