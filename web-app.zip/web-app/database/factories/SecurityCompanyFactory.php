<?php

use Carbon\Carbon;
use Faker\Generator as Faker;

/* @var Illuminate\Database\Eloquent\Factory $factory */

$factory->define(App\SecurityCompany::class, function (Faker $faker) {
    return [
        'name' => $faker->name,
        'contact_number' => '0111234567',        
        'alternative_contact_number' => '0111234568',
        'created_at' => new Carbon(),
        'updated_at' => new Carbon(),
    ];
});
